import { Outlet } from 'react-router-dom';
import Layout from './Layout';
import Lnb from './Lnb';
import Header from './Header';
import { SubLayoutStyle, MainContent } from './StyledLayout';

export interface SubLayoutProps {}

const SubLayout: React.FC<SubLayoutProps> = () => {
  return (
    <Layout>
      <Lnb />
      <SubLayoutStyle className="main-content-wrap">
        <Header />
        <MainContent>
          <Outlet />
        </MainContent>
      </SubLayoutStyle>
    </Layout>
  );
};

export default SubLayout;

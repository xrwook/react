import styled from 'styled-components';
import closeIcon from '/images/icons/icon-close.svg';

export const DimWrapper = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: #00000099;
  z-index: 100;
`;

export const ModalWrapper = styled.div`
  display: flex;
  align-items: center;
  display: inline-block;
  vertical-align: middle;
`;

export const ModalBox = styled.div<{ width?: string; height?: string }>`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  border-radius: 10px;
  background-color: ${(props) => props.theme.color.white};
`;

export const ModalClose = styled.button`
  position: absolute;
  right: 30px;
  top: 30px;
  width: 24px;
  height: 24px;
  background: url(${closeIcon}) no-repeat;
`;

export const ModalHeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px 66px 4px 30px;
`;

export const ModalContentWrapper = styled.div`
  overflow-y: auto;
  padding: 20px 30px 24px 30px;
`;

export const ModalFooterWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 24px 30px;
`;

import styled from 'styled-components';
import { NavLink } from 'react-router-dom';
import homeIcon from 'style/assets/images/icon-home.svg';

const Breadcrumbhome = styled(NavLink)`
  display: inline-block;
  width: 20px;
  height: 20px;
  background-image: url(${homeIcon});
  background-repeat: no-repeat;
`;

export interface BreadcrumbHomeProps {
  children?: any;
  to?: any;
}

const BreadcrumbHome: React.FC<BreadcrumbHomeProps> = ({ children, to }) => {
  return <Breadcrumbhome to={to}>{children}</Breadcrumbhome>;
};

export default BreadcrumbHome;

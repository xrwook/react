import { ReactDatePickerProps, registerLocale } from 'react-datepicker';
import { ko } from 'date-fns/locale/ko';
import 'react-datepicker/dist/react-datepicker.css';
import { useState } from 'react';
import { DatePickerStyle, DatePickerWrapper } from './StyledDatepicker';

registerLocale('ko', ko);

const DatePicker = ({ ...props }: ReactDatePickerProps) => {
  const [startDate, setStartDate] = useState(new Date());

  return (
    <DatePickerWrapper>
      <DatePickerStyle
        {...props}
        disabledKeyboardNavigation
        dateFormatCalendar="yyyy년 MM월"
        locale="ko"
        selected={startDate}
        onChange={(date: any) => setStartDate(date)}
        peekNextMonth
        showMonthDropdown
        showYearDropdown
        dropdownMode="select"
      />
    </DatePickerWrapper>
  );
};

export default DatePicker;

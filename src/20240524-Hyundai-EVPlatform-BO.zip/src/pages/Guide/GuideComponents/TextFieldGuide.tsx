import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import TextField from 'common/TextField';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TextFieldGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>TextField</GuideText>
        <GuideBox>
          <Grid $columns={3} $gap="20px">
            <GridItem>
              <TextField
                id="TextField01"
                name="text"
                type="text"
                placeholder="Placeholder"
              />
              <br />
              <TextField
                id="TextField02"
                name="readOnly"
                type="text"
                value="readOnly"
                readOnly
              />
              <br />
              <TextField
                id="TextField03"
                name="disabled"
                type="text"
                value="disabled"
                disabled
              />
              <br />
              <TextField
                id="TextField04"
                name="number"
                type="number"
                placeholder="숫자만 입력해주세요"
              />
            </GridItem>
            <GridItem>
              <TextField
                id="TextField05"
                name="error"
                type="text"
                placeholder="error"
                $error
                $errorMessage="Invaild message content"
              />
              <TextField
                id="TextField09"
                name="error"
                type="text"
                placeholder="valid"
                $verified
                $verifiedMessage="Vaild message content"
              />
            </GridItem>
            <GridItem>
              <TextField
                id="TextField06"
                name="text"
                type="text"
                placeholder="Placeholder"
                $search
              />
              <br />
              <TextField
                id="TextField08"
                name="text"
                type="text"
                value="readOnly"
                readOnly
                $search
              />
              <br />
              <TextField
                id="TextField07"
                name="text"
                type="text"
                value="disabled"
                disabled
                $search
              />
              <br />
              <TextField
                id="TextField08"
                name="TextField08"
                type="number"
                placeholder="숫자로 입력하세요"
                $innerRight="원"
              />
            </GridItem>
          </Grid>
        </GuideBox>
        <GuideSubBox>
          {` <TextField
            id="TextField01"
            name="text"
            type="text"
            placeholder="Placeholder"
          />
          `}
          <br />
          {`
          <TextField
            id="TextField02"
            name="readOnly"
            type="text"
            value="readOnly"
            readOnly
          />
          `}
          <br />
          {`
          <TextField
            id="TextField03"
            name="disabled"
            type="text"
            value="disabled"
            disabled
          />
          `}
          <br />
          {`
          <TextField
            id="TextField04"
            name="number"
            type="number"
            placeholder="숫자만 입력해주세요"
          />
          `}
          <br />
          {`
          <TextField
            id="TextField05"
            name="error"
            type="text"
            placeholder="error"
            $error
            $errorMessage="Invaild message content"
          />
          `}
          <br />
          {`
          <TextField
            id="TextField05"
            name="error"
            type="text"
            placeholder="valid"
            $verified
            $verifiedMessage="Vaild message content"
          />
          `}
          <br />
          {`
          <TextField
            id="TextField06"
            name="text"
            type="text"
            placeholder="Placeholder"
            $search
          />
          `}
          <br />
          {`
          <TextField
            id="TextField08"
            name="text"
            type="text"
            value="readOnly"
            readOnly
            $search
          />
          `}
          <br />
          {`
          <TextField
            id="TextField07"
            name="text"
            type="text"
            value="disabled"
            disabled
            $search
          />
          `}
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>readOnly</td>
              <td>readOnly</td>
              <td>읽기만 가능</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$error</td>
              <td>$error</td>
              <td>error 디자인 적용</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$errorMessage</td>
              <td>{`$errorMessage="Invaild message content"`}</td>
              <td>error message 입력</td>
              <td></td>
            </tr>
            <tr>
              <td>$verified</td>
              <td>$verified</td>
              <td>verified 디자인 적용</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$verifiedMessage</td>
              <td>{`$verifiedMessage="Vaild message content"`}</td>
              <td>Vaild message 입력</td>
              <td></td>
            </tr>
            <tr>
              <td>$search</td>
              <td>$search</td>
              <td>search 디자인 적용</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$innerRight</td>
              <td>{`$innerRight="원"`}</td>
              <td>textfield 내 단위 적용</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TextFieldGuide;

import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Switch from 'common/Switch';
import GuideTable from './GuideTable';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const RadioBoxGuide = () => {
  return (
    <StyledGuideWrapper>
      <div style={{ padding: '50px' }}>
        <GuideWrapper>
          <GuideText>Switch</GuideText>
          <GuideBox>
            <ul>
              <li>
                <Switch id="check01" name="check01" />
              </li>
              <li style={{ margin: '10px 0' }}>
                <Switch id="check02" name="check02" defaultChecked />
              </li>
              <li>
                <Switch id="check03" name="check03" disabled />
              </li>
            </ul>
          </GuideBox>
          <GuideSubBox>
            &lt;Switch id="check01" name="check01"&gt; <br />
            &lt;Switch id="check02" name="check02" defaultChecked&gt;
            <br />
            &lt;iSwitch id="check03" name="check03" disabled&gt;
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>id</td>
                <td>id</td>
                <td>id 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>name</td>
                <td>name</td>
                <td>name 입력</td>
                <td>id 값과 일치</td>
              </tr>
              <tr>
                <td>disabled</td>
                <td>disabled</td>
                <td>disabled 타입 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>defaultChecked</td>
                <td>defaultChecked</td>
                <td>checked 상태 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </GuideWrapper>
      </div>
    </StyledGuideWrapper>
  );
};

export default RadioBoxGuide;

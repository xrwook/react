import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import CheckBox from 'common/CheckBox/Checkbox';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import GuideTable from './GuideTable';

const CheckBoxGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Check Box</GuideText>
        <GuideBox>
          <Grid $columns={3} $gap="12px">
            <GridItem>
              <h4>라벨이 없는 경우</h4>
              <CheckBox
                id="check01"
                name="check01"
                htmlFor="check01"
                defaultChecked
              />
              <CheckBox
                id="check02"
                name="check02"
                htmlFor="check02"
                defaultChecked
                disabled
              />
              <CheckBox id="check03" name="check03" htmlFor="check03" />
              <CheckBox
                id="check04"
                name="check04"
                htmlFor="check04"
                disabled
              />
            </GridItem>
            <GridItem>
              <h4>라벨이 있는 경우</h4>
              <CheckBox
                id="check05"
                name="check05"
                text="Label"
                htmlFor="check05"
                defaultChecked
              />
              <CheckBox
                id="check06"
                name="check06"
                text="Label"
                htmlFor="check06"
                defaultChecked
                disabled
              />
              <CheckBox
                id="check07"
                name="check07"
                text="Label"
                htmlFor="check07"
              />
              <CheckBox
                id="check08"
                name="check08"
                text="Label"
                htmlFor="check08"
                disabled
              />
            </GridItem>
          </Grid>
        </GuideBox>
        <GuideSubBox>
          &lt;CheckBox id="" name="" text="" htmlFor="" defaultChecked /&gt;{' '}
          <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" defaultChecked disabled
          /&gt; <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" /&gt; <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" disabled /&gt;
        </GuideSubBox>

        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>defaultChecked</td>
              <td>defaultChecked</td>
              <td>defaultChecked</td>
              <td></td>
            </tr>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성 상태</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default CheckBoxGuide;

import { useState } from 'react';
import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Tab from 'common/Tab/Tab';
import CheckBoxGuide from './CheckBoxGuide';
import ButtonGuide from './ButtonGuide';
import BreadcrumbGuide from './BreadcrumbGuide';
import ModalGuide from './ModalGuide';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const TabGuide = () => {
  const BasetabData = [
    {
      name: 'Item 1',
      Component: CheckBoxGuide,
    },
    {
      name: 'Selected Item',
      Component: ButtonGuide,
    },
    {
      name: 'Item 3',
      Component: BreadcrumbGuide,
    },
    {
      name: 'Item 4',
      Component: ModalGuide,
    },
    {
      name: 'Item 5',
      Component: ButtonGuide,
    },
    {
      name: 'Item 6',
      Component: CheckBoxGuide,
    },
    {
      name: 'Item 7',
      Component: ModalGuide,
    },
  ];

  const [isSelected, setSelected] = useState(0);

  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Tab</GuideText>
        <GuideBox>
          <Tab tabs={BasetabData} selected={isSelected} onClick={setSelected} />
        </GuideBox>
        <GuideSubBox>
          &lt;Tab tabs="" selected="" onClick="" /&gt; <br />
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default TabGuide;

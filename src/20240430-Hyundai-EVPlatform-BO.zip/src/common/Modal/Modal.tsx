import styled from 'styled-components';
import closeIcon from 'style/assets/images/icon-close.svg';

const DimWrapper = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: #00000099;
  z-index: 100;
`;

const ModalWrapper = styled.div`
  display: flex;
  align-items: center;
  display: inline-block;
  vertical-align: middle;
`;

const ModalBox = styled.div<{ width?: string; height?: string }>`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  border-radius: 10px;
  background-color: ${(props) => props.theme.color.white};
`;

const ModalClose = styled.button`
  position: absolute;
  right: 30px;
  top: 30px;
  width: 24px;
  height: 24px;
  background: url(${closeIcon}) no-repeat;
`;

export interface ModalProps {
  width?: string;
  height?: string;
  children?: any;
  onClose(): void;
}

const Modal: React.FC<ModalProps> = ({ width, height, children, onClose }) => {
  const handleCloseClick = (e: any) => {
    e.preventDefault();
    onClose();
  };

  return (
    <>
      <DimWrapper>
        <ModalWrapper>
          <ModalBox width={width} height={height}>
            <ModalClose
              type="button"
              aria-label="close"
              onClick={handleCloseClick}
            />
            {children}
          </ModalBox>
        </ModalWrapper>
      </DimWrapper>
    </>
  );
};

export default Modal;

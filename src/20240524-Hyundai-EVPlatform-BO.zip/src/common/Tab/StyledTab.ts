import styled, { css } from 'styled-components';
import { TabProps } from './Tab';

export const TabList = styled.div<TabProps>`
  width: 100%;

  ul {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid #f0f0f0;
  }
  li {
    width: auto;
  }
  li + li {
    padding-left: 30px;
  }
`;

export const TabItem = styled.li<TabProps>`
  button,
  a {
    display: block;
    width: 100%;
    height: 44px;
    padding: 10px 0;
    font-size: 15px;
    line-height: 24px;
    color: #8d96a1;
    font-weight: 600;
    text-align: center;
    box-sizing: border-box;
  }

  ${(props) =>
    props.$active &&
    css`
      button,
      a {
        color: #242a30;
        border-bottom: 2px solid ${(props) => props.theme.color.primary};
      }
    `};
`;

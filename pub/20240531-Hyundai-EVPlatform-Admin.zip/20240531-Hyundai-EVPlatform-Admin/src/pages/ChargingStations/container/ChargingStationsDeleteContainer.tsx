import { useState } from 'react';
import Alert from 'common/Alert';
import AlertHeader from 'common/Alert/AlertHeader';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';
import { TextColor } from '../styled/StyledChargingStations';

const ChargingStationsDelete: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);
  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        충전소 삭제
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertHeader>충전소 삭제</AlertHeader>
          <AlertContent>
            충전소를 삭제하시겠습니까?
            <TextColor>서울역 HD 충전소</TextColor>
          </AlertContent>
          <AlertFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowAlert(false)}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                삭제
              </Button>
            </ButtonGroup>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargingStationsDelete;

import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import Button from 'common/Button/Button';
import Icon from 'common/Icon/Icon';
import { ButtonGroup } from 'common/Button/StyledButton';

/**
 * icon 상태 : default, click, dimmed, hover
 * icon 파일 네이밍 : icon-default(아이콘 이름), icon-defaul-click, icon-defaul-dimmed, icon-defaul-hover
 * (필수 prefix : icon- / 다른 상태 보여줄시 suffix 추가 : ~-click, ~-dimmed, ~-hover)
 */

const Layout = styled.div`
  display: flex;
  gap: 8px;
`;

const ButtonGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>
          Button <h3>Mini</h3>
        </GuideText>
        {/* mini */}
        <GuideBox>
          <Layout>
            <Button onClick={() => {}} $size="mini" $variant="primary">
              Button
            </Button>
            <Button onClick={() => {}} $size="mini" $variant="primary" disabled>
              Button
            </Button>

            <Button onClick={() => {}} $size="mini" $variant="secondaryGray">
              Button
            </Button>
            <Button
              onClick={() => {}}
              $size="mini"
              $variant="secondaryGray"
              disabled
            >
              Button
            </Button>
          </Layout>
        </GuideBox>

        {/* small */}
        <GuideText>
          <h3>Small</h3>
        </GuideText>
        <GuideBox>
          <Layout>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="primary"
              $icon="icon-search-primary"
            >
              <Icon $widthSize={20} $heightSize={20}>
                검색
              </Icon>
              primary
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="primary"
              disabled
            >
              primary
            </Button>

            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryBlue"
              $icon="icon-search-secondaryBlue"
            >
              <Icon $widthSize={20} $heightSize={20}>
                검색
              </Icon>
              secondaryBlue
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryBlue"
              disabled
            >
              secondaryBlue
            </Button>
            <Button onClick={() => {}} $size="small" $variant="tertiary">
              tertiary
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="tertiary"
              disabled
            >
              tertiary
            </Button>
            <Button onClick={() => {}} $size="small" $variant="secondaryGray">
              secondaryGray
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryGray"
              disabled
            >
              secondaryGray
            </Button>
            <Button onClick={() => {}} $size="small" $variant="transparent">
              transparent
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="transparent"
              disabled
            >
              transparent
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="transparentPurple"
              disabled
            >
              transparentPurple
            </Button>
          </Layout>
        </GuideBox>

        {/* large */}
        <GuideText>
          <h3>Large &amp; iconOnly</h3>
        </GuideText>
        <GuideBox>
          <Layout>
            <Button onClick={() => {}} $size="large" $variant="primary">
              primary
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="primary"
              disabled
            >
              primary
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="secondaryBlue"
              $icon="icon-search-secondaryBlue"
            >
              <Icon $widthSize={20} $heightSize={20}>
                검색
              </Icon>
              secondaryBlue
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="secondaryBlue"
              disabled
            >
              secondaryBlue
            </Button>
            <Button onClick={() => {}} $size="large" $variant="tertiary">
              tertiary
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="tertiary"
              disabled
            >
              tertiary
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="secondaryGray"
              $icon="icon-search-secondaryGray"
            >
              secondaryGray
            </Button>

            <Button
              onClick={() => {}}
              $size="large"
              $variant="secondaryGray"
              $icon="icon-search-secondaryGray"
              disabled
            >
              <Icon $widthSize={20} $heightSize={20}>
                검색
              </Icon>
              secondaryGray
            </Button>
            <Button onClick={() => {}} $size="large" $variant="transparent">
              transparent
            </Button>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="transparent"
              disabled
            >
              transparent
            </Button>
            <Button
              onClick={() => {}}
              $size="none"
              $variant="none"
              $iconOnly
              $icon="icon-search-secondaryBlue"
            >
              검색
            </Button>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Button onClick disabled $size="mini" $variant="primary"
          $icon="icon-search-primary"&gt; 버튼명 &lt;/Button&gt; <br />{' '}
          &lt;Button onClick $size="none" $variant="none"
          $icon="icon-search-primary" $iconOnly&gt; 검색 &lt;/Button&gt;
        </GuideSubBox>

        {/* 기타 */}
        <GuideText>
          <h3>Button Group</h3>
        </GuideText>
        <GuideBox>
          <Layout>
            <ButtonGroup $gap={6} $direction={'column'}>
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
                Button
              </Button>
            </ButtonGroup>
            <ButtonGroup $width={174} $gap={6} $direction={'column'}>
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
                Button
              </Button>
            </ButtonGroup>
            <ButtonGroup $gap={20} $direction={'row'}>
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
                Button
              </Button>
            </ButtonGroup>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;ButtonGroup {`$width={174} $gap={6} $direction={'column | row'}`}
          &gt;&lt;/ButtonGroup&gt;
        </GuideSubBox>
        <GuideText>
          <h3>Button</h3>
        </GuideText>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$size</td>
              <td>$size="large"</td>
              <td>mini , small , large , none</td>
              <td></td>
            </tr>
            <tr>
              <td>$variant</td>
              <td>$variant="primary"</td>
              <td>
                primary , secondaryBlue , secondaryGray , tertiary , transparent
                , transparentPurple , none
              </td>
              <td></td>
            </tr>
            <tr>
              <td>$icon</td>
              <td>$icon="icon-search-secondaryBlue"</td>
              <td>아이콘 name을 넣어줍니다</td>
              <td>{`/images/icons/icon-search-secondaryBlue.svg`}</td>
            </tr>
            <tr>
              <td>$iconOnly</td>
              <td>$iconOnly</td>
              <td>아이콘만 필요할 경우</td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>

        <GuideText>
          <h3>Button Group</h3>
        </GuideText>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>$width</td>
              <td>{`$width={174}`}</td>
              <td>Button Group의 width 값</td>
              <td></td>
            </tr>
            <tr>
              <td>$gap</td>
              <td>{`$gap={6}`}</td>
              <td>gap="6px"</td>
              <td>버튼과 버튼 사이의 간격</td>
            </tr>
            <tr>
              <td>$direction</td>
              <td>{`$direction={'column'}`}</td>
              <td>row, column</td>
              <td>버튼 나열 방향</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default ButtonGuide;

import React, { useRef } from 'react';
import { AgGridTooltipWrap } from './StyledAgGrid';

export interface AgGridTooltipProps {
  message?: any;
}

const AgGridTooltip: React.FC<AgGridTooltipProps> = ({ message }) => {
  const AgGridTooltipRef = useRef<any>(null);
  return (
    <AgGridTooltipWrap ref={AgGridTooltipRef}>{message}</AgGridTooltipWrap>
  );
};

export default AgGridTooltip;

import { useState } from 'react';
import Alert from 'common/Alert';
import AlertHeader from 'common/Alert/AlertHeader';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargerIssuesDeleteContainer: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);

  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        고장 접수 내역 삭제
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertHeader>고장 접수 내역 삭제</AlertHeader>
          <AlertContent>
            내역을 삭제한 이후에는 복구할 수 없습니다.
            <br />
            그래도 삭제하시겠습니까?
          </AlertContent>
          <AlertFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowAlert(false)}
                $size="large"
                $variant="tertiary"
                $width={77}
              >
                아니요
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={53}
              >
                네
              </Button>
            </ButtonGroup>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargerIssuesDeleteContainer;

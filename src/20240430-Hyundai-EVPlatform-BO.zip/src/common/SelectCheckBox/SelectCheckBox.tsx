import { useState } from 'react';
import { default as ReactSelect, components } from 'react-select';

export interface SelectCheckBoxProps {
  options?: any;
  placeholder?: any;
  isMulti?: any;
  hideSelectedOptions?: any;
  className?: any;
  title?: any;
  classNamePrefix: string;
  defaultValue?: any;
  required?: any;
  disabled?: any;
  error?: any;
  id?: any;
  components?: any;
}

const SelectCheckBox: React.FC<SelectCheckBoxProps> = ({
  options,
  placeholder,
  isMulti,
  hideSelectedOptions,
  className,
  classNamePrefix,
  defaultValue,
  disabled,
  id,
}) => {
  const [state, setState] = useState({ optionSelected: null });

  const handleChange = (selected: any) => {
    setState({
      optionSelected: selected,
    });
  };

  const Option = (props: any) => {
    return (
      <div>
        <components.Option {...props}>
          <input
            type="checkbox"
            checked={props.isSelected}
            onChange={() => null}
          />{' '}
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };

  return (
    <ReactSelect
      id={id}
      options={options}
      placeholder={placeholder}
      isMulti={isMulti}
      hideSelectedOptions={hideSelectedOptions}
      className={`
      ${className || ''}
      
    `}
      classNamePrefix={classNamePrefix}
      defaultValue={defaultValue}
      isDisabled={disabled}
      components={{
        Option,
      }}
      onChange={handleChange}
      value={state.optionSelected}
    />
  );
};

export default SelectCheckBox;

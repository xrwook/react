import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import CheckBox from 'common/CheckBox/Checkbox';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const CheckBoxGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Check Box</GuideText>
        <GuideBox>
          <div>
            <CheckBox
              id="check01"
              name="check01"
              htmlFor="check01"
              defaultChecked
            />
            <CheckBox
              id="check02"
              name="check02"
              htmlFor="check02"
              defaultChecked
              disabled
            />
            <CheckBox id="check03" name="check03" htmlFor="check03" />
            <CheckBox id="check04" name="check04" htmlFor="check04" disabled />
          </div>
          <div>
            <CheckBox
              id="check05"
              name="check05"
              text="Label"
              htmlFor="check05"
              defaultChecked
            />
            <CheckBox
              id="check06"
              name="check06"
              text="Label"
              htmlFor="check06"
              defaultChecked
              disabled
            />
            <CheckBox
              id="check07"
              name="check07"
              text="Label"
              htmlFor="check07"
            />
            <CheckBox
              id="check08"
              name="check08"
              text="Label"
              htmlFor="check08"
              disabled
            />
          </div>
        </GuideBox>
        <GuideSubBox>
          &lt;CheckBox id="" name="" text="" htmlFor="" defaultChecked /&gt;{' '}
          <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" defaultChecked disabled
          /&gt; <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" /&gt; <br />
          &lt;CheckBox id="" name="" text="" htmlFor="" disabled /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default CheckBoxGuide;

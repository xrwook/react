import React from 'react';
import ServiceLayout from 'pages/Service/ServiceLayout/ServiceLayout';
import ServiceHeader from 'pages/Service/ServiceHeader/ServiceHeader';
import ServiceFooter from 'pages/Service/ServiceFooter/ServiceFooter';
import ServiceContents from 'pages/Service/ServiceContents/ServiceContents';
import HomeIcon from 'style/assets/images/common/TestEllipse.svg';

const Service: React.FC = () => {
  const logo = 'Service';
  const menuOptions = [
    { title: 'MY COUPON', url: '/mycoupon' },
    { title: 'HISTORY', url: '/history' },
  ];

  // 해당 화면일 경우 color props 추가
  const navOptions = [
    {
      title: 'Home',
      url: '/Home',
      imageUrl: HomeIcon,
    },
    {
      title: 'Shop',
      url: '/shop',
      imageUrl: HomeIcon,
    },
    {
      title: 'Control',
      url: '/control',
      imageUrl: HomeIcon,
    },
    {
      title: 'Service',
      color: '#000',
      url: '/service',
      imageUrl: HomeIcon,
    },
    {
      title: 'My',
      url: '/my',
      imageUrl: HomeIcon,
    },
  ];

  return (
    <ServiceLayout>
      <ServiceHeader logo={logo} menuOptions={menuOptions} />
      <ServiceContents>
        <div style={{ height: '900px' }}>// 스크롤 생기게 하기 위한 더미</div>
      </ServiceContents>
      <ServiceFooter navOptions={navOptions} />
    </ServiceLayout>
  );
};

export default Service;

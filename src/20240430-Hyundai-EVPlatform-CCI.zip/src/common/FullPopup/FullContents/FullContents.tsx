import React from 'react';
import styled from 'styled-components';

const FullContentsWrapper = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 20px 30px 24px 30px;
`;

export interface FullContentsProps {
  children?: React.ReactNode;
}

const FullContents: React.FC<FullContentsProps> = ({ children }) => {
  return <FullContentsWrapper>{children}</FullContentsWrapper>;
};

export default FullContents;

import { useState } from 'react';
import {
  ArrowButton,
  DropdownInput,
  DropdownList,
  DropdownOption,
  DropdownText,
  DropdownWrapper,
} from './StyledDropdown';
import DropdownOptionDay from 'common/DropdownOptionDay/DropdownOptionDay';

type OptionType = {
  label: string;
  value: any;
};

export interface DropdownProps {
  initialValue?: OptionType;
  options: OptionType[];
  placeholder?: string;
  disabled?: any;
  label?: string;
  id?: string;
  $dropdown?: any;
  $readOnly?: any;
  $day?: any;
  $transparent?: any;
  transparent?: any;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  defaultOption?: any;
  defaultText?: string;
  $defaultText?: string;
}

const Dropdown: React.FC<DropdownProps> = ({
  placeholder,
  options,
  id,
  disabled,
  $readOnly,
  $day,
  $transparent,
  onClick,
  defaultOption,
  defaultText,
}) => {
  const [dropdown, setDropdown] = useState<boolean | null>(null);
  const [selected, setSelected] = useState<OptionType | null>(defaultOption);
  const handleClick = () => {
    setDropdown(!dropdown);
  };

  const handleItemClick = (option: OptionType) => {
    setSelected(option);
    setDropdown(!dropdown);
    onClick && onClick(option.value);
  };
  return (
    <>
      <DropdownWrapper>
        <DropdownInput
          $dropdown={dropdown}
          disabled={disabled}
          $readOnly={$readOnly}
          aria-expanded={dropdown ? dropdown : false}
          aria-label={selected ? selected.label : placeholder || ''}
          id={id}
          onClick={() => handleClick()}
          $transparent={$transparent}
        >
          <DropdownText
            disabled={disabled}
            selected={selected}
            $dropdown={dropdown}
            $defaultText={defaultText}
          >
            {selected ? selected.label : placeholder || ''}
          </DropdownText>
          <ArrowButton
            className="arrow-down"
            $dropdown={dropdown}
          ></ArrowButton>
        </DropdownInput>

        {dropdown && (
          <>
            <DropdownOptionDay $day={$day} />
            <DropdownList $day={$day}>
              {options &&
                options.map((option: OptionType, index) => (
                  <DropdownOption
                    role="option"
                    aria-selected={selected === option}
                    key={index}
                    aria-label={option.label}
                    tabIndex={dropdown ? 0 : -1}
                    onClick={() => handleItemClick(option)}
                  >
                    {option.label}
                  </DropdownOption>
                ))}
            </DropdownList>
          </>
        )}
      </DropdownWrapper>
    </>
  );
};

export default Dropdown;

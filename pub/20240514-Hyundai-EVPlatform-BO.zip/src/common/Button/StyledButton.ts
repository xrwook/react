import styled, { css } from 'styled-components';
import PrimaryIcon from '/images/icons/icon-search-primary.svg';
import PrimaryDisabledIcon from '/images/icons/icon-search-disabled.svg';
import SecondaryGrayIcon from '/images/icons/icon-search-secondaryGray.svg';
import SecondaryGrayDisabledIcon from '/images/icons/icon-search-secondaryGray-disabled.svg';
import SecondaryBlueIcon from '/images/icons/icon-search-secondaryBlue.svg';
import SecondaryBlueDisabledIcon from '/images/icons/icon-search-secondaryBlue-disabled.svg';
import TertiaryIcon from '/images/icons/icon-search-tertiary.svg';
import TertiaryDisabledIcon from '/images/icons/icon-search-tertiary-disabled.svg';
import DownloadIcon from '/images/icons/icon-download.svg';
import { ButtonProps } from './Button';

const size = {
  mini: css`
    height: 24px;
    padding: 1px 7px;
    font-size: ${(props) => props.theme.fontSize.fontSize1};
  `,
  small: css`
    height: 32px;
    padding: 5px 15px;
    font-size: ${(props) => props.theme.fontSize.fontSize2};
  `,
  large: css`
    height: 36px;
    padding: 5px 19px;
    font-size: ${(props) => props.theme.fontSize.fontSize3};
    line-height: 24px;
  `,
};

const variant = {
  primary: css`
    border: 1px solid ${(props) => props.theme.color.primary};
    background-color: ${(props) => props.theme.color.primary};

    &::before {
      background-image: url(${PrimaryIcon});
    }

    &:active {
      border: 1px solid #4c4b9d;
      background-color: #4c4b9d;
    }
    &:disabled {
      color: ${(props) => props.theme.color.gray1};
      border: 1px solid ${(props) => props.theme.color.gray4};
      background-color: ${(props) => props.theme.color.gray4};

      &::before {
        background-image: url(${PrimaryDisabledIcon});
      }
    }
    &:hover {
      border: 1px solid #7a78ff;
      background-color: #7a78ff;
    }
  `,
  secondaryBlue: css`
    color: #3a38ff;
    border: 1px solid #4341ff;
    background-color: ${(props) => props.theme.color.white};

    &::before {
      background-image: url(${SecondaryBlueIcon});
    }

    &:active {
      color: #4c4b9d;
      border: 1px solid #4c4b9d;
      background-color: #e6e4f9;
    }

    &:disabled {
      color: #7e8791;
      border: 1px solid #7e8791;
      background-color: ${(props) => props.theme.color.white};

      &::before {
        background-image: url(${SecondaryBlueDisabledIcon});
      }
    }

    &:hover {
      border: 1px solid #5958ff;
      background-color: #f4f3ff;
    }
  `,
  secondaryGray: css`
    color: #434860;
    border: 1px solid #c2c5d2;
    background-color: #fff;

    &::before {
      background-image: url(${SecondaryGrayIcon});
    }

    &:active {
      color: ${(props) => props.theme.color.gray8};
      border: 1px solid ${(props) => props.theme.color.gray4};
      background-color: #ebedf3;
    }

    &:disabled {
      color: ${(props) => props.theme.color.textDimed};
      border: 1px solid ${(props) => props.theme.color.gray2};
      background-color: #fbfbfb;

      &::before {
        background-image: url(${SecondaryGrayDisabledIcon});
      }
    }

    &:hover {
      border: 1px solid ${(props) => props.theme.color.gray2};
      background-color: ${(props) => props.theme.color.gray1};
    }
  `,
  tertiary: css`
    color: ${(props) => props.theme.color.gray10};
    border: 1px solid ${(props) => props.theme.color.gray3};
    background-color: ${(props) => props.theme.color.white};

    &::before {
      background-image: url(${TertiaryIcon});
    }

    &:active {
      border: 1px solid ${(props) => props.theme.color.gray4};
      background-color: #ebedf3;
    }

    &:disabled {
      color: ${(props) => props.theme.color.textDimed};
      border: 1px solid ${(props) => props.theme.color.gray2};
      background-color: #fbfbfb;

      &::before {
        background-image: url(${TertiaryDisabledIcon});
      }
    }

    &:hover {
      border: 1px solid #e8eaf0;
      background-color: #e8eaf0;
    }
  `,
  transparent: css`
    color: ${(props) => props.theme.color.gray8};
    border: 1px solid transparent;
    background-color: transparent;

    &:active {
      color: ${(props) => props.theme.color.gray10};
    }
    &:disabled {
      color: ${(props) => props.theme.color.textDimed};
    }
    &:hover {
      text-decoration: underline;
    }
  `,
  transparentPurple: css`
    color: ${(props) => props.theme.color.textSub};
    border: 1px solid transparent;
    background-color: transparent;
  `,
};

export const ButtonStyle = styled.button<ButtonProps>`
  display: flex;
  align-items: center;
  justify-content: center;
  width: auto;
  color: ${(props) => props.theme.color.white};
  margin: 0;
  line-height: 20px;
  font-weight: 500;
  border-radius: 4px;
  transition: all 150ms;
  cursor: pointer;
  ${(props) => size[props.$size]};
  ${(props) => variant[props.$variant]};

  > span {
    padding-left: ${(props) =>
      props.$icon ? '6px' : props.iconOnly ? '0' : ''};
  }

  &:disabled {
    pointer-events: none;
  }

  &::before {
    content: '';
    display: ${(props) => (props.$icon ? 'inline-block' : 'none')};
    width: 20px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: cover;
    background-image: ${(props) =>
      props.download ? `url(${DownloadIcon})` : ''};
  }
`;

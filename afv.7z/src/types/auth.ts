export interface LoginBody {
  username: string;
  password: string;
}

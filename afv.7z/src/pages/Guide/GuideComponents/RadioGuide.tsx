import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Radio from 'common/Radio/Radio';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const RadioGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Radio</GuideText>
        <GuideBox>
          <div>
            <Radio
              id="radio01"
              name="radio01"
              htmlFor="radio01"
              defaultChecked
            />
            <Radio
              id="radio02"
              name="radio02"
              htmlFor="radio02"
              defaultChecked
              disabled
            />
            <Radio id="radio03" name="radio03" htmlFor="radio03" />
            <Radio id="radio04" name="radio04" htmlFor="radio04" disabled />
          </div>
          <div>
            <Radio
              id="radio05"
              name="radio05"
              text="Label"
              htmlFor="radio05"
              defaultChecked
            />
            <Radio
              id="radio06"
              name="radio06"
              text="Label"
              htmlFor="radio06"
              defaultChecked
              disabled
            />
            <Radio id="radio07" name="radio07" text="Label" htmlFor="radio07" />
            <Radio
              id="radio08"
              name="radio08"
              text="Label"
              htmlFor="radio08"
              disabled
            />
          </div>
          <div>
            <Radio
              id="radio09"
              name="radio09"
              htmlFor="radio09"
              defaultChecked
              large
            />
            <Radio
              id="radio10"
              name="radio10"
              htmlFor="radio10"
              large
              defaultChecked
              disabled
            />
            <Radio id="radio11" name="radio11" htmlFor="radio11" large />
            <Radio
              id="radio12"
              name="radio12"
              htmlFor="radio12"
              large
              disabled
            />
          </div>
          <div>
            <Radio
              id="radio13"
              name="radio13"
              text="Label"
              htmlFor="radio13"
              large
              defaultChecked
            />
            <Radio
              id="radio14"
              name="radio14"
              text="Label"
              htmlFor="radio14"
              large
              defaultChecked
              disabled
            />
            <Radio
              id="radio15"
              name="radio15"
              text="Label"
              htmlFor="radio15"
              large
            />
            <Radio
              id="radio16"
              name="radio16"
              text="Label"
              htmlFor="radio16"
              large
              disabled
            />
          </div>
        </GuideBox>
        <GuideSubBox>
          &lt;Radio id="" text="" name="" htmlFor="" defaultChecked large /&gt;{' '}
          <br />
          &lt;Radio id="" text="" name="" htmlFor="" defaultChecked disabled
          large /&gt; <br />
          &lt;Radio id="" text="" name="" htmlFor="" large /&gt; <br />
          &lt;Radio id="" text="" name="" htmlFor="" disabled large /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default RadioGuide;

import GuideBox from './GuideBox/GuideBox';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideText from './GuideBox/GuideText';
import GuideTable from './GuideTable';
import { StyledGuideWrapper, StyledWrapper } from './GuideBox/GuideWrapper';
import Accordion from 'common/Accordion';

const AccordionGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Accordion</GuideText>
        <GuideBox>
          <Accordion title="기본 정보 닫힘 상태">
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
          </Accordion>

          <Accordion title="기본 정보 열림 상태" open>
            props - open: boolean 추가
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
          </Accordion>

          <Accordion title="EVSE /  커넥터 정보" $marginTop="40px">
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
          </Accordion>

          <Accordion title="네트워크 정보" $marginTop="40px">
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
            content
            <br />
          </Accordion>
        </GuideBox>
        <GuideSubBox>
          &lt;Accordion title="타이틀" $marginTop="40px"&gt; 컨텐츠
          &lt;/Accordion&gt;
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>title</td>
              <td>title="타이틀"</td>
              <td>Accordion header title</td>
              <td></td>
            </tr>
            <tr>
              <td>$marginTop</td>
              <td>$marginTop="40px"</td>
              <td>accordion과 컨텐츠 간의 간격 정의</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default AccordionGuide;

import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import FilterLabel from 'common/Filter/FilterLabel';
import TextField from 'common/TextField';
import Select from 'common/Select/Select';
import Dropdown from 'common/Dropdown/Dropdown';
import SelectSearch from 'common/SelectSearch/';
import { DropdownWrap } from 'common/Dropdown/StyledDropdown';
import { filterOption, selectSearchFilterOption } from './data';

const FilterListComponent: React.FC = () => {
  return (
    <FilterList useDetailButtons>
      <FilterItem $search>
        <TextField
          id="TextField01"
          name="text"
          type="text"
          placeholder="충전소 이름으로 검색"
          $search
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>사업자 :</FilterLabel>
        <SelectSearch
          $menuTitle="사업자"
          placeholder="사업자 이름"
          isMulti
          options={selectSearchFilterOption}
          defaultValue={selectSearchFilterOption[0]}
          classNamePrefix="react-select"
          $button
          $transparent
          $checkbox
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>권역 :</FilterLabel>
        <Select
          options={filterOption}
          defaultValue={filterOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>충전소 유형 :</FilterLabel>
        <Select
          options={filterOption}
          defaultValue={filterOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>시설 형태 :</FilterLabel>
        <Select
          options={filterOption}
          defaultValue={filterOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>시설 구분 :</FilterLabel>
        <Select
          options={filterOption}
          defaultValue={filterOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>개방 형태 :</FilterLabel>
        <Select
          options={filterOption}
          defaultValue={filterOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>등록 기간 :</FilterLabel>
        <DropdownWrap>
          <Dropdown
            options={filterOption}
            $allText="전체"
            placeholder="전체"
            $day
            $transparent
          />
        </DropdownWrap>
      </FilterItem>
    </FilterList>
  );
};

export default FilterListComponent;

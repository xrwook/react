import React from 'react';
import styled from 'styled-components';

interface GridProps {
  $columns?: number;
  $gap?: string;
  margin?: string;
  width?: string;
  children?: React.ReactNode;
}

const Grid = styled.div<GridProps>`
  display: grid;
  align-items: flex-start;
  grid-template-columns: repeat(${(props) => props.$columns || 1}, 1fr);
  gap: ${(props) => props.$gap || '12px 20px'};
  margin: ${(props) => props.margin || '0 auto'};
  width: ${(props) => props.width || '100%'};
`;

interface GridContainerProps extends GridProps {
  children: React.ReactNode;
}

const GridContainer: React.FC<GridContainerProps> = ({
  children,
  $columns,
  $gap,
  margin,
  width,
}) => {
  return (
    <Grid $columns={$columns} $gap={$gap} width={width} margin={margin}>
      {children}
    </Grid>
  );
};

export default GridContainer;

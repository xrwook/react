import { useState } from 'react';
import {
  DeleteButton,
  InputText,
  InputWrapper,
  SearchButton,
  ErrorMessage,
  VerifiedMessage,
  InnerRight,
} from './StyledTextField';

export interface TextFieldProps {
  type?: any;
  id?: any;
  name?: any;
  placeholder?: any;
  disabled?: any;
  readOnly?: any;
  $error?: boolean;
  $verified?: boolean;
  $inputValue?: any;
  value?: any;
  $search?: any;
  $errorMessage?: string;
  $verifiedMessage?: string;
  $innerRight?: string;
  $width?: string;
  $height?: string;
}

const TextField: React.FC<TextFieldProps> = ({
  type,
  id,
  name,
  placeholder,
  disabled,
  readOnly,
  $error,
  $search,
  $errorMessage,
  $verifiedMessage,
  $verified,
  $innerRight,
  $width,
  $height,
  value = '',
}) => {
  const [inputValue, setInputValue] = useState(value);

  const handleClear = () => {
    setInputValue('');
  };

  return (
    <InputWrapper className={inputValue ? 'input-typing' : ''}>
      <InputText
        id={id}
        name={name}
        type={type}
        value={inputValue}
        $inputValue={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        disabled={disabled}
        readOnly={readOnly}
        placeholder={placeholder}
        $error={$error}
        $verified={$verified}
        $innerRight={$innerRight}
        $width={$width}
        $height={$height}
      />
      {inputValue && !disabled && !readOnly && !$innerRight && (
        <DeleteButton
          onClick={handleClear}
          $search={$search}
          $errorMessage={$errorMessage}
          $verifiedMessage={$verifiedMessage}
        />
      )}
      <SearchButton
        $search={$search}
        disabled={disabled}
        readOnly={readOnly}
        $inputValue={inputValue}
      />
      {$error && $errorMessage && (
        <ErrorMessage>
          <span>{$errorMessage}</span>
        </ErrorMessage>
      )}
      {$verified && $verifiedMessage && (
        <VerifiedMessage>
          <span>{$verifiedMessage}</span>
        </VerifiedMessage>
      )}
      {$innerRight && (
        <InnerRight
          // $inputValue={inputValue}
          readOnly={readOnly}
          disabled={disabled}
          value={inputValue}
        >
          {$innerRight}
        </InnerRight>
      )}
    </InputWrapper>
  );
};

export default TextField;

import { components } from 'react-select';

const CustomInput = (props: any) => {
  return (
    <components.Input
      {...props}
      id={props.selectProps.inputId}
      name={props.selectProps.name}
    />
  );
};

export default CustomInput;

import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import CircleProgressBar from 'common/CircleProgressBar/CircleProgressBar';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const CircleProgressBarGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>CircleProgressBar</GuideText>
        <GuideBox>
          <CircleProgressBar
            $widthSize={60}
            $heightSize={60}
            $statusColor={'red'}
            $strokeWidth={4}
            title="고장률"
            currentValue={100}
            total={200}
          />
        </GuideBox>
        <GuideSubBox>&lt;CircleProgressBar /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default CircleProgressBarGuide;

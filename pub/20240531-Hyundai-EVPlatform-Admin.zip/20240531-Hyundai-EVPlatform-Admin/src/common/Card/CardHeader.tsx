import Button from 'common/Button';
import { CardHeaderLayout } from './StyledCard';

export interface CardHeaderProps {
  children?: any;
}

const CardHeader: React.FC<CardHeaderProps> = ({ children }) => {
  return (
    <CardHeaderLayout>
      {children}
      <Button onClick={() => {}} $size="mini" $variant="secondaryGray">
        Reset
      </Button>
    </CardHeaderLayout>
  );
};

export default CardHeader;

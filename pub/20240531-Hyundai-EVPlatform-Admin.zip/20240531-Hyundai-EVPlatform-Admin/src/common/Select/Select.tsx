import React, { useState, useEffect } from 'react';
import { components } from 'react-select';
import { MenuFooter, SelectStyle, ArrowButton } from './StyledSelect';
import Button from 'common/Button';
import CustomInput from 'common/CustomInput';
import CustomOption from 'common/CustomOption';
import DefaultOption from 'common/DefaultOption';

export type Option = {
  value: number | string;
  label: string;
};

export interface SelectProps {
  options?: any;
  placeholder?: any;
  isMulti?: any;
  hideSelectedOptions?: any;
  className?: any;
  title?: any;
  classNamePrefix: string;
  defaultValue?: any;
  required?: any;
  disabled?: any;
  readonly?: any;
  error?: any;
  name?: any;
  inputId?: any;
  $transparent?: any;
  components?: any;
  isSelectAll?: any;
  value?: any;
  onChange?: any;
  menuTitle?: any;
  menuPortalTarget?: any;
  $button?: any;
  $checkbox?: any;
  $menuPosition?: any;
  $all?: boolean;
  $height?: any;
}

const Select: React.FC<SelectProps> = ({
  placeholder,
  isMulti,
  hideSelectedOptions,
  className,
  classNamePrefix,
  defaultValue,
  disabled,
  inputId,
  name,
  readonly,
  $transparent,
  $button,
  $checkbox,
  onChange,
  value,
  $all,
  $height,
  menuPortalTarget,
  ...props
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<Option[]>(
    value || defaultValue || [],
  );

  useEffect(() => {
    if (value !== undefined) {
      setSelectedOptions(value);
    }
  }, [value]);

  const [isOpen, setIsOpen] = useState(false);

  const allOption = { value: '*', label: '전체' };
  const optionsWithAll = $all ? [allOption, ...props.options] : props.options;

  const handleChange = (selected: Option[]) => {
    const selectionArray = Array.isArray(selected) ? selected : [];
    if (selectionArray.some((option) => option.value === allOption.value)) {
      const allSelected = selectedOptions.length === props.options.length;
      setSelectedOptions(allSelected ? [] : [...props.options]);
    } else {
      setSelectedOptions(selected);
    }

    if (onChange) {
      onChange(selectedOptions);
    }
    if (!isMulti) {
      handleMenuClose();
    }
  };

  const handleApply = () => {
    if (onChange) {
      onChange(selectedOptions);
    }
    handleMenuClose();
  };

  const handleReset = () => {
    setSelectedOptions([]);
    if (onChange) {
      onChange([]);
    }
    handleMenuClose();
  };

  const handleMenuOpen = () => {
    setIsMenuOpen(true);
    setIsOpen(true);
  };

  const handleMenuClose = () => {
    setIsMenuOpen(false);
    setIsOpen(false);
  };

  const DropdownIndicator = (props: any) => {
    return (
      <components.DropdownIndicator {...props}>
        <ArrowButton $isOpen={isOpen} />
      </components.DropdownIndicator>
    );
  };

  const Menu = (props: any) => (
    <components.Menu {...props}>
      {props.children}
      <MenuFooter $button={$button}>
        <Button onClick={handleReset} $size="small" $variant="transparent">
          초기화
        </Button>
        <Button
          onClick={handleApply}
          $size="small"
          $variant="transparentPurple"
        >
          적용
        </Button>
      </MenuFooter>
    </components.Menu>
  );

  return (
    <SelectStyle
      {...props}
      inputId={inputId}
      name={name}
      placeholder={placeholder}
      isMulti={isMulti}
      closeMenuOnSelect={!isMulti}
      options={optionsWithAll}
      hideSelectedOptions={hideSelectedOptions}
      className={`${className || ''}`}
      classNamePrefix={classNamePrefix}
      defaultValue={defaultValue}
      isDisabled={disabled}
      menuIsOpen={isMenuOpen}
      menuPortalTarget={menuPortalTarget}
      onMenuOpen={handleMenuOpen}
      onMenuClose={handleMenuClose}
      readonly={readonly}
      $transparent={$transparent}
      $height={$height}
      components={{
        DropdownIndicator,
        Input: CustomInput,
        Option: $checkbox ? CustomOption : DefaultOption,
        Menu: Menu,
        ...props.components,
      }}
      onChange={handleChange}
      value={selectedOptions}
    />
  );
};

export default Select;

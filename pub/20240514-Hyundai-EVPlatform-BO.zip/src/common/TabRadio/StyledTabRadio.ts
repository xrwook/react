import styled from 'styled-components';
import { TabRadioItemProps } from './TabRadioItem';

export const TabRadioWrapper = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  border-radius: 4px;
`;

export const TabRadio = styled.div`
  position: relative;
  width: 100%;
  height: 32px;
  text-align: center;
`;

export const TabRadioButton = styled.input<TabRadioItemProps>`
  appearance: none;
  width: 100%;
  height: 32px;
  padding: 5px 0;
  margin: 0;
  border: 1px solid ${(props) => props.theme.color.gray3};
  border-right: ${(props) =>
    props.$borderlast ? '1px solid `${props.theme.color.gray3}`' : 'none'};
  border-top-right-radius: ${(props) => (props.$borderlast ? '4px' : '')};
  border-bottom-right-radius: ${(props) => (props.$borderlast ? '4px' : '')};
  border-top-left-radius: ${(props) => (props.$borderfirst ? '4px' : '')};
  border-bottom-left-radius: ${(props) => (props.$borderfirst ? '4px' : '')};

  &:checked {
    border: 1px solid ${(props) => props.theme.color.primary};
    background-color: ${(props) => props.theme.color.primary};
  }
  &:checked + label {
    color: #fff;
    font-weight: 500;
  }

  &:hover {
    border: 1px solid ${(props) => props.theme.color.gray4};
    background-color: ${(props) => props.theme.color.gray1};
  }

  &:hover + label {
    color: ${(props) => props.theme.color.gray8};
  }
`;

export const TabRadioLabel = styled.label<TabRadioItemProps>`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 14px;
  line-height: 20px;
  color: ${(props) => props.theme.color.gray8};
  white-space: nowrap;
`;

import styled from 'styled-components';

const RadioboxWrapper = styled.div`
  display: flex;
  align-items: center;
  vertical-align: middle;
`;

const StyledRadio = styled.input<RadioBoxProps>`
  appearance: none;
  position: relative;
  display: inline-block;
  width: ${(props) => (props.large ? '20px' : '16px')};
  height: ${(props) => (props.large ? '20px' : '16px')};
  border-radius: 50%;
  transition: all 150ms;
  border: 1px solid #caccd7;
  background-color: ${(props) => props.theme.color.white};
  background-repeat: no-repeat;
  background-size: contain;

  &:after {
    content: '';
    opacity: 0;
    transition: opacity 0.2s;
    position: absolute;
    border-radius: 50%;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: ${(props) => (props.large ? '10px' : '8px')};
    height: ${(props) => (props.large ? '10px' : '8px')};
    background-color: ${(props) => props.theme.color.primary};
  }

  &:checked {
    border: 1px solid ${(props) => props.theme.color.primary};
    &:after {
      opacity: 1;
    }
  }

  &:checked:hover {
    opacity: 0.6;
  }

  &:checked:disabled {
    border: 1px solid ${(props) => props.theme.color.gray4};
    opacity: 1;

    &:after {
      background-color: ${(props) => props.theme.color.gray4};
    }
  }

  &:disabled {
    border: 1px solid #dbdde5;
    background-color: #f5f6fa;
  }
`;

const StyledRadioBoxText = styled.span<RadioBoxProps>`
  margin-left: 8px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => (props.disabled ? '#cdcdcd' : '#434860')};
  line-height: 20px;
  font-weight: 400;
`;

export interface RadioBoxProps {
  id?: string;
  name?: any;
  text?: any;
  htmlFor?: any;
  disabled?: any;
  checked?: any;
  className?: any;
  defaultChecked?: any;
  large?: any;
}

const Radio: React.FC<RadioBoxProps> = ({
  id,
  name,
  text,
  htmlFor,
  disabled,
  checked,
  className,
  defaultChecked,
  large = false,
}) => {
  return (
    <>
      <RadioboxWrapper>
        <StyledRadio
          type="radio"
          id={id}
          name={name}
          disabled={disabled}
          checked={checked}
          defaultChecked={defaultChecked}
          className={className}
          large={large ? 'true' : undefined}
        />
        <label htmlFor={htmlFor}>
          {text && (
            <StyledRadioBoxText disabled={disabled}>{text}</StyledRadioBoxText>
          )}
        </label>
      </RadioboxWrapper>
    </>
  );
};

export default Radio;

import Title from 'common/Title/Title';
import Header from 'layout/Header';
import AgGrid from 'common/AgGrid';
import FilterChargingStationStatusList from '../components/FilterChargingStationStatusList';
import {
  ChargingStationStatusListrowData,
  ChargingStationStatusListcolumnDefs,
  listPerPageSelectOption,
} from '../components/data';

const ChargingStationStatusListContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '서비스 운영 관리' },
    { to: '/', text: '충전소 현황', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="충전소 현황"
        $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
      />

      <FilterChargingStationStatusList />

      <AgGrid
        rowData={ChargingStationStatusListrowData}
        columnDefs={ChargingStationStatusListcolumnDefs}
        hasPaging={true}
        hasGridTop={true}
        listPerPageSelectOption={listPerPageSelectOption}
        listPerPageDefaultOption={{
          value: '20',
          label: '20개씩보기',
        }}
      />
    </>
  );
};

export default ChargingStationStatusListContainer;

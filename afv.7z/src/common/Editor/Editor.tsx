import styled from 'styled-components';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const EditorStyled = styled(ReactQuill)<{ height?: string }>`
  height: ${(props) => props.height};
`;

export interface EditorProps {
  height?: string;
}

const Editor: React.FC<EditorProps> = ({ height }) => {
  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike', 'blockquote'],
      [{ align: ['right', 'center', 'justify'] }],
      [{ list: 'ordered' }, { list: 'bullet' }],
      ['link', 'image'],
      [{ color: [] }],
      [{ background: [] }],
    ],
  };

  const formats = [
    'header',
    'bold',
    'italic',
    'underline',
    'strike',
    'blockquote',
    'list',
    'bullet',
    'link',
    'color',
    'image',
    'background',
    'align',
  ];

  return (
    <EditorStyled
      theme="snow"
      modules={modules}
      formats={formats}
      placeholder="내용을 입력해주세요."
      height={height}
    />
  );
};

export default Editor;

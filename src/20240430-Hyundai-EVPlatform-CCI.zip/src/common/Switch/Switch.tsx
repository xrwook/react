import React, { useState } from 'react';
import styled from 'styled-components';

const SwitchWrapper = styled.label`
  position: relative;
  display: inline-block;
  width: 34px;
  height: 20px;
`;

const Slider = styled.span`
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: 0.4s;
  border-radius: 34px;

  &:before {
    position: absolute;
    content: '';
    height: 16px;
    width: 16px;
    left: 3px;
    top: 50%;
    margin-top: -8px;
    background-color: white;
    transition: 0.2s;
    border-radius: 50%;
  }
`;

const Checkbox = styled.input`
  opacity: 0;
  width: 0;
  height: 0;

  &:checked + ${Slider} {
    background-color: #2196f3;
  }

  &:focus + ${Slider} {
    box-shadow: 0 0 1px #2196f3;
  }

  &:checked + ${Slider}:before {
    transform: translateX(12px);
  }
`;

const Switch: React.FC<{
  id?: string;
  name?: string;
  checked?: boolean;
  disabled?: boolean;
  defaultChecked?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({ id, name, defaultChecked, disabled, onChange }) => {
  const [isChecked, setIsChecked] = useState(defaultChecked || false);

  const handleToggle = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsChecked(event.target.checked);
    if (onChange) {
      onChange(event);
    }
  };

  return (
    <SwitchWrapper>
      <Checkbox
        id={id}
        name={name}
        type="checkbox"
        disabled={disabled}
        defaultChecked={isChecked}
        onChange={handleToggle}
      />
      <Slider />
    </SwitchWrapper>
  );
};

export default Switch;

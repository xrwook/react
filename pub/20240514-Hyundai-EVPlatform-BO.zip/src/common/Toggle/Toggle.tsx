import { Input, Label, Switch, ToggleWrapper } from './StyledToggle';

export interface ToggleProps {
  disabled?: any;
  label?: any;
  checked?: any;
  defaultChecked?: any;
  onChange?: any;
}

const Toggle: React.FC<ToggleProps> = ({
  disabled,
  label,
  defaultChecked,
  checked,
  onChange,
}) => {
  return (
    <ToggleWrapper>
      <Input
        checked={checked}
        type="checkbox"
        onChange={onChange}
        disabled={disabled}
        defaultChecked={defaultChecked}
      />
      <Switch />
      {label && <Label disabled={disabled}>{label}</Label>}
    </ToggleWrapper>
  );
};

export default Toggle;

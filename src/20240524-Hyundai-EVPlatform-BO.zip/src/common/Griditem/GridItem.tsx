import styled from 'styled-components';

interface GridItemProps {
  $colStart?: number;
  $colEnd?: number;
  children: React.ReactNode;
  $gap?: string;
}

const GridItemContainer = styled.div<GridItemProps>`
  grid-column: ${(props) => props.$colStart || 'auto'} /
    ${(props) => props.$colEnd || 'auto'};

  gap: ${(props) => props.$gap || '0'};
`;

const GridItem: React.FC<GridItemProps> = ({
  $colStart,
  $colEnd,
  children,
  $gap,
}) => {
  return (
    <GridItemContainer $colStart={$colStart} $colEnd={$colEnd} $gap={$gap}>
      {children}
    </GridItemContainer>
  );
};

export default GridItem;

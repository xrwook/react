export { default } from './FullContents';

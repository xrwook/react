import styled from 'styled-components';

export const HeaderBox = styled.div`
  display: flex;
  align-items: center;
`;

export const HeaderWrap = styled.header`
  display: flex;
  align-items: center;
  width: 100%;
  min-width: 280px;
  min-height: 48px;
  padding: 12px 21px;
  box-sizing: border-box;
  background-color: #fff;
`;

export const Logo = styled.div`
  font-size: ${(props) => props.theme.fontSize.fontSize8};
  color: #000;
`;

export const Menu = styled.nav`
  margin-left: auto;
`;

export const MenuIList = styled.ul`
  display: flex;
  align-items: center;
`;

export const MenuItem = styled.li`
  position: relative;
  padding-left: 15px;
  cursor: pointer;
  white-space: nowrap;

  &::before {
    content: '';
    display: block;
    position: absolute;
    z-index: 1;
    top: 50%;
    left: 6px;
    margin-top: -6px;
    width: 1px;
    height: 12px;
    background-color: #000;
  }
  &:first-child::before {
    display: none;
  }
`;

export const MenuLink = styled.a`
  color: #000;
  text-decoration: underline;
`;

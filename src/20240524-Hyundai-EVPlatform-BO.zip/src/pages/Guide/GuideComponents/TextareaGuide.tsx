import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Textarea from 'common/Textarea/Textarea';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TextareaGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Textarea</GuideText>
        <GuideBox>
          <Textarea
            id="textarea01"
            name="text"
            height="100px"
            placeholder="Enter long form text here"
          />
          <Textarea
            id="textarea02"
            name="readOnly"
            height="100px"
            placeholder="Enter long form text here"
            value="readOnly"
            readOnly
          />
          <Textarea
            id="textarea03"
            name="disabled"
            height="100px"
            placeholder="Enter long form text here"
            value="disabled"
            disabled
          />
          <Textarea
            id="textarea04"
            name="error"
            height="100px"
            defaultValue="Enter long form text here"
            $error
            $errorMessage="Invaild message content"
          />
        </GuideBox>
        <GuideSubBox>
          {`<Textarea
            id="textarea04"
            name="error"
            height="100px"
            placeholder="Enter long form text here"
            defaultValue="Enter long form text here"
            readOnly
            disabled
            $error
            $errorMessage="Invaild message content"
          />`}
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>height</td>
              <td>height="100px"</td>
              <td>높이값 지정</td>
              <td></td>
            </tr>
            <tr>
              <td>defaultValue</td>
              <td>defaultValue="Enter long form text here"</td>
              <td>placeholder 외 기본 값</td>
              <td></td>
            </tr>
            <tr>
              <td>readOnly</td>
              <td>readOnly</td>
              <td>읽기만 가능</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성화 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$error</td>
              <td>$error</td>
              <td>error 디자인 적용</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$errorMessage</td>
              <td>$errorMessage="Invaild message content"</td>
              <td>error message</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TextareaGuide;

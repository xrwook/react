import { useState, useRef } from 'react';
import { components, InputAction } from 'react-select';
import { SelectStyle } from './StyledSelectAllCheck';
import { MenuFooter } from 'common/Select/StyledSelect';
import Button from 'common/Button/Button';

export type Option = {
  value: number | string;
  label: string;
};

export interface SelectAllCheckProps {
  options?: any;
  value?: any;
  onChange?: any;
  isSelectAll?: any;
  components?: any;
  menuPlacement?: any;
  disabled?: any;
  placeholder?: any;
  readonly?: any;
  isMulti?: any;
  hideSelectedOptions?: any;
  classNamePrefix: string;
  defaultValue?: any;
  $transparent?: any;
  $button?: any;
}

const SelectAllCheck: React.FC<SelectAllCheckProps> = ({
  readonly,
  placeholder,
  disabled,
  isMulti,
  hideSelectedOptions,
  classNamePrefix,
  defaultValue,
  $transparent,
  $button,
  ...props
}) => {
  const [selectInput, setSelectInput] = useState<string>('');
  const isAllSelected = useRef<boolean>(false);
  const selectAllLabel = useRef<string>('전체');
  const allOption = { value: '*', label: selectAllLabel.current };

  const filterOptions = (options: Option[], input: string) =>
    options?.filter(({ label }: Option) =>
      label.toLowerCase().includes(input.toLowerCase()),
    );

  const comparator = (v1: Option, v2: Option) =>
    (v1.value as number) - (v2.value as number);

  const filteredOptions = filterOptions(props.options, selectInput);
  const filteredSelectedOptions = filterOptions(props.value, selectInput);

  const Option = (props: any) => (
    <components.Option {...props}>
      {props.value === '*' &&
      !isAllSelected.current &&
      filteredSelectedOptions?.length > 0 ? (
        <input
          key={props.value}
          type="checkbox"
          className="checkbox"
          ref={(input) => {
            if (input) input.indeterminate = true;
          }}
        />
      ) : (
        <input
          key={props.value}
          type="checkbox"
          className="checkbox"
          checked={props.isSelected || isAllSelected.current}
          onChange={() => {}}
        />
      )}
      <label>{props.label}</label>
    </components.Option>
  );

  const Menu = (props: any) => (
    <components.Menu {...props}>
      {props.children}
      <MenuFooter $button={$button}>
        <Button onClick={() => {}} $size="small" $variant="transparent">
          초기화
        </Button>
        <Button onClick={() => {}} $size="small" $variant="transparentPurple">
          적용
        </Button>
      </MenuFooter>
    </components.Menu>
  );

  const Input = (props: any) => (
    <>
      {selectInput.length === 0 ? (
        <components.Input autoFocus={props.selectProps.menuIsOpen} {...props}>
          {props.children}
        </components.Input>
      ) : (
        <components.Input autoFocus={props.selectProps.menuIsOpen} {...props}>
          {props.children}
        </components.Input>
      )}
    </>
  );

  const customFilterOption = ({ value, label }: Option, input: string) =>
    (value !== '*' && label.toLowerCase().includes(input.toLowerCase())) ||
    (value === '*' && filteredOptions?.length > 0);

  const onInputChange = (
    inputValue: string,
    event: { action: InputAction },
  ) => {
    if (event.action === 'input-change') setSelectInput(inputValue);
    else if (event.action === 'menu-close' && selectInput !== '')
      setSelectInput('');
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLElement>) => {
    if ((e.key === ' ' || e.key === 'Enter') && !selectInput)
      e.preventDefault();
  };

  const onChange = (selected: Option[]) => {
    if (
      selected.length > 0 &&
      !isAllSelected.current &&
      (selected[selected.length - 1].value === allOption.value ||
        JSON.stringify(filteredOptions) ===
          JSON.stringify(selected.sort(comparator)))
    )
      return props.onChange(
        [
          ...(props.value ?? []),
          ...props.options.filter(
            ({ label }: Option) =>
              label.toLowerCase().includes(selectInput?.toLowerCase()) &&
              (props.value ?? []).filter((opt: Option) => opt.label === label)
                .length === 0,
          ),
        ].sort(comparator),
      );
    else if (
      selected.length > 0 &&
      selected[selected.length - 1].value !== allOption.value &&
      JSON.stringify(selected.sort(comparator)) !==
        JSON.stringify(filteredOptions)
    )
      return props.onChange(selected);
    else
      return props.onChange([
        // eslint-disable-next-line no-unsafe-optional-chaining
        ...props.value?.filter(
          ({ label }: Option) =>
            !label.toLowerCase().includes(selectInput?.toLowerCase()),
        ),
      ]);
  };

  const customStyles = {
    option: (styles: any, { isSelected, isFocused }: any) => {
      return {
        ...styles,
        backgroundColor:
          isSelected && !isFocused
            ? null
            : isFocused && !isSelected
              ? styles.backgroundColor
              : isFocused && isSelected
                ? ''
                : null,
        color: isSelected ? null : null,
      };
    },
    menu: (def: any) => ({ ...def, zIndex: 9999 }),
  };

  if (props.isSelectAll && props.options.length !== 0) {
    isAllSelected.current =
      JSON.stringify(filteredSelectedOptions) ===
      JSON.stringify(filteredOptions);

    selectAllLabel.current = '전체';

    allOption.label = selectAllLabel.current;

    return (
      <SelectStyle
        {...props}
        inputValue={selectInput}
        onInputChange={onInputChange}
        onKeyDown={onKeyDown}
        options={[allOption, ...props.options]}
        onChange={onChange}
        components={{
          Option: Option,
          Input: Input,
          Menu: Menu,
          ...props.components,
        }}
        filterOption={customFilterOption}
        menuPlacement={props.menuPlacement ?? 'auto'}
        styles={customStyles}
        isMulti
        closeMenuOnSelect={false}
        tabSelectsValue={false}
        backspaceRemovesValue={false}
        hideSelectedOptions={false}
        blurInputOnSelect={false}
        isDisabled={disabled}
        placeholder={placeholder}
        readonly={readonly}
        classNamePrefix={classNamePrefix}
        defaultValue={defaultValue}
        menuIsOpen={readonly ? false : undefined}
        $transparent={$transparent}
      />
    );
  }

  return (
    <SelectStyle
      {...props}
      inputValue={selectInput}
      onInputChange={onInputChange}
      filterOption={customFilterOption}
      components={{
        Input: Input,
        ...props.components,
      }}
      menuPlacement={props.menuPlacement ?? 'auto'}
      onKeyDown={onKeyDown}
      tabSelectsValue={false}
      backspaceRemovesValue={false}
      blurInputOnSelect={true}
      isDisabled={disabled}
      placeholder={placeholder}
      readonly={readonly}
      isMulti={isMulti}
      hideSelectedOptions={hideSelectedOptions}
      classNamePrefix={classNamePrefix}
      defaultValue={defaultValue}
      menuIsOpen={readonly ? false : undefined}
      $transparent={$transparent}
    />
  );
};

export default SelectAllCheck;

import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import AgGrid from 'common/AgGrid/AgGrid';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const AgGridGuide = () => {
  const columnDefs = [
    {
      headerName: '',
      checkboxSelection: true,
      headerCheckboxSelection: true,
      width: 52,
    },
    {
      headerName: 'Text',
      field: 'id',
      width: 88,
      editable: true,
    },
    { headerName: 'Text', field: 'name', width: 150 },
    {
      headerName: 'Text',
      field: 'name',
      width: 150,
    },
    { headerName: 'Text', field: 'name', width: 306, unSortIcon: true },
  ];

  const rowData = [
    {
      id: 1,
      name: 'John',
    },
    {
      id: 2,
      name: 'Alice',
    },
    {
      id: 3,
      name: 'Alice',
    },
    { id: 4, name: 'Alice' },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>AgGird</GuideText>
        <GuideBox>
          <AgGrid rowData={rowData} columnDefs={columnDefs} />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125;
        </GuideSubBox>
        <GuideBox>
          <AgGrid rowData={rowData} columnDefs={columnDefs} hasPaging={true} />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125; $hasPaging=&#123;true&#125; /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default AgGridGuide;

import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import TextField from 'common/TextField';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import FormFlex from 'common/FormFlex';
import Icon from 'common/Icon';
import { ButtonGroup } from 'common/Button/StyledButton';
import {
  FlexNone,
  Map,
  MapLocation,
  MapSearch,
} from '../styled/StyledChargingStations';
import Popover from 'common/Popover';

const ChargingStationsAddressSearchContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  const [showPopover, setShowPopover] = useState(false);

  return (
    <>
      {showModal && (
        <Modal width="800px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader>주소 검색</ModalHeader>
          <ModalContent $marginBottom="30px">
            {/* 지도 영역 */}
            <Map>
              <MapSearch>
                <TextField
                  id="TextField01"
                  name="text"
                  type="text"
                  placeholder="Address, Country, City or Postal code"
                  $search
                />
              </MapSearch>
              <MapLocation>
                {showPopover && (
                  <Popover
                    onClose={() => setShowPopover(false)}
                    style={{ top: '-149px', left: '-120px' }}
                  >
                    <span
                      style={{
                        color: '#212430',
                        lineHeight: '24px',
                        fontWeight: '600',
                      }}
                    >
                      Zip code:
                    </span>
                    <br />
                    80003
                    <div style={{ marginTop: '4xp' }}>
                      <span
                        style={{
                          color: '#212430',
                          lineHeight: '24px',
                          fontWeight: '600',
                        }}
                      >
                        Postal address:
                      </span>
                      <br />
                      6133, West 85th Place, Arvada,
                      <br />
                      Jefferson County, Colorado, 80003,
                      <br />
                      United States
                    </div>
                  </Popover>
                )}
                <Icon
                  $widthSize={48}
                  $heightSize={48}
                  $name={'icon-pin'}
                  onClick={() => setShowPopover(true)}
                >
                  위치
                </Icon>
              </MapLocation>
            </Map>
            {/* // */}

            {/* DD : 2항의 주소 선택시, 자동으로 입력 처리 (수정 불가) */}
            <Grid $columns={2} $gap="8px 8px">
              <GridItem $colStart={1} $colEnd={3}>
                <Formcontrol title="주소" required htmlFor="TextField02">
                  <FormFlex>
                    <FlexNone>
                      <TextField
                        id="TextField02"
                        name="text"
                        type="text"
                        value="Enter zip code"
                        $width="220"
                        disabled
                      />
                    </FlexNone>
                    <TextField
                      id="TextField02"
                      name="text"
                      type="text"
                      value="Enter address"
                      disabled
                    />
                  </FormFlex>
                </Formcontrol>
              </GridItem>
              {/* DD : 상세 주소 최대 50 글자까지 입력 가능 */}
              <GridItem $colStart={1} $colEnd={3}>
                <TextField
                  id="TextField03"
                  name="text"
                  type="text"
                  placeholder="Enter address detail"
                />
              </GridItem>
            </Grid>
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
                disabled
              >
                완료
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsAddressSearchContainer;

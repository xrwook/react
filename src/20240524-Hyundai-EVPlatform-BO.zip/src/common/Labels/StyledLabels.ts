import styled, { css } from 'styled-components';
import { LabelsProps } from './Labels';

const color = {
  red: css`
    color: #e52a40;
    background-color: #fef4f5;
  `,
  blue: css`
    color: #3089f0;
    background-color: #eef6fe;
  `,
  yellow: css`
    color: #f68534;
    background-color: #fff4ec;
  `,
  purple: css`
    color: #5c5cff;
    background-color: #f1f1ff;
  `,
  green: css`
    color: #47a357;
    background-color: #ebf5ed;
  `,
  gray: css`
    color: #8a8ab7;
    background-color: transparent;
  `,
  purpleDark: css`
    color: #5c5cff;
    background-color: #5252ff14;
  `,
  blueDark: css`
    color: #3089f0;
    background-color: #3089f014;
  `,
  redWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.textError};
  `,
  blueWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.blue};
  `,
  yellowWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.yellow};
  `,
  purpleWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.primary};
  `,
  greenWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.green};
  `,
  grayWhite: css`
    color: ${(props) => props.theme.color.white};
    background-color: ${(props) => props.theme.color.gray5};
  `,
};

const size = {
  default: css`
    height: 20px;
    padding: 0 6px;
    font-size: 11px;
  `,
  small: css`
    height: 18px;
    padding: 0 5px;
    font-weight: 500;
  `,
  medium: css`
    height: 24px;
    padding: 2px 6px;
  `,
};

export const LabelsWrapper = styled.div`
  display: inline-block;
`;

export const LabelStyle = styled.div<LabelsProps>`
  display: flex;
  align-items: center;
  justify-content: center;
  width: auto;
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  line-height: 20px;
  font-weight: 600;
  border-radius: 5px;
  ${(props) => color[props.$color]};
  ${(props) => size[props.$size]};
`;

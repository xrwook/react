import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Badge from 'common/Badges/Badge';
import Tooltip from 'common/Tooltip/Tooltip';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const BadgeGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Badge</GuideText>
        <GuideBox>
          <Tooltip
            message="This is a badge with tooltip"
            $direction="bottom"
            $auto
          >
            <Badge $blue>132</Badge>
          </Tooltip>
          <Badge $red>72</Badge>
          <Badge>0</Badge>
          <Badge $small $blue>
            36
          </Badge>
          <Badge $small $red>
            36
          </Badge>
          <Badge $small>0</Badge>
        </GuideBox>
        <GuideSubBox>&lt;Badge /&gt;</GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>$small</td>
              <td>$small</td>
              <td>small size</td>
              <td></td>
            </tr>
            <tr>
              <td>$blue</td>
              <td>$blue</td>
              <td>blue background</td>
              <td></td>
            </tr>
            <tr>
              <td>$red</td>
              <td>$red</td>
              <td>red background</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default BadgeGuide;

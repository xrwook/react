import styled from 'styled-components';

export const StyledGuideWrapper = styled.div`
  width: 100%;
  height: 100vh;
`;
export const StyledWrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding: 20px;
`;
export const StyledDivide = styled.hr`
  margin: 20px 0 30px;
  color: ${(props) => props.theme.color.gray2};
  border-style: dashed;
`;

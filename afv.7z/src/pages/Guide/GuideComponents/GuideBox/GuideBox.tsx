import styled from 'styled-components';
import React from 'react';

export interface StyledGuideBox {
  children?: React.ReactNode;
}

const StyledGuideBox = styled.div`
  width: 100%;
  border: 1px solid ${(props) => props.theme.color.gray3};
  padding: 10px;
  box-sizing: border-box;
  border-radius: 8px;
`;

const GuideBox: React.FC<StyledGuideBox> = ({ children }) => {
  return <StyledGuideBox>{children}</StyledGuideBox>;
};

export default GuideBox;

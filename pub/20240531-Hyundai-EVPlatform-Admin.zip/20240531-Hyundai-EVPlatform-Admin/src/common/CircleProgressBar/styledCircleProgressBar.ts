import styled, { css } from 'styled-components';
import { CircleProgressBarProps } from './CircleProgressBar';

export const CircleProgressBarWrap = styled.div<CircleProgressBarProps>`
  width: ${(props) => props.$widthSize || 60}px;
  height: ${(props) => props.$heightSize || 60}px;
  position: relative;

  svg {
    width: 100%;
    height: 100%;
  }

  .circle-progress {
    transform: rotate(-90deg);
  }

  .circle-progress__inner,
  .circle-progress__outer {
    fill: none;
  }

  .circle-progress__inner {
    stroke: ${(props) => props.theme.color.gray1};
  }

  .circle-progress__outer {
    stroke: ${(props) => props.$statusColor === 'red' && props.theme.color.red};
    stroke-linecap: round;
  }

  .circle-info {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    &__title {
      font-size: 10px;
      font-weight: 500;
      color: #434860;
      line-height: 16px;
    }

    &__percent {
      font-size: ${(props) => props.theme.fontSize.fontSize4};
      font-weight: 600;
      line-height: 18px;
      color: ${(props) =>
        props.$statusColor === 'red' && props.theme.color.red};
    }
  }
`;

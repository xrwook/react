import { IconStyle } from './StyledIcon';

export interface IconProps {
  $name?: string;
  $widthSize?: number;
  $heightSize?: number;
  children?: any;
}

const Icon: React.FC<IconProps> = ({
  $name,
  $widthSize,
  $heightSize,
  children,
}) => {
  return (
    <IconStyle $name={$name} $widthSize={$widthSize} $heightSize={$heightSize}>
      {children && <span className="blind-text">{children}</span>}
    </IconStyle>
  );
};

export default Icon;

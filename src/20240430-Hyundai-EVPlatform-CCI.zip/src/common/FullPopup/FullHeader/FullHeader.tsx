import React from 'react';
import styled from 'styled-components';
import PopupButton, { ButtonIconProps } from 'common/PopupButton/PopupButton';

const FullHeaderWrapper = styled.div<{ $isOpen: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px;
`;

const FullIconRight = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;

const FullIconLeft = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const FullTitle = styled.h2`
  flex: 1;
  font-size: ${(props) => props.theme.fontSize.fontSize7};
  text-align: center;
`;

export interface FullHeaderProps {
  onClose: () => void;
  leftIcon?: ButtonIconProps;
  rightIcon?: ButtonIconProps;
  children?: React.ReactNode;
}

const FullHeader: React.FC<FullHeaderProps> = ({
  onClose,
  leftIcon,
  rightIcon,
  children,
}) => {
  return (
    <FullHeaderWrapper $isOpen={false}>
      <FullIconLeft>
        {leftIcon && <PopupButton icon={leftIcon.icon} onClick={onClose} />}
      </FullIconLeft>
      <FullTitle>{children}</FullTitle>
      <FullIconRight>
        {rightIcon && <PopupButton icon={rightIcon.icon} onClick={onClose} />}
      </FullIconRight>
    </FullHeaderWrapper>
  );
};

export default FullHeader;

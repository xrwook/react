import { useState } from 'react';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import Modal from 'common/Modal/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';

const ModalGuide = () => {
  const [showModalFooter, setShowModalFooter] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showModalOversize, setShowModalOversize] = useState(false);
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Modal</GuideText>
        <GuideBox>
          <ButtonGroup $gap={6} $direction={'row'}>
            <Button
              $size="large"
              $variant="primary"
              onClick={() => setShowModal(true)}
            >
              Open Modal (기본)
            </Button>
            {showModal && (
              <Modal
                width="500px"
                height="auto"
                onClose={() => setShowModal(false)}
              >
                <ModalHeader>Title</ModalHeader>
                <ModalContent $marginBottom="25px">
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                </ModalContent>
                <ModalFooter>
                  <Button
                    onClick={() => setShowModal(false)}
                    $size="large"
                    $variant="secondaryBlue"
                  >
                    취소
                  </Button>
                  <Button onClick={() => {}} $size="large" $variant="primary">
                    등록
                  </Button>
                </ModalFooter>
              </Modal>
            )}
            <Button
              $size="large"
              $variant="secondaryBlue"
              onClick={() => setShowModalFooter(true)}
            >
              Open Modal (footer 없음)
            </Button>
            {showModalFooter && (
              <Modal
                width="500px"
                height="auto"
                onClose={() => setShowModalFooter(false)}
              >
                <ModalHeader>Title</ModalHeader>
                <ModalContent $marginBottom="30px">
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                </ModalContent>
              </Modal>
            )}

            <Button
              $size="large"
              $variant="tertiary"
              onClick={() => setShowModalOversize(true)}
            >
              Open Modal (oversize)
            </Button>
            {showModalOversize && (
              <Modal
                width="500px"
                height="auto"
                oversize
                onClose={() => setShowModalOversize(false)}
              >
                <ModalHeader>Title</ModalHeader>
                <ModalContent $marginBottom="25px">
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                  content
                  <br />
                </ModalContent>
                <ModalFooter>
                  <Button
                    onClick={() => setShowModalOversize(false)}
                    $size="large"
                    $variant="secondaryBlue"
                  >
                    취소
                  </Button>
                  <Button onClick={() => {}} $size="large" $variant="primary">
                    등록
                  </Button>
                </ModalFooter>
              </Modal>
            )}
          </ButtonGroup>
        </GuideBox>
        <GuideSubBox>
          &lt;Modal width="500px" height="auto" oversize onClose&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalHeader&gt;&lt;/ModalHeader&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalContent&gt;&lt;/ModalContent&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalFooter&gt;&lt;/ModalFooter&gt; <br />
          &lt;/Modal&gt;
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>width</td>
              <td>width="500px"</td>
              <td>모달 창의 넓이 값</td>
              <td></td>
            </tr>
            <tr>
              <td>height</td>
              <td>height="auto"</td>
              <td>모달 창의 높이 값</td>
              <td></td>
            </tr>
            <tr>
              <td>oversize</td>
              <td>oversize</td>
              <td>
                모달 창이 화면을 넓어갈 크기의 경우 화면 스크롤로 움직이도록
                처리
              </td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default ModalGuide;

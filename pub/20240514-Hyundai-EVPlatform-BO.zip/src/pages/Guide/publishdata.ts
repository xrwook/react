const publishdata = [
  {
    depth1: '충전소 운영 관리',
    below: [
      {
        id: 'CM_ChargingStations_List',
        depth2: '충전소 관리 (목록)',
        depth3: '',
        depth4: '',
        path: '/ChargingStationsList',
        status: '진행',
        create: '2023.05.14',
        update: '2023.05.14',
        log: [],
      },
    ],
  },
];

export default publishdata;

export { default } from './Home';

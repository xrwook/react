import { CardItemLayout } from './StyledCard';

export interface CardItemProps {
  children?: any;
}

const CardItem: React.FC<CardItemProps> = ({ children }) => {
  return <CardItemLayout>{children}</CardItemLayout>;
};

export default CardItem;

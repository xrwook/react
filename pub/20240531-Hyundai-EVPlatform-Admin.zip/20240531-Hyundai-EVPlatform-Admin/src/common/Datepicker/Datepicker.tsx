import { ReactDatePickerProps, registerLocale } from 'react-datepicker';
import { ko } from 'date-fns/locale/ko';
import 'react-datepicker/dist/react-datepicker.css';
import { useState } from 'react';
import {
  DatePickerStyle,
  DatePickerWrapper,
  DropDownContainer,
  DropDownHeader,
  DropDownList,
  DropDownListContainer,
  ListItem,
  NextButton,
  PrevButton,
} from './StyledDatepicker';
import { getMonth, getYear } from 'date-fns';
import _ from 'lodash';

registerLocale('ko', ko);

const DatePicker = ({ todayButton, ...props }: ReactDatePickerProps) => {
  const [isOpenMonths, setIsOpenMonths] = useState(false);
  const [isOpenYears, setIsOpenYears] = useState(false);
  const [selectedMonths, setSelectedMonths] = useState(null);
  const [selectedYears, setSelectedYears] = useState(null);

  const toggling = () => setIsOpenMonths(!isOpenMonths);
  const toggling2 = () => setIsOpenYears(!isOpenYears);

  const onMonthsClicked = (value: any) => () => {
    setSelectedMonths(value);
    setIsOpenMonths(false);
  };

  const onYearsClicked = (value: any) => () => {
    setSelectedYears(value);
    setIsOpenYears(false);
  };

  const years = _.range(1990, getYear(new Date()) + 1, 1);
  const months = [
    '1월',
    '2월',
    '3월',
    '4월',
    '5월',
    '6월',
    '7월',
    '8월',
    '9월',
    '10월',
    '11월',
    '12월',
  ];

  return (
    <DatePickerWrapper>
      <DatePickerStyle
        {...props}
        disabledKeyboardNavigation
        dateFormatCalendar="YYYY-MM-DD"
        placeholderText="yyyy/MM/dd"
        locale="ko"
        showMonthDropdown
        showYearDropdown
        dropdownMode="select"
        todayButton={todayButton}
        renderCustomHeader={({
          date,
          decreaseMonth,
          increaseMonth,
          prevMonthButtonDisabled,
          nextMonthButtonDisabled,
        }) => (
          <div
            style={{
              margin: 10,
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <PrevButton
              onClick={decreaseMonth}
              disabled={prevMonthButtonDisabled}
            />

            <DropDownContainer onClick={toggling2}>
              <DropDownHeader className={` ${isOpenYears ? 'open' : ''}`}>
                {selectedYears || [getYear(date)]}년
              </DropDownHeader>
              {isOpenYears && (
                <DropDownListContainer>
                  <DropDownList>
                    {years.map((option) => (
                      <ListItem
                        onClick={onYearsClicked(option)}
                        key={Math.random()}
                      >
                        {option}
                      </ListItem>
                    ))}
                  </DropDownList>
                </DropDownListContainer>
              )}
            </DropDownContainer>

            <DropDownContainer onClick={toggling}>
              <DropDownHeader className={` ${isOpenMonths ? 'open' : ''}`}>
                {selectedMonths || months[getMonth(date)]}
              </DropDownHeader>
              {isOpenMonths && (
                <DropDownListContainer>
                  <DropDownList>
                    {months.map((option) => (
                      <ListItem
                        onClick={onMonthsClicked(option)}
                        key={Math.random()}
                      >
                        {option}
                      </ListItem>
                    ))}
                  </DropDownList>
                </DropDownListContainer>
              )}
            </DropDownContainer>

            <NextButton
              onClick={increaseMonth}
              disabled={nextMonthButtonDisabled}
            />
          </div>
        )}
      />
    </DatePickerWrapper>
  );
};

export default DatePicker;

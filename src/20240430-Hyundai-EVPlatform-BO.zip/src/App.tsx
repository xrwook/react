import Router from './routes';
import Header from './common/Header';
import { findServiceTypeByUserAgent } from './utils/validation';
import { ThemeProvider } from 'styled-components';
import GlobalStyle from './style/assets/theme/globalStyle';
import theme from './style/assets/theme/theme';

export default function App() {
  console.log('userAgent:', navigator.userAgent);
  console.log('test:', findServiceTypeByUserAgent());
  return (
    <>
      <ThemeProvider theme={theme}>
        <GlobalStyle />
        <div className="App font-mono h-screen">
          <Header />
          <Router serviceType={findServiceTypeByUserAgent()} />
        </div>
      </ThemeProvider>
    </>
  );
}

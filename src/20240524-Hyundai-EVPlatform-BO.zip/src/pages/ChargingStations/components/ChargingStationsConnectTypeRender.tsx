import Icon from 'common/Icon/Icon';
import { RenderConnectType } from '../styled/StyledChargingStations';

export interface ChargingStationsConnectTypeRenderProps {
  connetType?: string | undefined;
}

const ChargingStationsConnectTypeRender: React.FC<
  ChargingStationsConnectTypeRenderProps
> = ({ connetType = '' }) => {
  const connetTypeMap: Record<string, string> = {
    'CCS Type2': 'CCS-Type2',
    CHAdeMO: 'CHAdeMO',
    'CCS Combo': 'CCS-Combo',
  };

  const typeResult: string = connetTypeMap[connetType] || '';
  return (
    <RenderConnectType>
      <Icon $name={'icon-' + typeResult} $widthSize={24} $heightSize={24} />
      {connetType}
    </RenderConnectType>
  );
};

export default ChargingStationsConnectTypeRender;

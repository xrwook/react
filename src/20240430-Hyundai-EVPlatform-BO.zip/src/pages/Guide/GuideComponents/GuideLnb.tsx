import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

// 임시 주석
// const datasOverView = [
//   {
//     title: 'Convention',
//     url: '/guidelist/convention',
//   },
// ];

const datasComponents = [
  {
    title: 'Breadcrumb',
    url: '/guidelist/Breadcrumb',
  },
  {
    title: 'Button',
    url: '/guidelist/Button',
  },
  {
    title: 'CheckBox',
    url: '/guidelist/CheckBox',
  },
  {
    title: 'DatePicker',
    url: '/guidelist/DatePicker',
  },
  {
    title: 'Editor',
    url: '/guidelist/Editor',
  },
  {
    title: 'Labels',
    url: '/guidelist/Labels',
  },
  {
    title: 'Modal',
    url: '/guidelist/Modal',
  },
  {
    title: 'Radio',
    url: '/guidelist/Radio',
  },
  {
    title: 'Select',
    url: '/guidelist/Select',
  },
  {
    title: 'Tab',
    url: '/guidelist/Tab',
  },
  {
    title: 'TextField',
    url: '/guidelist/TextField',
  },
  {
    title: 'Textarea',
    url: '/guidelist/Textarea',
  },
  {
    title: 'Title',
    url: '/guidelist/Title',
  },
  {
    title: 'Toggle',
    url: '/guidelist/Toggle',
  },
  {
    title: 'Tooltip',
    url: '/guidelist/Tooltip',
  },
];

const LnbWrap = styled.div`
  width: 220px;
  padding: 20px 10px 0;
  background-color: ${(props) => props.theme.color.white};
  border-right: 1px solid ${(props) => props.theme.color.gray3};
  transition: margin-left 0.3s ease;
  overflow-y: auto;
  z-index: 40;
`;

const LnbMenuItem = styled.a`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  font-size: 1.25rem;
  font-weight: bold;
  color: inherit;
  text-decoration: none;
  margin-bottom: 20px;
`;

const LnbTitle = styled.h2`
  padding: 10px 0;
  font-size: ${(props) => props.theme.fontSize.fontSize6};
  font-weight: bold;
  cursor: pointer;
`;

const LnbItem = styled.li`
  color: ${(props) => props.theme.color.black};
  border-radius: 4px;

  &:hover {
    background-color: ${(props) => props.theme.color.primary};
    color: ${(props) => props.theme.color.white};
    transition: all 130ms;
  }

  a {
    display: block;
    padding: 7px;
    width: 100%;
  }
`;

const LnbList = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;

const LnbMapList = styled.div`
  cursor: pointer;
`;

const GuideLnb: React.FC = () => {
  return (
    <LnbWrap>
      <ul>
        <li>
          <LnbList>
            <LnbMenuItem href="/guidelist">
              <span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                  className="mr-2 h-6 w-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
                  />
                </svg>
              </span>
              <span>Home</span>
            </LnbMenuItem>
          </LnbList>
        </li>
        {/* 임시 주석 */}
        {/* <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Overview</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasOverView.map((datasOverView, index) => (
                <LnbItem key={index}>
                  <a href={datasOverView.url}>{datasOverView.title}</a>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li> */}
        <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Components</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasComponents.map((datasComponents, index) => (
                <LnbItem key={index}>
                  <Link to={datasComponents.url}>{datasComponents.title}</Link>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li>
      </ul>
    </LnbWrap>
  );
};

export default GuideLnb;

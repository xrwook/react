import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Badge from 'common/Badges/Badge';
import Tooltip from 'common/Tooltip/Tooltip';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const BadgeGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Badge</GuideText>
        <GuideBox>
          <Tooltip
            message="This is a badge with tooltip"
            $direction="bottom"
            $auto
          >
            <Badge $blue>132</Badge>
          </Tooltip>
          <Badge $red>72</Badge>
          <Badge>0</Badge>
          <Badge $small $blue>
            36
          </Badge>
          <Badge $small $red>
            36
          </Badge>
          <Badge $small>0</Badge>
        </GuideBox>
        <GuideSubBox>&lt;Badge /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default BadgeGuide;

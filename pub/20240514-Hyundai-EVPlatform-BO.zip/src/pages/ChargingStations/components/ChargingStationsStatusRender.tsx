import Icon from 'common/Icon/Icon';
import { ChargingStationStatusRenderData } from './data';
import {
  RenderWrap,
  RenderBox,
  RenderCurrent,
  RenderTotal,
} from '../styled/StyledChargingStations';

export interface ChargingStationStatusRenderProps {
  id?: number;
  iconWidthSize?: number;
  iconName?: string;
  current?: number;
  total?: number;
}

const ChargingStationsStatusRender: React.FC<
  ChargingStationStatusRenderProps
> = () => {
  return (
    <RenderWrap>
      {ChargingStationStatusRenderData &&
        ChargingStationStatusRenderData.map((item) => (
          <RenderBox key={item.id}>
            <Icon
              $widthSize={item.iconWidthSize}
              $heightSize={16}
              $name={`icon-lightning-${item.iconName}`}
            />
            <div className="group">
              <RenderCurrent>{item.current}</RenderCurrent>
              <RenderTotal>{item.total}</RenderTotal>
            </div>
          </RenderBox>
        ))}
    </RenderWrap>
  );
};

export default ChargingStationsStatusRender;

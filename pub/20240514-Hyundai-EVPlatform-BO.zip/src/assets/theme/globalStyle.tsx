import { createGlobalStyle } from 'styled-components';
import '../fonts/pretendard/style.css';
import timeIcon from '/images/icons/icon-time.svg';
import checkIcon from '/images/icons/icon-check.svg';

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after {
    box-sizing: border-box;
  }

  html, body {
    font-size: 16px;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
    font-weight: 400;
    -webkit-text-size-adjust: none;
    text-size-adjust: none;
    word-break: break-all;
    -webkit-overflow-scrolling: touch
  }
  html, body, div, span, applet, object, iframe,
  h1, h2, h3, h4, h5, h6, p, blockquote, pre,
  a, abbr, acronym, address, big, cite, code,
  del, dfn, em, img, ins, kbd, q, s, samp,
  small, strike, strong, sub, sup, tt, var,
  b, u, i, center,
  dl, dt, dd, ol, ul, li,
  fieldset, form, label, legend,
  table, caption, tbody, tfoot, thead, tr, th, td,
  article, aside, canvas, details, embed, 
  figure, figcaption, footer, header, hgroup, 
  menu, nav, output, ruby, section, summary,
  time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font: inherit;
    vertical-align: baseline;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
  }
  ol, ul {
    list-style: none;
  }
  blockquote, q {
    quotes: none;
  }
  blockquote:before, blockquote:after,
  q:before, q:after {
    content: '';
    content: none;
  }
  table {
    border-collapse: collapse;
    border-spacing: 0;
  }
  a {
    color: inherit;
    text-decoration: none
  }
  button, input, select, table, textarea {
    font-size: inherit;
    color: inherit;
    font-family: inherit;
    font-weight: inherit
  }
  h1, h2, h3, h4, h5, h6, strong {
    font-size: inherit;
    line-height: inherit;
    font-weight: inherit
  }
  textarea {
    border: 0;
    word-break: keep-all;
    word-wrap: break-word
  }
  button, label, a {
    cursor: pointer;
    &:disabled {
      cursor: default;
    }
  }
  button, input {
    border-radius: 0;
    border: 0;
    background-color: unset
  }
  input, select, textarea, button {
    outline: none;
  }
  /* scrollbar custom */

  /* 스크롤바 */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  /* 스크롤바 막대 */
  ::-webkit-scrollbar-thumb {
    background: #caccd7;
    border-radius: 12px 12px 12px 12px;
  }

  /* 스크롤바 트랙 */
  ::-webkit-scrollbar-track {
  }

  
  /* time-datepicker */
  .time .react-datepicker__input-container::after {
    background-image: url(${timeIcon}) !important;
  }

  /* ag-grid */
  .ag-root-wrapper {
    border: unset;
    border-radius: 0;

    .custom-align-center .ag-header-cell-label {
      justify-content: center;
    }
  }
  .ag-paging-panel {
    border-top: 0;
  }
  .ag-paging-page-size {
    display: none;
  }
  .ag-paging-row-summary-panel {
    display: none;
  }
  .ag-header, .ag-advanced-filter-header {
    height: 44px !important;
    min-height: 44px !important;
    background-color: #F5F6FA;
    border-top: 1px solid #C2C5D2;
    border-bottom: 1px solid #C2C5D2;
  }
  .ag-header:hover {
    background-color: #E7E9F1;
  }
  .ag-header-container {
    width: 100%;
  }
  .ag-header.ag-header-allow-overflow .ag-header-row {
    width: 100% !important;
  }
  .ag-header-cell {
    .ag-sort-indicator-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
    }
    &.ag-header-cell-sortable {
      .ag-sort-order {
        display: block !important;
        font-size: 0;
        &::after {
          content: '';
          display: inline-block;
          width: 16px;
          height: 16px;
          background: url('/images/icons/icon-table-sort-default.svg') no-repeat center right / 12px 16px; 
        }
      }
    }
    .ag-icon-asc {
      &::before {
        display: none;
      }
      &::after {
        background: url('/images/icons/icon-table-sort-asc.svg') no-repeat center right / 12px 16px; 
      }
    }
    .ag-icon-desc {
      &::before {
        display: none;
      }
      &::after {
        background: url('/images/icons/icon-table-sort-desc.svg') no-repeat center right / 12px 16px; 
      }
    }
  }
  .ag-header-cell-resize {
    display: none;
  }
  
  .ag-header-cell, .ag-header-group-cell {
    height: 44px !important;
    padding: 0 14px !important;
  }
  
  .ag-header-cell-label{ 
    align-items: center;
    justify-content: flex-start;
  }
  .ag-header-cell-text {
    font-size: 13px;
    line-height: 16px;
    font-weight: 600;
    color: #212430;
  }
  .ag-center-cols-container {
    width: 100% !important;
  }
  .ag-cell {
    text-align: left;
    padding: 0 14px;
  }
  .ag-row {
    height: 44px;
    border-bottom: 1px solid #F0F1F4;
  }
  .ag-row-odd {
    background-color: #ffffff;
  }
  .ag-checkbox-input-wrapper {
    width: 18px;
    height: 18px;
    border-radius: 2px;
  }
  .ag-checkbox-input-wrapper input, .ag-checkbox-input-wrapper input {
    width: 18px;
    height: 18px;
  }
  .ag-checkbox-input-wrapper::after {
    content: '';
    width: 18px;
    height: 18px;
    border-radius: 2px;
    border: 1px solid #CDCDCD;
  }
  .ag-checkbox-input-wrapper.ag-checked::before{
    border: none;
    background-image: url(${checkIcon}) !important;
    background-size: cover !important;
    width: 18px !important;
  }
  .ag-checkbox-input-wrapper.ag-checked::after {
    content: none;
  }
  .ag-checkbox-input-wrapper.ag-indeterminate::before {
    background-image: none;
  }
  .ag-checkbox-input-wrapper.ag-indeterminate::after {
    content: '';
  }
  .ag-checkbox-input-wrapper:focus-within, .ag-checkbox-input-wrapper:active {
    box-shadow: unset;
  }
  .ag-row-selected::before {
    background-color: transparent;
  }
  .ag-row-hover.ag-row-selected::before {
    background-color: transparent !important;
    background-image: none;
  }
  .ag-row-hover, .ag-row-hover:not(.ag-full-width-row)::before {
    background-color: #F5F7FF;
  }
  .ag-cell-inline-editing  {
    border: 1px solid;
  }
  .ag-body {
    min-height: auto;
    flex: 0;
  }
  .ag-root-wrapper-body.ag-layout-normal {
    height: auto;
  }
  .ag-has-focus .ag-cell-focus {
    border-color: transparent !important;
  }

  /* react-select */
`;

export default GlobalStyle;

import styled from 'styled-components';
import { AlertProps } from './Alert';

export const Dim = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: ${(props) => props.theme.color.black};
  opacity: 0.7;
  z-index: 100;
`;

export const AlertWrapper = styled.div`
  display: flex;
  align-items: center;
  display: inline-block;
  vertical-align: middle;
`;

export const AlertBox = styled.div<AlertProps>`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: ${(props) => props.width};
  height: ${(props) => props.height};
  padding: 35px 31px 31px 32px;
  border: 1px solid #caccd7;
  border-radius: 6px;
  background-color: ${(props) => props.theme.color.white};
  box-shadow: 0 0 15px #0000001a;
  z-index: 200;
`;

export const AlertHeaderWrapper = styled.div`
  margin-bottom: 20px;
  font-size: ${(props) => props.theme.fontSize.fontSize6};
  line-height: 24px;
  color: ${(props) => props.theme.color.gray10};
  font-weight: 600;
`;

export const AlertContentWrapper = styled.div`
  margin-bottom: 30px;
  max-height: 467px;
  overflow-y: auto;
  font-size: ${(props) => props.theme.fontSize.fontSize4};
  line-height: 24px;
  color: ${(props) => props.theme.color.gray7};
  font-weight: 500;
`;

export const AlertFooterWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;

  > button + button {
    margin-left: 8px;
  }
`;

export const AlertLine = styled.div`
  width: 100%;
  height: 1px;
  margin: 20px 0;
  background-color: #d9d9d9;
`;

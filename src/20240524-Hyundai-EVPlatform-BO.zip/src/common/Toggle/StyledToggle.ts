import styled from 'styled-components';
import { ToggleProps } from './Toggle';

export const ToggleWrapper = styled.label`
  display: flex;
  align-items: center;
`;

export const Switch = styled.div`
  position: relative;
  width: 26px;
  height: 17px;
  border-radius: 8.5px;
  background-color: ${(props) => props.theme.color.gray4};
  transition: 300ms all;

  &:before {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    transform: translateX(0);
    width: 13px;
    height: 13px;
    border-radius: 50%;
    background-color: ${(props) => props.theme.color.white};
    transition: 300ms all;
  }
`;

export const Input = styled.input`
  position: absolute;
  opacity: 0;

  &:checked + ${Switch} {
    background: ${(props) => props.theme.color.primary};

    &:before {
      transform: translateX(9px);
    }
  }
  &:checked:disabled + ${Switch} {
    background-color: ${(props) => props.theme.color.gray2};
  }

  &:disabled + ${Switch} {
    background-color: ${(props) => props.theme.color.gray2};
  }
`;

export const Label = styled.span<ToggleProps>`
  padding-left: 8px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) =>
    props.disabled
      ? `${props.theme.color.textDimed}`
      : `${props.theme.color.gray8}`};
`;

import styled, { css } from 'styled-components';

const TabList = styled.div<TabProps>`
  width: 100%;

  ul {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid #f0f0f0;
  }
  li {
    width: auto;
  }
  li + li {
    padding-left: 30px;
  }
`;

export const TabItem = styled.li<TabProps>`
  button,
  a {
    display: block;
    width: 100%;
    height: 44px;
    font-size: 15px;
    line-height: 24px;
    font-weight: 600;
    padding: 10px 0;
    text-align: center;
    color: #8d96a1;
    box-sizing: border-box;
  }

  ${(props) =>
    props.$active &&
    css`
      button,
      a {
        color: #242a30;
        border-bottom: 2px solid #5755ff;
      }
    `};
`;

export interface TabProps {
  tabs?: any;
  selected?: any;
  $active?: any;
  onClick?: any;
}

const Tab: React.FC<TabProps> = ({ tabs = [], selected = 0, onClick }) => {
  const Panel = tabs && tabs[selected];

  return (
    <>
      <TabList>
        <ul role="tablist">
          {tabs.map((item: any, index: any) => {
            return (
              <TabItem
                key={`tab-item-${index}`}
                onClick={() => onClick(index)}
                $active={selected === index}
              >
                <button type="button">{item.name}</button>
              </TabItem>
            );
          })}
        </ul>
      </TabList>
      {Panel && (
        <div role="tabpanel">
          <Panel.Component index={selected} />
        </div>
      )}
    </>
  );
};

export default Tab;

import { Route, Routes, BrowserRouter } from 'react-router-dom';
import { Layout } from 'common/Tab/Layout';
import { Home_ } from 'common/Tab/Home';
import { AxiosQuery } from 'pages/Subpage/AxiosQuery';
import { ReactQuery } from 'pages/Subpage/ReactQuery';
import Home from 'pages/Home';
import GuideRoute from 'routes/GuideRoute';
import PrivateRoute from 'routes/PrivateRoute';
import PublicRoute from 'routes/PublicRoute';
import React from 'react';
import { ServiceType } from 'types/serviceType';
// import HyundaiRoute from 'routes/HyundaiRoute';
// import KiaRoute from 'routes/KiaRoute';
// import GenesisRoute from 'routes/GenesisRoute';
import MainLayout from 'layout/MainLayout';
import SubLayout from 'layout/SubLayout';
import PublishingRoute from './PublishingRoute';
import routes from './publishroutedata';

export interface RouterProps {
  serviceType: ServiceType;
}

const Router: React.FC<RouterProps> = ({ serviceType }) => (
  <BrowserRouter>
    <Routes>
      <Route
        path="/"
        element={
          <PublicRoute>
            <Home />
          </PublicRoute>
        }
      />
      <Route
        path="/tab"
        element={
          <PrivateRoute>
            {/* <Articles /> */}
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Home_ />} />
        <Route path="axios-query" element={<AxiosQuery />} />
        <Route path="react-query" element={<ReactQuery />} />
        {/* 임시 레이아웃 Route */}
        {/* <Route path="/main" element={<GlobalLayout />} /> */}
      </Route>

      {/* DD: 퍼블 파일을 보기 위한 라우터 */}
      <Route path="main" element={<MainLayout />} />
      <Route path="/" element={<SubLayout />}>
        {routes.map(({ path, element }) => (
          <Route key={path} path={path} element={element} />
        ))}
      </Route>
    </Routes>
    <GuideRoute />
    <PublishingRoute />

    {/* GuideRoute / PublishingRoute 추가 */}

    {/* DD : 어드민 분기 처리 미결정으로 우선 주석 처리함 */}
    {/* {serviceType == ServiceType.Hyundai ? (
      <HyundaiRoute />
    ) : serviceType == ServiceType.Kia ? (
      <KiaRoute />
    ) : serviceType == ServiceType.Genesis ? (
      <GenesisRoute />
    ) : (
      <></>
    )} */}
  </BrowserRouter>
);

export default Router;

const HyundaiBrandTest = () => {
  return <div>Hyundai Brand Page</div>;
};

export default HyundaiBrandTest;

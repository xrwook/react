import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Select from 'common/Select/Select';
import SelectCheckBox from 'common/SelectCheckBox';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const SelectGuide = () => {
  const options = [
    {
      value: 'option01',
      label: 'option01',
    },
    {
      value: 'option02',
      label: 'option02',
    },
    {
      value: 'option03',
      label: 'option03',
    },
    {
      value: 'option04',
      label: 'option04',
    },
  ];
  const optionscolor = [
    {
      value: 'option01',
      label: '빨강',
    },
    {
      value: 'option02',
      label: '노랑',
    },
    {
      value: 'option03',
      label: '초록',
    },
    {
      value: 'option04',
      label: '파랑',
    },
  ];

  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Select</GuideText>
        <GuideBox>
          <Select
            placeholder="선택해주세요"
            options={options}
            classNamePrefix="react-select"
          />
          <Select
            placeholder="선택해주세요"
            options={optionscolor}
            isMulti
            hideSelectedOptions={false}
            classNamePrefix="react-select"
          />
          <SelectCheckBox
            placeholder="선택해주세요"
            options={optionscolor}
            isMulti
            hideSelectedOptions={false}
            classNamePrefix="react-select"
          />
        </GuideBox>
        <GuideSubBox>
          &lt;Select placeholder="" options="" defaultValue="" error disabled
          /&gt;
          <br />
          &lt;Select placeholder="" options="" isMulti="" hideSelectedOptions=""
          /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default SelectGuide;

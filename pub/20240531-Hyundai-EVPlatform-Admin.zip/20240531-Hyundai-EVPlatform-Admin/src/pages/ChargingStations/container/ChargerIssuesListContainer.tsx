import AgGrid from 'common/AgGrid';
import {
  ChargerIssuesListRowData,
  ChargerIssuesListColumnDefs,
} from '../components/listData';
import { listPerPageSelectOption } from '../components/data';
import Title from 'common/Title';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';
import FilterList from '../components/FilterChargerIssuesList';
import Header from 'layout/Header';
import { StatusDisplay } from '../styled/StyledChargingStations';
import CardStatus from 'common/Card/CardStatus';
import CircleProgressBar from 'common/CircleProgressBar/CircleProgressBar';

const ChargingStationsListContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전소 고장 관리', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />
      <Title
        titlemain="충전기 고장 관리"
        $titlesub="Last Updated 2024-00-00 00:00"
      >
        <ButtonGroup $gap={8}>
          <Button onClick={() => {}} $size="large" $variant="primary">
            고장 등록
          </Button>
        </ButtonGroup>
      </Title>
      <StatusDisplay>
        <li className="status-display-box">
          <div className="status-display-box-inner">
            <CardStatus $color="purple" status="전체 충전기" />
            <span className="status-display-box__number">405</span>
          </div>
        </li>
        <li className="status-display-box">
          <div className="status-display-box-inner">
            <CardStatus $color="red" status="고장 충전기" />
            <span className="status-display-box__number">67</span>
          </div>
          <CircleProgressBar
            $widthSize={60}
            $heightSize={60}
            $statusColor={'red'}
            $strokeWidth={4}
            title="고장률"
            currentValue={67}
            total={405}
          />
        </li>
        <li className="status-display-box status-display-box--column">
          <CardStatus $color="blue" status="조치" />
          <div className="status-notice">
            <div className="status-notice-group">
              <span>조치 필요</span>
              <span className="need-color">608</span>
            </div>
            <div className="status-notice-group">
              <span>조치 완료</span>
              <span className="complete-color">36</span>
            </div>
          </div>
        </li>
      </StatusDisplay>
      <FilterList />
      <AgGrid
        rowData={ChargerIssuesListRowData}
        columnDefs={ChargerIssuesListColumnDefs}
        hasPaging={true}
        hasGridTop={true}
        listPerPageSelectOption={listPerPageSelectOption}
        listPerPageDefaultOption={{
          value: '20',
          label: '20개씩보기',
        }}
      />
    </>
  );
};

export default ChargingStationsListContainer;

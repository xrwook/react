import styled from 'styled-components';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

export const EditorStyled = styled(ReactQuill)<{ height?: string }>`
  height: ${(props) => props.height};
`;

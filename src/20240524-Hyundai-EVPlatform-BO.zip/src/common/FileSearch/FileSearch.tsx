import React, { useRef, useState } from 'react';
import {
  FileSearchWrap,
  FileSearchBox,
  FileAttachArea,
  FileSearchDnd,
  DndStage,
} from './StyledFileSearch';
import Button from 'common/Button/Button';
import Icon from 'common/Icon/Icon';

export interface FileSearchProps {
  $position?: 'top' | 'bottom';
  text?: string;
  dnd?: boolean;
  max?: number;
  uploadedInfo?: any;
  onDelete?: any;
  $small?: any;
}

const FileSearch: React.FC<FileSearchProps> = ({
  $position,
  text,
  dnd,
  $small,
}) => {
  /**
   * 일반 파일
   *  */
  const [images, setImages] = useState([] as any);
  /**
   * Drag and Drop
   *  */
  const [isActiveDrag, setActiveDrag] = useState(false);
  const [uploadedInfo, setUploadedInfo] = useState<any>(null);
  const selectInputFile = useRef<HTMLInputElement>(null);
  const handleClick = () => {
    selectInputFile.current?.click();
  };

  const handleAddImages = (event: any) => {
    const imageLists = event.target.files;
    let imageUrlLists = [...images];

    for (let i = 0; i < imageLists.length; i++) {
      const currentImageUrl = URL.createObjectURL(imageLists[i]);
      imageUrlLists.push(currentImageUrl);
    }

    if (imageUrlLists.length > 10) {
      imageUrlLists = imageUrlLists.slice(0, 10);
    }

    setImages(imageUrlLists);
  };

  const handleDeleteImage = (id: any) => {
    setImages(images.filter((_: any, index: any) => index !== id));
  };

  const setFileInfo = (file: any) => {
    const { extension, name, type } = file;
    setUploadedInfo({ extension, name, type });
  };

  const handleDragStart = () => {
    setActiveDrag(true);
  };

  const handleDragEnd = () => setActiveDrag(false);

  const handleDragOver = (event: any) => {
    event.preventDefault();
  };

  const handleDrop = (event: any) => {
    event.preventDefault();
    setActiveDrag(false);
    const file = event.dataTransfer.files[0];
    const extension = getFileNameExtension(file);
    const newFile = Object.assign(file, {
      extension,
    });
    setFileInfo(newFile);
  };

  const handleUpload = (event: any) => {
    const file = event.target.files[0];
    const extension = getFileNameExtension(file);
    const newFile = Object.assign(file, {
      extension,
    });
    setFileInfo(newFile);
  };

  const handleDelete = (event: any) => {
    event.preventDefault();
    setUploadedInfo(null);
  };

  const getFileNameExtension = (file: any) => {
    const lastIndex = file.name.lastIndexOf('.');
    if (lastIndex <= 0) return null;

    return file.name.slice(lastIndex + 1);
  };

  return (
    <FileSearchWrap $position={$position}>
      {dnd ? (
        <>
          <FileSearchDnd>
            <div className="dnd-title">{text}</div>
            <DndStage
              className="dnd-stage"
              $drag={isActiveDrag}
              $active={uploadedInfo}
              onDragEnter={handleDragStart}
              onDragOver={handleDragOver}
              onDragLeave={handleDragEnd}
              onDrop={handleDrop}
            >
              {!uploadedInfo && (
                <>
                  여기로 파일을 드래그 하세요.
                  <span className="other-text">또는</span>
                  <Button
                    onClick={handleClick}
                    $size="small"
                    $variant="primary"
                  >
                    파일 검색
                  </Button>
                  <input
                    type="file"
                    accept="image/*"
                    ref={selectInputFile}
                    onChange={handleUpload}
                  />
                </>
              )}
              {uploadedInfo && (
                <div className="uploaded-info">
                  <Icon
                    $name={`icon-${uploadedInfo.extension === 'xlsx' || uploadedInfo.extension === 'xls' ? 'excel-32' : uploadedInfo.extension === 'ppt' ? 'ppt-32' : 'png-32'}`}
                    $widthSize={32}
                    $heightSize={32}
                  >
                    지원되지 않는 파일입니다.
                  </Icon>
                  {uploadedInfo?.name}
                  <Button
                    className="file-attach-button"
                    $iconOnly
                    $icon="icon-delete-16"
                    $size="none"
                    $variant="none"
                    onClick={(event) => handleDelete(event)}
                  />
                </div>
              )}
            </DndStage>
          </FileSearchDnd>
        </>
      ) : (
        <>
          <FileSearchBox htmlFor="fileSearch01" onChange={handleAddImages}>
            <Button
              $icon="icon-search-black"
              onClick={handleClick}
              $size="small"
              $variant="tertiary"
            >
              <Icon $widthSize={20} $heightSize={20}>
                검색
              </Icon>
              파일 검색
            </Button>
            {text}
            <input
              type="file"
              accept="image/*"
              ref={selectInputFile}
              id="fileSearch01"
              multiple
            />
          </FileSearchBox>
          <FileAttachArea $small={$small}>
            {images.map((image: any, id: any) => (
              <div className="file-attach-area">
                <img src={image} />
                <Button
                  className="file-attach-button"
                  $iconOnly
                  $icon="icon-attach-delete"
                  $size="none"
                  $variant="none"
                  onClick={() => handleDeleteImage(id)}
                />
              </div>
            ))}
          </FileAttachArea>
        </>
      )}
    </FileSearchWrap>
  );
};

export default FileSearch;

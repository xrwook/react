import styled from 'styled-components';
import React from 'react';
import { Outlet } from 'react-router';
import GuideLnb from './GuideComponents/GuideLnb';

const StyledGuideWrapper = styled.div`
  display: flex;
  width: 100%;
  min-width: 1400px;
  height: 100%;
`;

const StyledComponentsWrapper = styled.div`
  flex: 1;
  height: 100%;
  margin-left: 180px;
`;

const Guide: React.FC = () => {
  return (
    <StyledGuideWrapper>
      <GuideLnb />
      <StyledComponentsWrapper>
        <Outlet />
      </StyledComponentsWrapper>
    </StyledGuideWrapper>
  );
};

export default Guide;

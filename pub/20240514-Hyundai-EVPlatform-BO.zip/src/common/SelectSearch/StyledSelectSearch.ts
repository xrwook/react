import { styled } from 'styled-components';

export const MenuContainer = styled.div`
  .react-select__control {
    margin: 0 0 8px 0;
  }
  box-shadow: 0 6px 10px #0000000d;
  border: 1px solid #caccd7;
  padding: 8px;
  width: auto;
  max-width: 300px;
  min-width: 160px;
  position: absolute;
  z-index: 20;
  background-color: #fff;
  border-radius: 4px;
  margin-top: 4px;
`;

export const MenuHeader = styled.div`
  margin-bottom: 8px;
`;

export const MenuTitle = styled.div<{ $menuTitle: any }>`
  display: ${(props) => (props.$menuTitle ? 'block' : 'none')};
  padding: 4px 10px;
  margin-bottom: 8px;
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
  color: #434860;
`;

export const MenuWrapper = styled.div`
  .react-select__menu {
    box-shadow: unset;
    border: unset;
    padding: unset;
    border-top: 1px solid #f0f1f4;
  }
`;

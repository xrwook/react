import Button from 'common/Button/Button';
import { RenderCommonWrap } from '../styled/StyledChargingStations';

export interface ChargingStationsConnectTypeRenderProps {
  buttonName?: string | undefined;
}

const ChargingStationsConnectTypeRender: React.FC<
  ChargingStationsConnectTypeRenderProps
> = ({ buttonName }) => {
  return (
    <RenderCommonWrap>
      <Button $size="mini" $variant="tertiary" onClick={() => {}}>
        {buttonName}
      </Button>
    </RenderCommonWrap>
  );
};

export default ChargingStationsConnectTypeRender;

import { Link } from 'react-router-dom';
import Breadcrumb from 'common/Breadcrumb/Breadcrumb';
import BreadcrumbHome from 'common/Breadcrumb/BreadcrumbHome';
import BreadcrumbLink from 'common/Breadcrumb/BreadcrumbLink';
import { HeaderWrap, HeaderProfileWrap, ImgArea } from './StyledLayout';

interface BreadcrumbLinkProps {
  to: string;
  text: string;
  className?: string;
}

interface HeaderProps {
  breadcrumbLinks: BreadcrumbLinkProps[];
}

const Header: React.FC<HeaderProps> = ({ breadcrumbLinks }) => {
  return (
    <HeaderWrap>
      <Breadcrumb>
        <BreadcrumbHome to="/" />
        {breadcrumbLinks?.map((link, index) => (
          <BreadcrumbLink key={index} to={link.to} className={link.className}>
            {link.text}
          </BreadcrumbLink>
        ))}
      </Breadcrumb>

      <HeaderProfileWrap>
        <figure>
          <ImgArea $size={'small'}>
            <img src="/images/common/bg-profile.svg" alt="" />
          </ImgArea>
          <figcaption>hyundai.kim@hyundai-autoever.com</figcaption>
        </figure>
        <div className="profile-popover">
          <ul className="profile-popover-list">
            <li className="profile-popover-item">
              <span className="profile-popover-item__name">
                김오토 (테넌트 운영자)
              </span>
              <span className="profile-popover-item__info">
                hyundai.kim@hyundai-autoever.com
              </span>
            </li>
            <li className="profile-popover-item">
              <Link to={'#mypage'}>마이페이지</Link>
            </li>
            <li className="profile-popover-item">
              <Link to={'#logout'}>로그아웃</Link>
            </li>
          </ul>
        </div>
      </HeaderProfileWrap>
    </HeaderWrap>
  );
};

export default Header;

import React, { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { AgGridWrap, AgGridContainer } from './StyledAgGrid';
import Pagination from 'common/Pagination/Pagination';
import Button from 'common/Button/Button';
import Dropdown from 'common/Dropdown/Dropdown';
import Icon from 'common/Icon/Icon';
import AgGridTop from 'common/AgGrid/AgGridTop';

export interface AgGridProps {
  rowData?: any[];
  columnDefs?: any[];
  hasPaging?: boolean;
  hasGridTop?: boolean;
  noneButton?: boolean;
  hasDate?: boolean;
  itemsPerPage?: number;
  defaultNumberButtons?: number;
  dateSelectOption?: any;
  dateSelectDefaultOption?: any;
  listPerPageSelectOption?: any;
  listPerPageDefaultOption?: any;
}

const AgGrid: React.FC<AgGridProps> = ({
  rowData,
  columnDefs,
  hasPaging,
  hasGridTop,
  noneButton,
  hasDate,
  dateSelectOption,
  dateSelectDefaultOption,
  listPerPageSelectOption,
  listPerPageDefaultOption,
}) => {
  const [gridApi, setGridApi] = useState(null);
  const [rowCount, setRowCount] = useState(null);
  const [selectedOption, setSelectedOption] = useState(20);

  const defaultColDef = { sortable: false, resizable: true, flex: 1 };
  const onGridReady = (params: any) => {
    setGridApi(params.api);
    setRowCount(params.api.getDisplayedRowCount());
    params.api.sizeColumnsToFit();
  };
  const handleClick = (prop: any) => {
    const stringValue: string = prop;
    const changeNumberValue: number = parseInt(stringValue, 10);
    setSelectedOption(changeNumberValue);
  };

  return (
    <AgGridContainer>
      {hasGridTop && (
        <AgGridTop totalCount={rowCount}>
          {!noneButton && (
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryGray"
              $icon={'icon-download'}
            >
              <Icon $widthSize={20} $heightSize={20} />
              엑셀 다운로드
            </Button>
          )}
          {hasDate && (
            <Dropdown
              $width="168"
              options={dateSelectOption}
              defaultOption={dateSelectDefaultOption}
              onClick={handleClick}
            />
          )}
          <Dropdown
            $width="120"
            options={listPerPageSelectOption}
            defaultOption={listPerPageDefaultOption}
            onClick={handleClick}
          />
        </AgGridTop>
      )}
      <AgGridWrap className="ag-theme-alpine">
        <AgGridReact
          columnDefs={columnDefs}
          rowData={rowData}
          rowSelection="multiple"
          reactiveCustomComponents
          onGridReady={onGridReady}
          defaultColDef={defaultColDef}
          pagination={true}
          paginationPageSize={selectedOption}
          suppressPaginationPanel={true}
        />
      </AgGridWrap>
      {hasPaging && <Pagination gridApi={gridApi} />}
    </AgGridContainer>
  );
};

export default AgGrid;

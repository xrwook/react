import { useEffect, useState } from 'react';
import { CircleProgressBarWrap } from './styledCircleProgressBar';

export interface CircleProgressBarProps {
  $widthSize?: any;
  $heightSize?: any;
  $statusColor?: string;
  $strokeWidth?: any;
  title?: string;
  total?: any;
  currentValue?: any;
}

const CircleProgressBar: React.FC<CircleProgressBarProps> = ({
  $widthSize,
  $heightSize,
  $statusColor,
  $strokeWidth,
  title,
  total,
  currentValue,
}) => {
  const [value, setValue] = useState<number>(0);
  const RADIUS = $widthSize / 2 - $strokeWidth / 2;
  const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
  const viewBox = `0 0 ${$widthSize || 60} ${$heightSize || 60}`;

  useEffect(() => {
    const updateProgressBar = () => {
      const progress = currentValue / total;
      const progressNumber = Math.floor(progress * 100);
      setValue(progressNumber);

      const circleBar = document?.querySelector(
        '.circle-progress__outer',
      ) as SVGCircleElement;
      const dashoffset = CIRCUMFERENCE * (1 - progress);

      if (circleBar) {
        circleBar.style.strokeDashoffset = dashoffset + 'px';
        circleBar.style.strokeDasharray = CIRCUMFERENCE + 'px';
      }
    };

    updateProgressBar();
  }, [currentValue, total, CIRCUMFERENCE]);

  return (
    <CircleProgressBarWrap
      $widthSize={$widthSize}
      $heightSize={$heightSize}
      $statusColor={$statusColor}
    >
      <svg viewBox={viewBox} className="circle-progress">
        <circle
          className="circle-progress__inner"
          cx={$widthSize / 2 || 30}
          cy={$widthSize / 2 || 30}
          r={RADIUS}
          strokeWidth={$strokeWidth}
        />
        <circle
          className="circle-progress__outer"
          cx={$widthSize / 2 || 30}
          cy={$widthSize / 2 || 30}
          r={RADIUS}
          strokeWidth={$strokeWidth}
        />
      </svg>
      <div className="circle-info">
        <div className="circle-info__title">{title}</div>
        <div className="circle-info__percent">{value}%</div>
      </div>
    </CircleProgressBarWrap>
  );
};

export default CircleProgressBar;

import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import CardStatus from 'common/Card/CardStatus';
import Card from 'common/Card';
import CardHeader from 'common/Card/CardHeader';
import CardItem from 'common/Card/CardItem';
import { CardInfo, CardName, CardValue } from 'common/Card/StyledCard';

const CardGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>
          Card <h3>Status</h3>
        </GuideText>
        <GuideBox>
          <CardStatus $color="purple" status="Chargers" />
          <CardStatus $color="blue" status="Available" />
          <CardStatus $color="green" status="Charging" />
          <CardStatus $color="gray" status="Complete" />
          <CardStatus $color="gray" status="Out of Service" />
          <CardStatus $color="yellow" status="Waitlist" />
          <CardStatus $color="yellow" status="On Hold" />
          <CardStatus $color="red" status="Unknown" />
          <CardStatus $color="red" status="Breakdown/Inspection" />
          <CardStatus $color="red" status="Communication Failure" />
          <CardStatus $color="red" status="Suspended Operation" />
          <CardStatus $color="red" status="In Use" />
        </GuideBox>
        <GuideText>
          <h3>Card Sample</h3>
        </GuideText>
        <GuideBox>
          <Card>
            <CardHeader>
              <CardStatus $color="blue" status="Available" />
            </CardHeader>
            <CardItem>
              <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
              <CardInfo>Left</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>커넥터 타입</CardValue>
              <CardInfo>CCS Combo</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>속도</CardValue>
              <CardInfo>Super Fast (Max.150 kW)</CardInfo>
            </CardItem>
          </Card>

          <Card>
            <CardHeader>
              <CardStatus $color="yellow" status="On Hold" />
            </CardHeader>
            <CardItem>
              <CardName>Charging Station Name</CardName>
              <CardInfo>Left</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>Plug Type</CardValue>
              <CardInfo>CCS Combo</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>Max. Speed</CardValue>
              <CardInfo>Super Fast (Max.150 kW)</CardInfo>
            </CardItem>
          </Card>
        </GuideBox>

        <GuideSubBox>
          {`<Card>
            <CardHeader>
              <CardStatus $color="blue" status="Available" />
            </CardHeader>
            <CardItem>
              <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
              <CardInfo>Left</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>커넥터 타입</CardValue>
              <CardInfo>CCS Combo</CardInfo>
            </CardItem>
            <CardItem>
              <CardValue>속도</CardValue>
              <CardInfo>Super Fast (Max.150 kW)</CardInfo>
            </CardItem>
          </Card>`}
        </GuideSubBox>

        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>$color</td>
              <td>$color="yellow"</td>
              <td>purple , blue , green , gray , yellow , red</td>
              <td></td>
            </tr>
            <tr>
              <td>status</td>
              <td>status="On Hold"</td>
              <td>상태값 이름</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default CardGuide;

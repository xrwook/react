import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import Formcontrol from 'common/FormControl';
import TextField from 'common/TextField';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Select from 'common/Select';
import FormFlex from 'common/FormFlex';
import Icon from 'common/Icon';
import Radio from 'common/Radio';
import Datepicker from 'common/Datepicker';
import AgGrid from 'common/AgGrid';
import {
  chargerRegistrationRowData,
  chargerRegistrationColumnDefs,
  chargingStationsDetailOption,
} from '../components/detailData';
import { ButtonGroup } from 'common/Button/StyledButton';
import {
  FlexNone,
  Section,
  SectionTitle,
} from '../styled/StyledChargingStations';

const ChargingStationsAddContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  const [startDate, setStartDate] = useState<Date | null>(new Date());

  const options01 = [
    {
      value: '현대엔지니어링',
      label: '현대엔지니어링',
    },
  ];

  const options02 = [
    {
      value: 'ChargingOnly',
      label: 'ChargingOnly',
    },
    {
      value: '충전제어(VOG)',
      label: '충전제어(VOG)',
    },
    {
      value: 'SmartGharging(VIG)',
      label: 'SmartGharging(VIG)',
    },
    {
      value: 'BPT(V2G)',
      label: 'BPT(V2G)',
    },
    {
      value: 'etc(Unknown)',
      label: 'etc(Unknown)',
    },
  ];

  const options03 = [
    {
      value: 'SK Signet signet',
      label: 'SK Signet signet',
    },
  ];

  const options04 = [
    {
      value: '000001',
      label: '000001',
    },
  ];

  const options05 = [
    {
      value: 'Manual(수동)',
      label: 'Manual(수동)',
    },
    {
      value: 'ManualotACD',
      label: 'ManualotACD',
    },
    {
      value: 'OnlyACD(Robot)',
      label: 'OnlyACD(Robot)',
    },
    {
      value: 'Pantograph',
      label: 'Pantograph',
    },
    {
      value: 'etc',
      label: 'etc',
    },
  ];

  const options06 = [
    {
      value: '대기표 방식',
      label: '대기표 방식',
    },
    {
      value: '사전예약 방식',
      label: '사전예약 방식',
    },
    {
      value: 'NONE',
      label: 'NONE',
    },
  ];

  const options07 = [
    {
      value: 'None(인증/과금없음)',
      label: 'None(인증/과금없음)',
    },
    {
      value: 'RFID+Nunmber(RFID/회원번호)',
      label: 'RFID+Nunmber(RFID/회원번호)',
    },
    {
      value: 'QR',
      label: 'QR',
    },
    {
      value: 'CreditCard',
      label: 'CreditCard',
    },
    {
      value: 'PnC',
      label: 'PnC',
    },
    {
      value: 'FID+QR',
      label: 'FID+QR',
    },
    {
      value: 'RFID+QR+Credit',
      label: 'RFID+QR+Credit',
    },
  ];

  const options08 = [
    {
      value: 'OCPP1.6',
      label: 'OCPP1.6',
    },
    {
      value: 'OCPP2.0.1',
      label: 'OCPP2.0.1',
    },
  ];

  const options09 = [
    {
      value: 'OCPI',
      label: 'OCPI',
    },
    {
      value: 'ECS',
      label: 'ECS',
    },
    {
      value: 'ECSP',
      label: 'ECSP',
    },
    {
      value: 'ECPI(ECSP+OCPI)',
      label: 'ECPI(ECSP+OCPI)',
    },
  ];

  return (
    <>
      {showModal && (
        <Modal
          width="1104px"
          height="auto"
          oversize
          onClose={() => setShowModal(false)}
        >
          <ModalHeader>충전기 등록</ModalHeader>
          <ModalContent $marginBottom="30px">
            <Section>
              <SectionTitle>기본 정보</SectionTitle>
              <Grid $columns={2} $gap="12px 80px">
                <GridItem $colStart={1} $colEnd={3}>
                  <Formcontrol
                    title="충전기 이름"
                    htmlFor="TextField01"
                    required
                    $gapSmall
                  >
                    <TextField
                      id="TextField01"
                      name="text"
                      type="text"
                      placeholder="Enter charging station name"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="사업자"
                    htmlFor="Select01"
                    required
                    $gapSmall
                  >
                    <Select
                      inputId="Select01"
                      name="Select01"
                      placeholder="충전사업자 이름 표시"
                      options={options01}
                      classNamePrefix="react-select"
                      disabled
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전소"
                    htmlFor="Select01"
                    required
                    $gapSmall
                  >
                    <FormFlex>
                      <TextField
                        id="TextField02"
                        name="text"
                        type="text"
                        placeholder="Enter zip code"
                        value="Park Plaze Irvine, CA 92614 (권역 ex: California)"
                        disabled
                      />

                      <Button
                        onClick={() => {}}
                        $size="small"
                        $variant="secondaryGray"
                        $icon="icon-search-secondaryGray"
                      >
                        <Icon $widthSize={20} $heightSize={20}>
                          검색
                        </Icon>
                        충전소 검색
                      </Button>
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전 서비스 유형"
                    htmlFor="Select02"
                    required
                    $gapSmall
                  >
                    <Select
                      inputId="Select02"
                      name="Select02"
                      placeholder="선택"
                      options={options02}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="시공 방식"
                    htmlFor="radio1"
                    required
                    $gapLarge
                  >
                    <FormFlex $gap="16px">
                      <FlexNone>
                        <Radio
                          id="radio1"
                          name="radio1"
                          text="단독 시공"
                          htmlFor="radio1"
                          $large
                          defaultChecked
                        />
                      </FlexNone>

                      <FlexNone>
                        <Radio
                          id="radio2"
                          name="radio1"
                          text="병렬 시공"
                          htmlFor="radio2"
                          $large
                        />
                      </FlexNone>
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="제조사/모델"
                    htmlFor="Select03"
                    $gapSmall
                    required
                  >
                    <FormFlex>
                      <Select
                        inputId="Select03"
                        name="Select03"
                        placeholder="제조사 선택"
                        options={options03}
                        classNamePrefix="react-select"
                      />

                      {/* DD : 제조사 선택 전, 모델 옵션은 비활성화  */}
                      <Select
                        inputId="Select04"
                        name="Select04"
                        placeholder="모델 선택"
                        options={options04}
                        classNamePrefix="react-select"
                      />
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전기 용량"
                    htmlFor="Select05"
                    $gapSmall
                    required
                  >
                    <FormFlex>
                      <TextField
                        id="TextField03"
                        name="text"
                        type="text"
                        value="350"
                        placeholder="00"
                        $innerRight="kW"
                      />
                      <TextField
                        id="TextField04"
                        name="text"
                        type="text"
                        value="260"
                        placeholder="00"
                        $innerRight="실 허용 용량 kW"
                      />
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전기 속도"
                    htmlFor="TextField05"
                    $gapSmall
                    required
                  >
                    <TextField
                      id="TextField05"
                      name="text"
                      type="text"
                      placeholder="Enter detail"
                      value="초고속"
                      disabled
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전기 구분"
                    htmlFor="radio2"
                    required
                    $gapLarge
                  >
                    <FormFlex $gap="16px">
                      <FlexNone>
                        <Radio
                          id="radio2"
                          name="radio2"
                          text="유선"
                          htmlFor="radio2"
                          $large
                          defaultChecked
                        />
                      </FlexNone>

                      <FlexNone>
                        <Radio
                          id="radio2"
                          name="radio2"
                          text="무선"
                          htmlFor="radio2"
                          $large
                        />
                      </FlexNone>
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="아울렛 유형"
                    htmlFor="TextField06"
                    $gapSmall
                    required
                  >
                    <TextField
                      id="TextField06"
                      name="text"
                      type="text"
                      placeholder="Enter detail"
                      value="Type 1 Combo 급속"
                      disabled
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="연결 방식 유형"
                    htmlFor="Select05"
                    required
                    $gapSmall
                  >
                    <Select
                      inputId="Select05"
                      name="Select05"
                      placeholder="선택"
                      options={options05}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="충전 제공 방식"
                    htmlFor="Select06"
                    required
                    $gapSmall
                  >
                    <Select
                      inputId="Select06"
                      name="Select06"
                      placeholder="선택"
                      options={options06}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="인증 과금 유형"
                    htmlFor="Select07"
                    required
                    $gapSmall
                  >
                    <Select
                      inputId="Select07"
                      name="Select07"
                      placeholder="선택"
                      options={options07}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="설치일" htmlFor="datepicker01" $gapSmall>
                    <Datepicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      dateFormat="yyyy/MM/dd"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="통신 게시일"
                    htmlFor="datepicker02"
                    $gapSmall
                  >
                    <Datepicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      dateFormat="yyyy/MM/dd"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="서비스 시작일"
                    htmlFor="datepicker03"
                    $gapSmall
                  >
                    <Datepicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      dateFormat="yyyy/MM/dd"
                    />
                  </Formcontrol>
                </GridItem>
              </Grid>
            </Section>

            <Section>
              <SectionTitle>EVSE / 커넥터 정보</SectionTitle>
              <AgGrid
                rowData={chargerRegistrationRowData}
                columnDefs={chargerRegistrationColumnDefs}
                hasGridTop={false}
                noneButton
                listPerPageSelectOption={chargingStationsDetailOption}
              />
            </Section>

            <Section>
              <SectionTitle>네트워크 정보</SectionTitle>
              <Grid $columns={2} $gap="16px 80px">
                <GridItem>
                  <Formcontrol title="OCPP 버전" htmlFor="Select08" $gapSmall>
                    <Select
                      inputId="Select08"
                      name="Select08"
                      placeholder="선택"
                      options={options08}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="OCPP 연동 구분"
                    htmlFor="Select09"
                    $gapSmall
                  >
                    <Select
                      inputId="Select09"
                      name="Select09"
                      placeholder="선택"
                      options={options09}
                      classNamePrefix="react-select"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="인증 ID" htmlFor="TextField07" $gapSmall>
                    <TextField
                      id="TextField07"
                      name="text"
                      type="text"
                      placeholder="ID 입력"
                      value="ID"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="비밀번호" htmlFor="TextField08" $gapSmall>
                    <TextField
                      id="TextField08"
                      name="text"
                      type="text"
                      placeholder="비밀번호 입력"
                      value="1.0.0.0"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem $colStart={1} $colEnd={3}>
                  <Formcontrol
                    title="등록 상태"
                    htmlFor="radio3"
                    required
                    $gapLarge
                  >
                    <FormFlex $gap="16px">
                      <FlexNone>
                        <Radio
                          id="radio3"
                          name="radio3"
                          text="유선"
                          htmlFor="radio3"
                          $large
                          defaultChecked
                        />
                      </FlexNone>

                      <FlexNone>
                        <Radio
                          id="radio3"
                          name="radio3"
                          text="무선"
                          htmlFor="radio3"
                          $large
                        />
                      </FlexNone>
                    </FormFlex>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="Heartbeat"
                    htmlFor="TextField09"
                    $gapSmall
                  >
                    <TextField
                      id="TextField09"
                      name="text"
                      type="text"
                      placeholder="Heartbeat 입력"
                      value="-"
                    />
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol
                    title="ping/pong"
                    htmlFor="TextField10"
                    $gapSmall
                  >
                    <TextField
                      id="TextField10"
                      name="text"
                      type="text"
                      placeholder="ping/pong 입력"
                      value="-"
                    />
                  </Formcontrol>
                </GridItem>
              </Grid>
            </Section>
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                등록
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsAddContainer;

import { useState } from 'react';
import Alert from 'common/Alert';
import AlertHeader from 'common/Alert/AlertHeader';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';
import { TextColor } from '../styled/StyledChargingStations';

const ChargingStationsChargerDeleteContainer: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);
  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        충전기 삭제
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertHeader>충전기 제거</AlertHeader>
          <AlertContent>
            충전기를 제거하시겠습니까?
            <TextColor>충전기 이름</TextColor>
          </AlertContent>
          <AlertFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowAlert(false)}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                제거
              </Button>
            </ButtonGroup>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargingStationsChargerDeleteContainer;

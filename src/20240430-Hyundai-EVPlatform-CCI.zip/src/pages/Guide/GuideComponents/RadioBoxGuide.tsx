import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import RadioBox from 'common/RadioBox';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const RadioBoxGuide = () => {
  return (
    <StyledGuideWrapper>
      <div style={{ padding: '50px' }}>
        <GuideWrapper>
          <GuideText>Radio Box</GuideText>
          <GuideBox>
            <RadioBox
              id="check01"
              name="check01"
              text="Label"
              htmlFor="check01"
              defaultChecked
            />
            <RadioBox
              id="check02"
              name="check01"
              text="Label"
              htmlFor="check02"
            />
            <RadioBox
              id="check03"
              name="check03"
              text="Label"
              htmlFor="check03"
            />
            <RadioBox
              id="check04"
              name="check04"
              text="Label"
              htmlFor="check04"
              disabled
            />
          </GuideBox>
          <GuideSubBox>
            &lt;RadioBox id="check01" name="check01" text="Label"
            htmlFor="check01" defaultChecked&gt; <br />
            &lt;RadioBox id="check02" name="check01" text="Label"
            htmlFor="check02"&gt; <br />
            &lt;RadioBox id="check03" name="check03" text="Label"
            htmlFor="check03"&gt; <br />
            &lt;RadioBox id="check04" name="check04" text="Label"
            htmlFor="check04" disabled&gt;
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>id</td>
                <td>id</td>
                <td>id 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>htmlFor</td>
                <td>htmlFor</td>
                <td>htmlFor 입력</td>
                <td>id 값과 일치</td>
              </tr>
              <tr>
                <td>name</td>
                <td>name</td>
                <td>name 입력</td>
                <td>id 값과 일치</td>
              </tr>
              <tr>
                <td>text</td>
                <td>text</td>
                <td>text 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>disabled</td>
                <td>disabled</td>
                <td>disabled 타입 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>defaultChecked</td>
                <td>defaultChecked</td>
                <td>checked 상태 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </GuideWrapper>
      </div>
    </StyledGuideWrapper>
  );
};

export default RadioBoxGuide;

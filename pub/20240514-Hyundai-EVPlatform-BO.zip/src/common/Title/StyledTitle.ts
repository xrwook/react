import styled from 'styled-components';
import { TitleProps } from './Title';

export const TitleLayout = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

export const TitleTop = styled.div<TitleProps>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  width: 100%;
  padding-bottom: ${(props) => (props.$pagetitle ? '10px' : '')};

  &::after {
    content: '';
    display: ${(props) => (props.$pagetitle ? 'block' : 'none')};
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    border-bottom: 1px solid ${(props) => props.theme.color.gray11};
  }
`;

export const TitleRight = styled.div`
  display: flex;
  > * {
    margin-left: 8px;
  }
`;

export const TitleMain = styled.div<TitleProps>`
  font-size: ${(props) =>
    props.$pagetitle
      ? `${props.theme.fontSize.fontSize7}`
      : `${props.theme.fontSize.fontSize8}`};
  line-height: ${(props) => (props.$pagetitle ? '32px' : '36px')};
  color: ${(props) => props.theme.color.gray10};
  font-weight: 500;
`;

export const TitleSub = styled.div<TitleProps>`
  display: ${(props) => (props.$titlesub ? 'block' : 'none')};
  margin-top: 4px;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray4};
`;

export const TitleGuide = styled.div<TitleProps>`
  display: ${(props) => (props.$titleguide ? 'block' : 'none')};
  position: relative;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray7};

  &::before {
    content: '*';
    position: absolute;
    top: 0;
    left: -7px;
    font-size: ${(props) => props.theme.fontSize.fontSize1};
    line-height: 20px;
    color: ${(props) => props.theme.color.textError};
  }
`;

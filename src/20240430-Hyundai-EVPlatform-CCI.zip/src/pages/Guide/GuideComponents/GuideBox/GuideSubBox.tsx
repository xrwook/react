import styled from 'styled-components';
import React from 'react';

export interface StyledGuideSubBox {
  children?: React.ReactNode;
}

const StyledGuideSubBox = styled.div`
  width: 100%;
  padding: 10px 20px;
  box-sizing: border-box;
  margin: 20px 0;
  color: #fff;
  background-color: #444;
`;

const GuideSubBox: React.FC<StyledGuideSubBox> = ({ children }) => {
  return <StyledGuideSubBox>{children}</StyledGuideSubBox>;
};

export default GuideSubBox;

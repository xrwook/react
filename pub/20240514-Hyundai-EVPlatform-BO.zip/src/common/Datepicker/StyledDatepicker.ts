import styled from 'styled-components';
import calenderIcon from '/images/icons/icon-calender.svg';
import previousIcon from '/images/icons/icon-previous.svg';
import nextIcon from '/images/icons/icon-next.svg';
import ReactDatePicker from 'react-datepicker';

export const DatePickerWrapper = styled.div`
  position: relative;

  .react-datepicker__input-container::after {
    content: '';
    position: absolute;
    display: inline-block;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: url(${calenderIcon}) no-repeat;
  }
  .react-datepicker__triangle {
    display: none;
  }

  .react-datepicker-popper {
    z-index: 50;
    transform: unset !important;
    top: 38px !important;
  }
  .react-datepicker {
    width: auto;
    height: auto;
    border: 1px solid #c2c5d2;
    padding: 30px 27px;
  }

  .react-datepicker__month-container {
    width: 100%;
  }
  .react-datepicker__header:not(.react-datepicker__header--has-time-select) {
    border-top-right-radius: unset;
  }
  .react-datepicker__header {
    background-color: #fff;
    border-bottom: none;
    padding: 0;
  }
  .react-datepicker__navigation {
    width: 20px;
    height: 20px;
  }
  .react-datepicker__navigation--previous {
    top: 32px;
    left: 30px;
  }
  .react-datepicker__navigation-icon--previous::before {
    content: '';
    width: 20px;
    height: 20px;
    display: block;
    background: url(${previousIcon}) no-repeat;
    transform: unset;
    border: unset;
  }
  .react-datepicker__navigation--next {
    top: 32px;
    right: 30px;
  }
  .react-datepicker__navigation-icon--next::before {
    content: '';
    width: 20px;
    height: 20px;
    display: block;
    background: url(${nextIcon}) no-repeat;
    transform: unset;
    border: unset;
  }
  .react-datepicker__current-month {
    display: none;
  }
  .react-datepicker__day-names {
    margin-top: 24px;
  }
  .react-datepicker__day-name {
    color: #a0a4b6;
    font-size: 14px;
    line-height: 30px;
    font-weight: 500;
    width: 34px;
    margin: 0 3px;
  }
  .react-datepicker__month {
    margin: 12px 0 0 0;
  }
  .react-datepicker__day {
    color: #2d3145;
    font-size: 14px;
    line-height: 30px;
    font-weight: 500;
    width: 30px;
    margin: 0 5px;
  }
  .react-datepicker__day--outside-month {
    color: #caccd7 !important;
    pointer-events: none;
  }
  .react-datepicker__week {
    height: 30px;
    margin: 4px 0;
  }
  .react-datepicker__day--selected .react-datepicker__day--in-selecting-range,
  .react-datepicker__day--in-range,
  .react-datepicker__day--selected,
  .react-datepicker__day--selected.react-datepicker__day:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start.react-datepicker__day--selecting-range-start,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start.react-datepicker__day--selecting-range-start:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end.react-datepicker__day--selecting-range-end,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end.react-datepicker__day--selecting-range-end:hover {
    color: #5755ff !important;
    border-radius: 100% !important;
    background-color: #3d50ff1a !important;
    width: 30px;
  }
  .react-datepicker__day--in-selecting-range,
  .react-datepicker__day--in-range,
  .react-datepicker__day:hover,
  .react-datepicker__month-text:hover,
  .react-datepicker__quarter-text:hover,
  .react-datepicker__year-text:hover {
    border-radius: 100% !important;
    background-color: #f0f1f4 !important;
  }
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--in-selecting-range,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--in-selecting-range:hover {
    border-radius: 100% !important;
    background-color: #f0f1f4 !important;
  }
  .react-datepicker__header__dropdown,
  .react-datepicker__header__dropdown--select {
    height: 30px;
    display: inline-block;
    padding-top: 3px;
  }
  .react-datepicker__month-select,
  .react-datepicker__year-select {
    appearance: none;
  }
  .react-datepicker__year-dropdown-container--select,
  .react-datepicker__month-dropdown-container--select,
  .react-datepicker__month-year-dropdown-container--select {
    margin: 0 4px;
    font-size: 16px;
    line-height: 24px;
    font-weight: 600;
    color: #2d3145;
  }
`;

export const DatePickerStyle = styled(ReactDatePicker)`
  position: relative;
  border: 1px solid ${(props) => props.theme.color.gray3};
  height: 32px;
  width: 100%;
  border-radius: 4px;
  background-color: ${(props) => props.theme.color.white};
  padding: 6px 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};

  &:focus {
    border: 1px solid #5755ff;
  }
`;

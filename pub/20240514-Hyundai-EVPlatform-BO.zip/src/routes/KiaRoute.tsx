import { Route, Routes } from 'react-router-dom';
// import KiaBrandTest from '../pages/brand/KiaBrandTest';
import KiaBrandTest from 'pages/Brand/KiaBrandTest';

const KiaRoute = () => {
  return (
    <Routes>
      <Route path="brand" element={<KiaBrandTest />} />
    </Routes>
  );
};

export default KiaRoute;

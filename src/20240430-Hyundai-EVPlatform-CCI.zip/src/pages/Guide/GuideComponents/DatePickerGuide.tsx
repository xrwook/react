import styled from 'styled-components';
import { useState } from 'react';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Datepicker from 'common/Datepicker/Datepicker';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const Layout = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
`;

const DatePickerGuide = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  return (
    <StyledGuideWrapper>
      <div style={{ padding: '50px' }}>
        <GuideWrapper>
          <section>
            <GuideText>Datepicker - Basic</GuideText>
            <GuideBox>
              <Datepicker
                selected={startDate}
                onChange={(date) => setStartDate(date)}
                dateFormat="yyyy/MM/dd"
              />
            </GuideBox>

            <GuideSubBox>
              &lt;DatePicker dateFormat="yyyy/MM/dd"&gt; <br />
            </GuideSubBox>
          </section>

          <section style={{ marginTop: '50px' }}>
            <GuideText>Datepicker - Disabled</GuideText>
            <GuideBox>
              <Datepicker
                selected={startDate}
                onChange={(date) => setStartDate(date)}
                dateFormat="yyyy/MM/dd"
                disabled
              />
            </GuideBox>

            <GuideSubBox>
              &lt;DatePicker dateFormat="yyyy/MM/dd" disabled&gt;
            </GuideSubBox>
          </section>

          <section style={{ marginTop: '50px' }}>
            <GuideText>Datepicker - From~To</GuideText>
            <GuideBox>
              <Layout>
                <Datepicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  selectsStart
                  startDate={startDate}
                  endDate={endDate}
                  dateFormat="yyyy/MM/dd"
                />
                <span style={{ margin: '0 10px' }}>-</span>
                <Datepicker
                  selected={endDate}
                  onChange={(date) => setEndDate(date)}
                  selectsEnd
                  startDate={startDate}
                  endDate={endDate}
                  minDate={startDate}
                  dateFormat="yyyy/MM/dd"
                />
              </Layout>
            </GuideBox>

            <GuideSubBox>
              &lt;DatePicker dateFormat="yyyy/MM/dd", startDate/endDate&gt;
            </GuideSubBox>
          </section>

          <section style={{ marginTop: '50px' }}>
            <GuideText>Datepicker - Time</GuideText>
            <GuideBox>
              <Datepicker
                selected={startDate}
                onChange={(date) => setStartDate(date)}
                showTimeSelect
                showTimeSelectOnly
                timeIntervals={15}
                timeCaption="Time"
                dateFormat="h:mm aa"
              />
            </GuideBox>

            <GuideSubBox>
              &lt;DatePicker showTimeSelect showTimeSelectOnly
              timeCaption="Time" dateFormat="h:mm aa"&gt;
            </GuideSubBox>
          </section>
        </GuideWrapper>
      </div>
    </StyledGuideWrapper>
  );
};

export default DatePickerGuide;

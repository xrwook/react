import {
  ServiceContentsWrap,
  ServiceContentsBox,
} from 'pages/Service/StyledService/ServiceContents';

export interface ContentsProps {
  children?: React.ReactNode;
}

const ServiceContents: React.FC<ContentsProps> = ({ children }) => {
  return (
    <ServiceContentsWrap>
      <ServiceContentsBox>{children}</ServiceContentsBox>
    </ServiceContentsWrap>
  );
};

export default ServiceContents;

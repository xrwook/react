import styled, { css } from 'styled-components';

const color = {
  red: css`
    color: #e52a40;
    background-color: #fef4f5;
  `,
  blue: css`
    color: #3089f0;
    background-color: #eef6fe;
  `,
  yellow: css`
    color: #ff9b53;
    background-color: #fff4ec;
  `,
  purple: css`
    color: #5c5cff;
    background-color: #f1f1ff;
  `,
  green: css`
    color: #47a357;
    background-color: #ebf5ed;
  `,
  gray: css`
    color: #8a8ab7;
    background-color: transparent;
  `,
};

const size = {
  small: css`
    height: 18px;
    padding: 0 5px;
  `,
  medium: css`
    height: 24px;
    padding: 2px 6px;
  `,
};

const LabelsWrapper = styled.div`
  display: inline-block;
`;

const LabelStyle = styled.div<LabelsProps>`
  width: auto;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  ${(props) => color[props.color]};
  ${(props) => size[props.size]};
`;

export interface LabelsProps {
  children?: any;
  color: 'red' | 'blue' | 'yellow' | 'purple' | 'green' | 'gray';
  size: 'small' | 'medium';
}

const Labels: React.FC<LabelsProps> = ({ children, color, size }) => {
  return (
    <LabelsWrapper>
      <LabelStyle color={color} size={size}>
        {children}
      </LabelStyle>
    </LabelsWrapper>
  );
};

export default Labels;

import { useState } from 'react';
import Alert from 'common/Alert';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargingStationsRegistrationAlertContainer: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);

  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        충전기 삭제
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertContent>
            페이지를 나가는 경우 작성했던 정보는 모두 삭제됩니다.
            <br />
            그래도 페이지를 나가시겠습니까?
          </AlertContent>
          <AlertFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowAlert(false)}
                $size="large"
                $variant="secondaryGray"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={77}
              >
                나가기
              </Button>
            </ButtonGroup>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargingStationsRegistrationAlertContainer;

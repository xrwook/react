import React from 'react';
import styled from 'styled-components';

const StepProgressContainer = styled.div`
  display: flex;
  width: 100%;
  height: 15px;
  border-radius: 10px;
  overflow: hidden;
`;

const Step = styled.div<StepProps>`
  flex: 1;
  background-color: ${(props) => (props.$active ? props.$background : '#ddd')};
  display: flex;
  justify-content: center;
  align-items: center;
  color: #000;
`;

interface StepProgressProps {
  total: number;
  current: number;
  background: string;
}

interface StepProps {
  $active: boolean;
  $background: string;
}

const StepProgress: React.FC<StepProgressProps> = ({
  total,
  current,
  background,
}) => (
  <StepProgressContainer>
    {[...Array(total).keys()].map((index) => (
      <Step
        key={index + 1}
        $active={index < current}
        $background={background}
      />
    ))}
  </StepProgressContainer>
);

export default StepProgress;

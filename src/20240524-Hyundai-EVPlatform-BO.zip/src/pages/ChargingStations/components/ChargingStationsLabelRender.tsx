import Labels from 'common/Labels/Labels';
import { RenderCommonWrap } from '../styled/StyledChargingStations';

export interface ChargingStationsLabelRenderProps {
  status?: string | undefined;
}

const ChargingStationsLabelRender: React.FC<
  ChargingStationsLabelRenderProps
> = ({ status = '' }) => {
  const statusMap: Record<string, any> = {
    pending: { name: '등록대기', color: 'yellow' },
    completed: { name: '등록완료', color: 'blue' },
    notAllowed: { name: '등록불가', color: 'red' },
  };
  const result: any = statusMap[status] || '';
  return (
    <RenderCommonWrap>
      <Labels $color={result.color} $size="medium">
        {result.name}
      </Labels>
    </RenderCommonWrap>
  );
};

export default ChargingStationsLabelRender;

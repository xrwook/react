import { useState } from 'react';
import Title from 'common/Title';
import Header from 'layout/Header';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import TextField from 'common/TextField';
import Select from 'common/Select';
import Accordion from 'common/Accordion';
import AgGrid from 'common/AgGrid';
import FormFlex from 'common/FormFlex';
import Textarea from 'common/Textarea';
import DatePicker from 'common/Datepicker/Datepicker';
import PageFooter from 'common/PageFooter';
import Button from 'common/Button';
import { ContentContainer } from 'layout/StyledLayout';
import {
  ChargerIssuesEditRowData,
  ChargerIssuesEditColumnDefs,
  ChargerIssuesRegistrationrowData,
  ChargerIssuesRegistrationcolumnDefs,
} from '../components/detailData';
import FileSearch from 'common/FileSearch';
import {
  ChargerIssuesEditOption,
  ChargerIssuesEditOption2,
  ChargerIssuesEditOption3,
} from '../components/data';

const ChargerIssuesEditContainer: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());

  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전기 고장 관리' },
    { to: '/', text: '고장 수정', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="충전소 고장 수정"
        $titleguide
        $titleGuideText="표시는 필수 입력항목입니다"
      />

      <ContentContainer $gap="48px">
        <section>
          <Title titlemain="기본 정보" $pagetitle />

          <Grid $columns={4} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem $colStart={1} $colEnd={2}>
              <Formcontrol title="충전소 이름" $row required>
                <TextField
                  id="TextField01"
                  name="TextField01"
                  type="text"
                  placeholder=""
                  value="이마트 세종점 HD충전소"
                  $width="480"
                  disabled
                />
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={2}>
              <Formcontrol title="충전기 이름" $row required>
                <TextField
                  id="TextField02"
                  name="TextField02"
                  type="text"
                  placeholder=""
                  value="전북 테스트 충전기"
                  $width="480"
                  disabled
                />
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={2}>
              <Formcontrol title="EVSE ID" $row>
                <Select
                  inputId="Select01"
                  name="Select01"
                  placeholder=""
                  options={ChargerIssuesEditOption}
                  defaultValue={ChargerIssuesEditOption[0]}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Accordion title="EVSE /  커넥터 정보" open>
            <AgGrid
              rowData={ChargerIssuesEditRowData}
              columnDefs={ChargerIssuesEditColumnDefs}
              hasGridTop={false}
              noneButton
            />
          </Accordion>
        </section>

        <section>
          <Title titlemain="고장 정보" $pagetitle />

          <Grid $columns={2} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="고장 유형" $row required>
                <Select
                  inputId="Select02"
                  name="Select02"
                  placeholder="고장 유형 선택"
                  options={ChargerIssuesEditOption2}
                  defaultValue={ChargerIssuesEditOption2[0]}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="고장 발생 일시" $row>
                <FormFlex>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    selectsStart
                    startDate={startDate}
                    dateFormat="yyyy/MM/dd"
                  />
                  <div className="time">
                    <DatePicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      showTimeSelect
                      showTimeSelectOnly
                      timeIntervals={15}
                      timeCaption="Time"
                      dateFormat="h:mm aa"
                    />
                  </div>
                </FormFlex>
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="고장 구분" $row required>
                <Select
                  inputId="Select03"
                  name="Select03"
                  placeholder="고장 구분 선택"
                  options={ChargerIssuesEditOption3}
                  defaultValue={ChargerIssuesEditOption3[1]}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="고장 조치 완료 일시" $row>
                {/* DD: 조치 완료 상태일 경우 고장 조치 된 날짜 표기 비활성화 처리 */}
                <FormFlex>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    selectsStart
                    startDate={startDate}
                    dateFormat="yyyy/MM/dd"
                    disabled
                  />
                  <div className="time">
                    <DatePicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      showTimeSelect
                      showTimeSelectOnly
                      timeIntervals={15}
                      timeCaption="Time"
                      dateFormat="h:mm aa"
                      disabled
                    />
                  </div>
                </FormFlex>
                {/*  */}
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="고장 접수 내용" $row>
                <Textarea height="120px" maxLength={500} total={500} />
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="첨부파일" $row>
                <FileSearch
                  text="* 이미지 최적의 해상도 450 x 300, 10MB 이하 (jpg,png)"
                  dnd
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title titlemain="담당자 정보" $pagetitle />

          <div style={{ marginTop: '24px' }}>
            <AgGrid
              rowData={ChargerIssuesRegistrationrowData}
              columnDefs={ChargerIssuesRegistrationcolumnDefs}
              hasGridTop={true}
              noneButton
              nonePerPageSelect
              addButton
            />
          </div>
        </section>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          취소
        </Button>
        <Button onClick={() => {}} $size="large" $variant="primary">
          저장
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargerIssuesEditContainer;

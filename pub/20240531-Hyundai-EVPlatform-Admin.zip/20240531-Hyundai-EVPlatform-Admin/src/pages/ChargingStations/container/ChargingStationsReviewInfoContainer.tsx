import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import FormcontrolItem from 'common/FormcontrolItem';
import Labels from 'common/Labels';
import CardStatus from 'common/Card/CardStatus';
import { FileAttachArea } from 'common/FileSearch/StyledFileSearch';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargingStationsReviewInfo: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  return (
    <>
      {showModal && (
        <Modal width="800px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader>리뷰 상세 정보</ModalHeader>

          <ModalContent $marginBottom="36px">
            <Grid $columns={2} $gap="24px 24px">
              <GridItem>
                <Formcontrol title="작성일" $detail $gapMini>
                  <FormcontrolItem>2024-04-23 11:13</FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem>
                <Formcontrol title="상태" $detail $gapMini>
                  <FormcontrolItem $small>
                    {/* Case : 승인대기일 경우 */}
                    <Labels $color="yellowWhite" $size="default">
                      승인대기
                    </Labels>
                    {/* Case : 승인대기일 경우 */}
                    {/* Case : 승인거부일 경우 */}
                    <Labels $color="redWhite" $size="default">
                      승인거부
                    </Labels>
                    {/* Case : 승인거부일 경우 */}
                    {/* Case : 승인완료일 경우 */}
                    <Labels $color="blueWhite" $size="default">
                      승인완료
                    </Labels>
                    2024-04-23 11:13
                    {/* Case : 승인완료일 경우 */}
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem>
                <Formcontrol title="회원그룹" $detail $gapMini>
                  <FormcontrolItem $small>프라임</FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem>
                <Formcontrol title="회원코드" $detail $gapMini>
                  <FormcontrolItem $small>123123123123123123</FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem $colStart={1} $colEnd={3}>
                <Formcontrol title="리뷰 내용" $detail $gapMini>
                  <FormcontrolItem $small>
                    리뷰 내용을 표시합니다. 리뷰 내용을 표시합니다. 리뷰 내용을
                    표시합니다.리뷰 내용을 표시합니다. 리뷰 내용을
                    표시합니다.리뷰 내용을 표시합니다.리뷰 내용을
                    표시합니다.리뷰 내용을 표시합니다. 리뷰 내용을 표시합니다.
                    리뷰 내용을 표시합니다. 리뷰 내용을 표시합니다.리뷰 내용을
                    표시합니다. 리뷰 내용을 표시합니다.리뷰 내용을
                    표시합니다.리뷰 내용을 표시합니다.리뷰 내용을 표시합니다.
                    리뷰 내용을 표시합니다. 리뷰 내용을 표시합니다. 리뷰 내용을
                    표시합니다.리뷰 내용을 표시합니다.
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem>
                <Formcontrol title="충전여부" $detail $gapMini>
                  <FormcontrolItem $none $center>
                    {/* Case : 승인대기 / 승인완료일 경우 */}
                    <CardStatus $color="green" />
                    충전성공
                    {/* Case : 승인대기 / 승인완료일 경우 */}
                    {/* Case : 승인거부일 경우 */}
                    <CardStatus $color="red" />
                    충전실패
                    {/* Case :승인거부일 경우 */}
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem>
                <Formcontrol title="담당자" $detail $gapMini>
                  <FormcontrolItem $none $center>
                    -
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>

              <GridItem $colStart={1} $colEnd={3}>
                <Formcontrol title="이미지" $detail $gapMini>
                  <FormcontrolItem $none $center>
                    <FileAttachArea $small>
                      <div
                        className="file-attach-area"
                        data-file={'img-attach01.jfif'}
                      >
                        <img src="/images/dummy/img-attach01.jfif" />
                      </div>
                      <div
                        className="file-attach-area "
                        data-file={'img-attach01.jfif'}
                      >
                        <img src="/images/dummy/img-attach01.jfif" />
                      </div>
                      <div
                        className="file-attach-area "
                        data-file={'img-attach02.jfif'}
                      >
                        <img src="/images/dummy/img-attach02.jfif" />
                      </div>
                      <div
                        className="file-attach-area "
                        data-file={'img-attach01.jfif'}
                      >
                        <img src="/images/dummy/img-attach01.jfif" />
                      </div>
                      <div
                        className="file-attach-area "
                        data-file={'img-attach02.jfif'}
                      >
                        <img src="/images/dummy/img-attach02.jfif" />
                      </div>
                    </FileAttachArea>
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>
            </Grid>
          </ModalContent>
          {/* Case : 승인완료일 경우 footer 삭제 */}
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              {/* Case : 승인대기일 경우 */}
              <Button
                onClick={() => {}}
                $size="large"
                $variant="tertiary"
                $width={92}
              >
                등록 거부
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={92}
              >
                등록 승인
              </Button>
              {/* Case : 승인대기일 경우 */}
              {/* Case : 승인거부일 경우 */}
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                삭제
              </Button>
              {/* Case : 승인거부일 경우 */}
            </ButtonGroup>
          </ModalFooter>
          {/* Case : 승인완료일 경우 footer 삭제 */}
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsReviewInfo;

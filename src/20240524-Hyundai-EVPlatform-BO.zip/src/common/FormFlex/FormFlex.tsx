import React from 'react';
import { FormFlexWrap } from './StyledFormFlex';

export interface FormFlexProps {
  children?: React.ReactNode;
  $gap?: string;
  $width?: any;
}

const FormFlex: React.FC<FormFlexProps> = ({ children, $gap, $width }) => {
  return (
    <FormFlexWrap $gap={$gap} $width={$width}>
      {children}
    </FormFlexWrap>
  );
};

export default FormFlex;

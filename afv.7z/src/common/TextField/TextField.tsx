import styled from 'styled-components';

const InputText = styled.input<TextFieldProps>`
  display: block;
  padding: 10px 15px;
  width: 100%;
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
  color: ${(props) => (props.disabled ? '#c7c7c7' : '#000')};
  border: ${(props) =>
    props.disabled
      ? '1px solid #f7f7f7'
      : props.readOnly
        ? '1px solid #ebebeb'
        : props.error
          ? '1px solid #F15454'
          : '1px solid #e3e3e3'};
  border-radius: 4px;
  background-color: ${(props) =>
    props.readOnly ? '#ebebeb' : props.disabled ? '#f7f7f7' : '#fff'};

  &::placeholder {
    color: #aaaaaa;
  }

  &:hover {
    border: 1px solid #c0bfbf;
  }

  &:focus {
    outline: none;
    border: 1px solid #0057ff;
  }
`;

export interface TextFieldProps {
  type?: any;
  id?: any;
  name?: any;
  value?: any;
  placeholder?: any;
  disabled?: any;
  readOnly?: any;
  error?: any;
}

const TextField: React.FC<TextFieldProps> = ({
  type,
  id,
  name,
  value,
  placeholder,
  disabled,
  readOnly,
  error = false,
}) => {
  return (
    <InputText
      id={id}
      name={name}
      type={type}
      value={value}
      disabled={disabled}
      readOnly={readOnly}
      placeholder={placeholder}
      error={error ? 'true' : undefined}
    />
  );
};

export default TextField;

import Button from 'common/Button';
import { defaultTheme, components } from 'react-select';
import { ReactNode, useState } from 'react';
import {
  ArrowButton,
  CheckBox,
  Icon,
  MenuFooter,
  SelectInput,
  SelectStyle,
  SelectText,
} from '../Select/StyledSelect';
import {
  MenuContainer,
  MenuHeader,
  MenuTitle,
  MenuWrapper,
} from './StyledSelectSearch';

export type Option = {
  value: number | string;
  label: string;
};

export interface SelectSearchProps {
  $checkbox?: any;
  classNamePrefix?: any;
  placeholder?: any;
  options?: any;
  $button?: any;
  label?: any;
  $menuTitle?: any;
}

const SelectSearch: React.FC<SelectSearchProps> = ({
  $checkbox,
  classNamePrefix,
  placeholder,
  options,
  $button,
  $menuTitle,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [value, setValue] = useState<SelectSearchProps>();
  const { colors } = defaultTheme;

  const Option = (props: any) => (
    <components.Option {...props}>
      <CheckBox
        key={props.value}
        type="checkbox"
        checked={props.isSelected}
        onChange={() => {}}
        $checkbox={$checkbox}
      />
      <label>{props.label}</label>
    </components.Option>
  );

  const Menu = (props: any) => {
    return (
      <>
        <MenuContainer>
          <MenuHeader>
            <MenuTitle $menuTitle={$menuTitle}>{$menuTitle}</MenuTitle>
            <MenuWrapper>{props.children}</MenuWrapper>
          </MenuHeader>
          <MenuFooter $button={$button}>
            <Button onClick={() => {}} $size="small" $variant="transparent">
              초기화
            </Button>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="transparentPurple"
            >
              적용
            </Button>
          </MenuFooter>
        </MenuContainer>
      </>
    );
  };

  const Blanket = (props: any) => <Icon {...props} />;

  const Dropdown = ({
    children,
    target,
    onClose,
  }: {
    children?: ReactNode;
    readonly isOpen: boolean;
    readonly target: ReactNode;
    readonly onClose: () => void;
  }) => (
    <span style={{ position: 'relative' }}>
      {target}
      {isOpen ? <Menu>{children}</Menu> : null}
      {isOpen ? <Blanket onClick={onClose} /> : null}
    </span>
  );
  const Svg = (p: any) => (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      focusable="false"
      role="presentation"
      {...p}
    />
  );
  const DropdownIndicator = () => (
    <span style={{ color: colors.neutral20, height: 24, width: 32 }}>
      <Svg>
        <path
          d="M16.436 15.085l3.94 4.01a1 1 0 0 1-1.425 1.402l-3.938-4.006a7.5 7.5 0 1 1 1.423-1.406zM10.5 16a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11z"
          fill="currentColor"
          fillRule="evenodd"
        />
      </Svg>
    </span>
  );

  return (
    <Dropdown
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      target={
        <SelectInput onClick={() => setIsOpen((prev) => !prev)}>
          <SelectText value={value}>
            {value ? `${value.label}` : placeholder}
          </SelectText>
          <ArrowButton className="arrow-down" isOpen={isOpen}></ArrowButton>
        </SelectInput>
      }
    >
      <SelectStyle
        autoFocus
        classNamePrefix={classNamePrefix}
        backspaceRemovesValue={false}
        components={{
          DropdownIndicator,
          IndicatorSeparator: null,
          Option: Option,
        }}
        controlShouldRenderValue={false}
        hideSelectedOptions={false}
        isClearable={false}
        menuIsOpen
        onChange={(newValue: any) => {
          setValue(newValue);
          setIsOpen(false);
        }}
        options={options}
        placeholder={placeholder}
        styles={{
          control: (provided) => ({
            ...provided,
            minWidth: 240,
            margin: 8,
          }),
          menu: () => ({
            boxShadow: 'inset 0 1px 0 rgba(0, 0, 0, 0.1)',
          }),
        }}
        tabSelectsValue={false}
        value={value}
      />
    </Dropdown>
  );
};

export default SelectSearch;

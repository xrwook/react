import { Breadcrumbhome } from './StyledBreadcrumb';

export interface BreadcrumbHomeProps {
  children?: any;
  to?: any;
}

const BreadcrumbHome: React.FC<BreadcrumbHomeProps> = ({ children, to }) => {
  return <Breadcrumbhome to={to}>{children}</Breadcrumbhome>;
};

export default BreadcrumbHome;

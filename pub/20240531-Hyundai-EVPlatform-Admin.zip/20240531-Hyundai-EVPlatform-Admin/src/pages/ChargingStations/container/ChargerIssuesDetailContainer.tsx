import Accordion from 'common/Accordion';
import Button from 'common/Button';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Title from 'common/Title';
import Header from 'layout/Header';
import FormControl from 'common/FormControl';
import AgGrid from 'common/AgGrid';
import PageFooter from 'common/PageFooter';
import Labels from 'common/Labels';
import { FileAttachArea } from 'common/FileSearch/StyledFileSearch';
import { ButtonGroup } from 'common/Button/StyledButton';
import { ContentContainer } from 'layout/StyledLayout';
import {
  ChargerIssuesEditRowData,
  ChargerIssuesEditColumnDefs,
  ChargerIssuesDetailColumnDefs,
  ChargerIssuesDetailRowData,
} from '../components/detailData';

const ChargerIssuesDetailContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전기 고장 관리' },
    { to: '/', text: '고장 상세', className: 'active' },
  ];

  // dummy images
  const images = [
    { id: 1, name: '/images/dummy/img-attach.png' },
    { id: 2, name: '/images/dummy/img-attach02.jfif' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="#1_전라북도 테스트 충전소"
        $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
        label={
          <Labels $color="red" $size="medium">
            조치 필요
          </Labels>
        }
      >
        <ButtonGroup $gap={8} $direction={'row'}>
          <Button
            onClick={() => {}}
            $size="large"
            $variant="secondaryBlue"
            $width={65}
          >
            삭제
          </Button>
          <Button
            onClick={() => {}}
            $size="large"
            $variant="primary"
            $width={65}
          >
            수정
          </Button>
        </ButtonGroup>
      </Title>

      <ContentContainer $gap="48px">
        <Accordion title="기본 정보" open>
          <Grid $columns={1} $gap="12px 120px">
            <GridItem>
              <FormControl title="충전소" $detail $row>
                전라북도 테스트 충전소 ㅣ 전북특별자치도 김제시 만경읍 대동길471
                물류센터 내부
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="EVSE ID" $detail $row>
                [KREPTE0002170001] #1
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="제조사/모델" $detail $row>
                그린파워 SK Green green0000101
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="충전기 구분/모델" $detail $row>
                초고속
              </FormControl>
            </GridItem>
          </Grid>
        </Accordion>

        <Accordion title="EVSE /  커넥터 정보" open>
          <AgGrid
            rowData={ChargerIssuesEditRowData}
            columnDefs={ChargerIssuesEditColumnDefs}
            hasGridTop={false}
            noneButton
          />
        </Accordion>

        <section>
          <Title titlemain="고장 정보" $pagetitle>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="primary"
              $width={84}
            >
              고장 조치
            </Button>
          </Title>

          <Grid $columns={2} $gap="12px 120px" margin="24px 0 0 0">
            <GridItem>
              <FormControl title="고장 유형" $detail $row>
                하드웨어
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="고장 발생 일시" $detail $row>
                2024-04-26 00:00
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="고장 구분" $detail $row>
                메인보드
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="고장 조치 완료 일시" $detail $row>
                -
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="고장 접수 내용" $detail $row>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cill.
              </FormControl>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="첨부 파일" $detail $row>
                <FileAttachArea>
                  {images.map((image: any) => (
                    <div
                      className="file-attach-area"
                      key={image.id}
                      data-file={image.name.replace(/^.*\//, '')}
                    >
                      <img src={image.name} />
                    </div>
                  ))}
                </FileAttachArea>
              </FormControl>
            </GridItem>
          </Grid>
        </section>

        <Accordion title="담당자 정보" open>
          <AgGrid
            rowData={ChargerIssuesDetailRowData}
            columnDefs={ChargerIssuesDetailColumnDefs}
            hasGridTop={false}
            noneButton
          />
        </Accordion>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          목록으로 돌아가기
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargerIssuesDetailContainer;

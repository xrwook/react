import styled from 'styled-components';
import React from 'react';

export interface StyledGuideSubBox {
  children?: React.ReactNode;
}

const StyledGuideSubBox = styled.div`
  width: 100%;
  padding: 16px;
  box-sizing: border-box;
  margin: 20px 0;
  color: ${(props) => props.theme.color.white};
  background-color: ${(props) => props.theme.color.gray8};
  border-radius: 8px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
`;

const GuideSubBox: React.FC<StyledGuideSubBox> = ({ children }) => {
  return <StyledGuideSubBox>{children}</StyledGuideSubBox>;
};

export default GuideSubBox;

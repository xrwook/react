import classes from './Spinner.module.scss';

const Spinner = () => <div className={classes.loader} />;

export default Spinner;

import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Title from 'common/Title/Title';
import Button from 'common/Button/Button';
import arrowIcon from '/images/icons/icon-arrow.svg';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import { ButtonGroup } from 'common/Button/StyledButton';

const Layout = styled.div`
  display: flex;
  flex-direction: column;
  gap: 30px;
`;

const ArrowIcon = styled.div`
  width: 20px;
  height: 20px;
  background: url(${arrowIcon}) no-repeat;
`;

const TitleGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Title</GuideText>
        <GuideBox>
          <Layout>
            <Title
              titlemain="Current Page Title"
              $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
            >
              <ButtonGroup $gap={8}>
                <Button onClick={() => {}} $size="large" $variant="primary">
                  Button
                </Button>
                <Button onClick={() => {}} $size="large" $variant="primary">
                  Button
                </Button>
              </ButtonGroup>
            </Title>

            <Title
              titlemain="Current Page Title"
              $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
            />

            <Title titlemain="Current Page Title">
              <ButtonGroup $gap={8}>
                <Button onClick={() => {}} $size="large" $variant="primary">
                  Button
                </Button>
                <Button onClick={() => {}} $size="large" $variant="primary">
                  Button
                </Button>
              </ButtonGroup>
            </Title>

            <Title titlemain="Current Page Title" />

            <Title titlemain="Current Page Title" $titleguide />

            <Title titlemain="Page Title" $pagetitle>
              <ButtonGroup $gap={8}>
                <Button onClick={() => {}} $size="small" $variant="primary">
                  Button
                </Button>
                <Button onClick={() => {}} $size="small" $variant="primary">
                  Button
                </Button>
              </ButtonGroup>
            </Title>

            <Title titlemain="Page Title" $pagetitle />

            <Title titlemain="Page Title" $pagetitle $titleguide />

            <Title titlemain="Page Title" $pagetitle>
              <ArrowIcon />
            </Title>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          {`<Title
              titlemain="Current Page Title"
              $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
            >contents</Title>`}
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>titlemain</td>
              <td>titlemain="Current Page Title"</td>
              <td>main title</td>
              <td></td>
            </tr>
            <tr>
              <td>$titlesub</td>
              <td>
                $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
              </td>
              <td>main title 밑의 sub title</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TitleGuide;

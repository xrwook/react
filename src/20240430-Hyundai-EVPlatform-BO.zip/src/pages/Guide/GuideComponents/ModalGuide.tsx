import styled from 'styled-components';
import { useState } from 'react';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Modal from 'common/Modal/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const ModalGuide = () => {
  const [showModal, setShowModal] = useState(false);
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Modal</GuideText>
        <GuideBox>
          <button name="" onClick={() => setShowModal(true)}>
            Open Modal
          </button>
          {showModal && (
            <Modal
              width="500px"
              height="auto"
              onClose={() => setShowModal(false)}
            >
              <ModalHeader>Title</ModalHeader>
              <ModalContent>
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
              </ModalContent>
              <ModalFooter>footer</ModalFooter>
            </Modal>
          )}
        </GuideBox>
        <GuideSubBox>
          &lt;Modal width="" height="" onClose&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalHeader&gt;&lt;/ModalHeader&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalContent&gt;&lt;/ModalContent&gt; <br />
          &lt;/Modal&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default ModalGuide;

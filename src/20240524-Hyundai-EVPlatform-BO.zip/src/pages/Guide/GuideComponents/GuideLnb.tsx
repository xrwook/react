import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const datasComponents = [
  {
    title: 'Accordion',
    url: '/guidelist/Accordion',
  },
  {
    title: 'AgGrid',
    url: '/guidelist/AgGrid',
  },
  {
    title: 'Alert',
    url: '/guidelist/Alert',
  },
  {
    title: 'Badge',
    url: '/guidelist/Badge',
  },
  {
    title: 'Breadcrumb',
    url: '/guidelist/Breadcrumb',
  },
  {
    title: 'Button',
    url: '/guidelist/Button',
  },
  {
    title: 'Card',
    url: '/guidelist/Card',
  },
  {
    title: 'CheckBox',
    url: '/guidelist/CheckBox',
  },
  {
    title: 'DatePicker',
    url: '/guidelist/DatePicker',
  },
  {
    title: 'Dropdown',
    url: '/guidelist/Dropdown',
  },
  {
    title: 'Editor',
    url: '/guidelist/Editor',
  },
  {
    title: 'Filter',
    url: '/guidelist/Filter',
  },
  {
    title: 'FileSearch',
    url: '/guidelist/FileSearch',
  },
  {
    title: 'FormControl',
    url: '/guidelist/FormControl',
  },
  {
    title: 'Icon',
    url: '/guidelist/Icon',
  },
  {
    title: 'Labels',
    url: '/guidelist/Labels',
  },
  {
    title: 'Modal',
    url: '/guidelist/Modal',
  },
  {
    title: 'Popover',
    url: '/guidelist/Popover',
  },
  {
    title: 'Radio',
    url: '/guidelist/Radio',
  },
  {
    title: 'Select',
    url: '/guidelist/Select',
  },
  {
    title: 'Tab',
    url: '/guidelist/Tab',
  },
  {
    title: 'TextField',
    url: '/guidelist/TextField',
  },
  {
    title: 'Textarea',
    url: '/guidelist/Textarea',
  },

  {
    title: 'Title',
    url: '/guidelist/Title',
  },
  {
    title: 'Toggle',
    url: '/guidelist/Toggle',
  },
  {
    title: 'Tooltip',
    url: '/guidelist/Tooltip',
  },
];

const LnbWrap = styled.div`
  position: fixed;
  width: 180px;
  height: 100%;
  padding: 20px 10px 0;
  background-color: ${(props) => props.theme.color.white};
  border-right: 1px solid ${(props) => props.theme.color.gray3};
  transition: margin-left 0.3s ease;
  overflow-y: auto;
  z-index: 40;
`;

const LnbList = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;

const LnbMenuItem = styled.div`
  font-size: 1rem;
  font-weight: bold;
  color: inherit;
  text-decoration: none;
  margin-bottom: 20px;
`;

const LnbTitle = styled.h2`
  padding: 10px 0;
  font-size: ${(props) => props.theme.fontSize.fontSize6};
  font-weight: bold;
  cursor: pointer;
`;

const LnbItem = styled.li`
  color: ${(props) => props.theme.color.black};
  border-radius: 4px;

  &:hover {
    background-color: ${(props) => props.theme.color.primary};
    color: ${(props) => props.theme.color.white};
    transition: all 130ms;
  }

  a {
    display: block;
    padding: 4px;
    margin: 2px 0;
    width: 100%;
    font-size: ${(props) => props.theme.fontSize.fontSize4};
  }
`;

const LnbMapList = styled.div`
  cursor: pointer;
`;

const GuideLnb: React.FC = () => {
  return (
    <LnbWrap>
      <ul>
        <li>
          <LnbList>
            <LnbMenuItem>
              <Link
                to="/publishinglist"
                style={{
                  textDecoration: 'none',
                  color: '#ffffff',
                  fontSize: '14px',
                  fontWeight: 700,
                  padding: '6px 10px',
                  borderRadius: '6px',
                  backgroundColor: '#5755FF',
                }}
              >
                Publish List
              </Link>
            </LnbMenuItem>
          </LnbList>
        </li>
        <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Components</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasComponents.map((datasComponents, index) => (
                <LnbItem key={index}>
                  <Link to={datasComponents.url}>{datasComponents.title}</Link>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li>
      </ul>
    </LnbWrap>
  );
};

export default GuideLnb;

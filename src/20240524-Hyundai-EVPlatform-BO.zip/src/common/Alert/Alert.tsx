import { AlertBox, AlertWrapper, Dim } from './StyledAlert';

export interface AlertProps {
  children?: any;
  width?: string;
  height?: string;
}

const Alert: React.FC<AlertProps> = ({ children, width, height }) => {
  return (
    <>
      <AlertWrapper>
        <AlertBox width={width} height={height}>
          {children}
        </AlertBox>
      </AlertWrapper>
      <Dim />
    </>
  );
};

export default Alert;

import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Title from 'common/Title/Title';
import Button from 'common/Button/Button';
import arrowIcon from '/images/icons/icon-arrow.svg';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const Layout = styled.div`
  display: flex;
  flex-direction: column;
  gap: 30px;
`;

const ArrowIcon = styled.div`
  width: 20px;
  height: 20px;
  background: url(${arrowIcon}) no-repeat;
`;

const TitleGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Title</GuideText>
        <GuideBox>
          <Layout>
            <Title
              titlemain="Current Page Title"
              $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
            >
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
            </Title>

            <Title
              titlemain="Current Page Title"
              $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
            />

            <Title titlemain="Current Page Title">
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="large" $variant="primary">
                Button
              </Button>
            </Title>

            <Title titlemain="Current Page Title" />

            <Title titlemain="Current Page Title" $titleguide />

            <Title titlemain="Page Title" $pagetitle>
              <Button onClick={() => {}} $size="small" $variant="primary">
                Button
              </Button>
              <Button onClick={() => {}} $size="small" $variant="primary">
                Button
              </Button>
            </Title>

            <Title titlemain="Page Title" $pagetitle />

            <Title titlemain="Page Title" $pagetitle $titleguide />

            <Title titlemain="Page Title" $pagetitle>
              <ArrowIcon />
            </Title>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Title titlemain="" titlesub="" pagetitle titleguide /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TitleGuide;

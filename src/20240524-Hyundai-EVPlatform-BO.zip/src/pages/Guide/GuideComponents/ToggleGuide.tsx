import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Toggle from 'common/Toggle';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const ToggleGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Toggle-Switch</GuideText>
        <GuideBox>
          <Toggle />
          <Toggle disabled />
          <Toggle defaultChecked />
          <Toggle defaultChecked disabled />
          <Toggle label="Label" />
          <Toggle label="Label" disabled />
          <Toggle label="Label" defaultChecked />
          <Toggle label="Label" defaultChecked disabled />
        </GuideBox>
        <GuideSubBox>
          {`<Toggle />
          <Toggle disabled />
          <Toggle defaultChecked />
          <Toggle defaultChecked disabled />
          <Toggle label="Label" />
          <Toggle label="Label" disabled />
          <Toggle label="Label" defaultChecked />
          <Toggle label="Label" defaultChecked disabled />`}
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>defaultChecked</td>
              <td>defaultChecked</td>
              <td>checked 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>label</td>
              <td>label="Label"</td>
              <td>toggle Label</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default ToggleGuide;

import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import FilterLabel from 'common/Filter/FilterLabel';
import TextField from 'common/TextField';
import Select from 'common/Select/Select';
import SelectSearch from 'common/SelectSearch/';
import {
  ChargingStationStatusListOption,
  ChargingStationStatusListOption2,
  ChargingStationStatusListOption3,
  ChargingStationStatusListOption4,
  ChargingStationStatusListOption5,
} from './data';

const FilterChargingStationStatusList: React.FC = () => {
  return (
    <FilterList useDetailButtons>
      <FilterItem $search>
        <TextField
          id="TextField01"
          name="text"
          type="text"
          placeholder="충전소 이름으로 검색"
          $search
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>사업자 :</FilterLabel>
        <SelectSearch
          $menuTitle="사업자"
          placeholder="사업자 이름"
          isMulti
          options={ChargingStationStatusListOption}
          classNamePrefix="react-select"
          $button
          $all={true}
          $transparent
          $checkbox
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>권역 :</FilterLabel>
        <Select
          options={ChargingStationStatusListOption2}
          defaultValue={ChargingStationStatusListOption2[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>태그 :</FilterLabel>
        <Select
          options={ChargingStationStatusListOption3}
          defaultValue={ChargingStationStatusListOption3[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>결제방식 :</FilterLabel>
        <Select
          options={ChargingStationStatusListOption4}
          defaultValue={ChargingStationStatusListOption4[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>인증방식 :</FilterLabel>
        <Select
          options={ChargingStationStatusListOption5}
          defaultValue={ChargingStationStatusListOption5[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
    </FilterList>
  );
};

export default FilterChargingStationStatusList;

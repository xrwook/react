import { LayoutWrap } from './StyledLayout';

export interface LayoutProps {}

const Layout: React.FC<LayoutProps> = ({
  children,
}: React.PropsWithChildren) => {
  return <LayoutWrap>{children}</LayoutWrap>;
};

export default Layout;

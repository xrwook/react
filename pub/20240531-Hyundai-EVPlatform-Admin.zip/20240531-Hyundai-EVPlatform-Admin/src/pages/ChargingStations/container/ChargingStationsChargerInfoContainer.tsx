import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import Accordion from 'common/Accordion';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import FormcontrolItem from 'common/FormcontrolItem';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import AgGrid from 'common/AgGrid';
import {
  ChargingStationsChargerInfoRowData,
  ChargingStationsChargerInfoColumnDefs,
  chargingStationsDetailOption,
} from '../components/detailData';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargingStationsChargerInfoContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);

  return (
    <>
      {showModal && (
        <Modal
          width="1104px"
          height="auto"
          oversize
          onClose={() => setShowModal(false)}
        >
          <ModalHeader>충전기 상세</ModalHeader>
          <ModalContent>
            <Accordion title="기본 정보" open>
              <Grid $columns={2} $gap="24px 80px">
                <GridItem $colStart={1} $colEnd={3}>
                  <Formcontrol title="충전기 이름" $detail $gapSmall>
                    <FormcontrolItem>
                      HD_Park Plaza Charing Station
                    </FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem $colStart={1} $colEnd={3}>
                  <Formcontrol title="충전소 주소" $detail $gapSmall>
                    <FormcontrolItem $small>
                      Park Plaze Irvine, CA 92614 (권역 ex: California)
                      <Button
                        onClick={() => {}}
                        $size="mini"
                        $variant="secondaryGray"
                        $width={65}
                      >
                        지도 보기
                      </Button>
                    </FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="사업자" $detail $gapSmall>
                    <img src="/images/logo/logo02.svg" alt="로고" />
                    <span className="normal-text">ChargePoint</span>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="운영 상태" $detail $gapSmall>
                    <FormcontrolItem>운영중</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="충전 서비스 유형" $detail $gapSmall>
                    <FormcontrolItem>Charging Only</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="시공 방식" $detail $gapSmall>
                    <FormcontrolItem>시공 방식</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="제조사/모델" $detail $gapSmall>
                    <FormcontrolItem>제조사/모델</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="충전기 용량" $detail $gapSmall>
                    <FormcontrolItem>
                      350 kW[실 허용 용량 : 260 kW]
                    </FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="충전기 속도" $detail $gapSmall>
                    <FormcontrolItem>초고속</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="충전기 구분" $detail $gapSmall>
                    <FormcontrolItem>유선</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="아울렛 유형" $detail $gapSmall>
                    <FormcontrolItem>Type 1 Combo 급속</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="연결 방식 유형" $detail $gapSmall>
                    <FormcontrolItem>Manual (수동)</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="충전 제공 방식" $detail $gapSmall>
                    <FormcontrolItem>대기표 방식</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="인증 과금 유형" $detail $gapSmall>
                    <FormcontrolItem>
                      RFID + Number(RFID/회원번호)
                    </FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="PnC 충전 지원" $detail $gapSmall>
                    <FormcontrolItem>Yes</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="펌웨어" $detail $gapSmall>
                    <FormcontrolItem>1.0.0.0</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="설치일" $detail $gapSmall>
                    <FormcontrolItem>2024-04-23 11:11</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="서비스 시작일" $detail $gapSmall>
                    <FormcontrolItem>2024-04-23 11:11</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="통신 게시일" $detail $gapSmall>
                    <FormcontrolItem>2024-04-23 11:11</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
                <GridItem>
                  <Formcontrol title="등록일" $detail $gapSmall>
                    <FormcontrolItem>2024-04-23 11:11</FormcontrolItem>
                  </Formcontrol>
                </GridItem>
              </Grid>
            </Accordion>

            <div style={{ marginTop: '40px' }}>
              <Accordion title="EVSE /  커넥터 정보">
                <AgGrid
                  rowData={ChargingStationsChargerInfoRowData}
                  columnDefs={ChargingStationsChargerInfoColumnDefs}
                  hasGridTop={false}
                  noneButton
                  listPerPageSelectOption={chargingStationsDetailOption}
                />
              </Accordion>
            </div>

            <div style={{ marginTop: '40px' }}>
              <Accordion title="네트워크 정보">
                <Grid $columns={2} $gap="24px 80px">
                  <GridItem>
                    <Formcontrol title="OCPP 버전" $detail $gapSmall>
                      <FormcontrolItem>ocpp2.0.1</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem>
                    <Formcontrol title="OCPP 연동 구분" $detail $gapSmall>
                      <FormcontrolItem>EPT</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem>
                    <Formcontrol title="인증 ID" $detail $gapSmall>
                      <FormcontrolItem>ID</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem>
                    <Formcontrol title="비밀번호" $detail $gapSmall>
                      <FormcontrolItem>1.0.0.0</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem $colStart={1} $colEnd={3}>
                    <Formcontrol title="등록 상태" $detail $gapSmall>
                      <FormcontrolItem>Accepted</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem>
                    <Formcontrol title="Heartbeat" $detail $gapSmall>
                      <FormcontrolItem>-</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                  <GridItem>
                    <Formcontrol title="ping/pong" $detail $gapSmall>
                      <FormcontrolItem>-</FormcontrolItem>
                    </Formcontrol>
                  </GridItem>
                </Grid>
              </Accordion>
            </div>
          </ModalContent>
          <ModalFooter $borderNone>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                제거
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                수정
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsChargerInfoContainer;

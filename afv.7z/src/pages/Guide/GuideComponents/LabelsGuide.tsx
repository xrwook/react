import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Labels from 'common/Labels';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;
const LabelsGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Label</GuideText>
        <GuideBox>
          <div>
            <Labels color="red" size="small">
              TAG
            </Labels>
            <Labels color="blue" size="small">
              TAG
            </Labels>
            <Labels color="yellow" size="small">
              TAG
            </Labels>
            <Labels color="purple" size="small">
              TAG
            </Labels>
            <Labels color="green" size="small">
              TAG
            </Labels>
            <Labels color="gray" size="small">
              TAG
            </Labels>
          </div>

          <div>
            <Labels color="red" size="medium">
              Labels
            </Labels>
            <Labels color="blue" size="medium">
              Labels
            </Labels>
            <Labels color="yellow" size="medium">
              Labels
            </Labels>
            <Labels color="purple" size="medium">
              Labels
            </Labels>
            <Labels color="green" size="medium">
              Labels
            </Labels>
            <Labels color="gray" size="medium">
              Labels
            </Labels>
          </div>
        </GuideBox>
        <GuideSubBox>
          &lt;Labels color="" size="" &gt;&lt;/Labels&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default LabelsGuide;

import styled from 'styled-components';

const ModalHeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px 66px 4px 30px;
`;

export interface ModalHeaderProps {
  children?: any;
}

const ModalHeader: React.FC<ModalHeaderProps> = ({ children }) => {
  return (
    <>
      <ModalHeaderWrapper>{children}</ModalHeaderWrapper>
    </>
  );
};

export default ModalHeader;

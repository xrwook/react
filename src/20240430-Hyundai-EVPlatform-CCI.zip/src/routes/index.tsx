import { Route, Routes, HashRouter } from 'react-router-dom';
import { Layout } from 'common/Tab/Layout';
import { Home_ } from 'common/Tab/Home';
import { AxiosQuery } from 'pages/Subpage/AxiosQuery';
import { ReactQuery } from 'pages/Subpage/ReactQuery';
import Home from 'pages/Home';
import GuideRoute from 'routes/GuideRoute';
import PrivateRoute from 'routes/PrivateRoute';
import PublicRoute from 'routes/PublicRoute';
import React from 'react';
import { ServiceType } from 'types/serviceType';
import HyundaiRoute from 'routes/HyundaiRoute';
import KiaRoute from 'routes/KiaRoute';
import GenesisRoute from 'routes/GenesisRoute';

export interface RouterProps {
  serviceType: ServiceType;
}

const Router: React.FC<RouterProps> = ({ serviceType }) => (
  <HashRouter>
    <Routes>
      <Route
        path="/"
        element={
          <PublicRoute>
            <Home />
          </PublicRoute>
        }
      />
      <Route
        path="/tab"
        element={
          <PrivateRoute>
            {/* <Articles /> */}
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Home_ />} />
        <Route path="axios-query" element={<AxiosQuery />} />
        <Route path="react-query" element={<ReactQuery />} />
      </Route>
    </Routes>
    {/* GuideRoute 추가 */}
    <GuideRoute />
    {serviceType == ServiceType.Hyundai ? (
      <HyundaiRoute />
    ) : serviceType == ServiceType.Kia ? (
      <KiaRoute />
    ) : serviceType == ServiceType.Genesis ? (
      <GenesisRoute />
    ) : (
      <></>
    )}
  </HashRouter>
);

export default Router;

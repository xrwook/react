import { useState } from 'react';
import Modal from 'common/Modal';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import ModalHeader from 'common/Modal/ModalHeader';
import Button from 'common/Button';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import Textarea from 'common/Textarea';
import FileSearch from 'common/FileSearch';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargerIssuesListPopupContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);

  return (
    <>
      {showModal && (
        <Modal width="800px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader $modalguide $ModalGuideText="표시는 필수 입력항목입니다">
            고장 조치
          </ModalHeader>
          <ModalContent $marginBottom="30px">
            <Grid $columns={1} $gap="30px 0">
              <GridItem>
                <Formcontrol title="조치 내역" required>
                  <Textarea
                    height="120px"
                    placeholder="조치 내역을 입력하세요."
                    maxLength={700}
                    total={700}
                  />
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="첨부 파일" $detail>
                  <div style={{ width: '100%' }}>
                    <FileSearch
                      text="* 이미지 최적의 해상도 450 x 300, 10MB 이하 (jpg,png)"
                      dnd
                    />
                  </div>
                </Formcontrol>
              </GridItem>
            </Grid>
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowModal(false)}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>

              {/* DD: 조치 내역 입력 시 버튼 활성화 */}
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={92}
                disabled
              >
                조치 완료
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargerIssuesListPopupContainer;

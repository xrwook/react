import styled from 'styled-components';
import React from 'react';

export interface GuideWrapperProps {
  children?: React.ReactNode;
}

const StyledWrapper = styled.div`
  display: flex;
`;

const StyledContainer = styled.div`
  flex: 1;
  padding: 20px;
`;

const GuideWrapper: React.FC<GuideWrapperProps> = ({ children }) => {
  return (
    <StyledWrapper>
      <StyledContainer>{children}</StyledContainer>
    </StyledWrapper>
  );
};

export default GuideWrapper;

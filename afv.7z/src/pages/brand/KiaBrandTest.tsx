const KiaBrandTest = () => {
  return <div>Kia Brand Page</div>;
};

export default KiaBrandTest;

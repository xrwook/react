import React from 'react';
import styled, { css } from 'styled-components';

interface BasicBoxProps {
  children?: React.ReactNode;
  background?: string;
  border?: string;
}

const BasicBoxWrapper = styled.div<BasicBoxProps>`
  padding: 19px;
  border-radius: 8px;
  border: 1px solid ${(props) => props.border || 'none'};
  background-color: ${(props) => props.background || 'none'};
  box-sizing: border-box;
  ${(props) =>
    props.background &&
    css`
      border: none;
    `}
`;

const BasicBox: React.FC<BasicBoxProps> = ({
  children,
  background,
  border,
}) => {
  return (
    <BasicBoxWrapper background={background} border={border}>
      {children}
    </BasicBoxWrapper>
  );
};

export default BasicBox;

import styled from 'styled-components';
import React from 'react';

export interface StyledGuideBox {
  children?: React.ReactNode;
}

const StyledGuideBox = styled.div`
  width: 100%;
  border: 3px solid #ddd;
  padding: 40px 20px;
  box-sizing: border-box;
`;

const GuideBox: React.FC<StyledGuideBox> = ({ children }) => {
  return <StyledGuideBox>{children}</StyledGuideBox>;
};

export default GuideBox;

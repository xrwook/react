import * as yup from 'yup';
import i18n from '../locale/index';
import { ServiceType } from '../types/serviceType';

export const loginSchema = yup.object().shape({
  username: yup.string().required(i18n.t('login.nameRequired')),
  password: yup.string().required(i18n.t('login.passRequired')),
});

export const gridSearchSchema = yup.object().shape({
  search: yup
    .string()
    .matches(/^[a-zA-Z0-9]*$/, i18n.t('common.onlyNumber'))
    .lowercase()
    .trim(),
  id: yup
    .string()
    .required(i18n.t('common.search'))
    .matches(/^[0-9]*$/, i18n.t('common.onlyNumber')),
});
export const findServiceTypeByUserAgent = (): ServiceType => {
  const userAgent = navigator.userAgent;
  if (userAgent.match(ServiceType.Hyundai) != null) {
    return ServiceType.Hyundai;
  } else if (userAgent.match(ServiceType.Kia) != null) {
    return ServiceType.Kia;
  } else if (userAgent.match(ServiceType.Genesis) != null) {
    return ServiceType.Genesis;
  } else {
    return ServiceType.None;
  }
};

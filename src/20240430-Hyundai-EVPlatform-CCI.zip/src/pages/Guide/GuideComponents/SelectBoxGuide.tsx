import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import SelectBox from 'common/SelecBox';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const options01 = [
  { value: '1', label: 'Option01-01' },
  { value: '2', label: 'Option02-02' },
  { value: '3', label: 'Option03-03' },
];

const options02 = [
  { value: '1', label: 'Option02-01' },
  { value: '2', label: 'Option02-02' },
  { value: '3', label: 'Option03-03' },
];

const TextFieldGuide = () => {
  return (
    <StyledGuideWrapper>
      <div style={{ padding: '50px' }}>
        <GuideWrapper>
          <GuideText>Select Box</GuideText>

          <GuideBox>
            <ul>
              <li>
                <SelectBox
                  options={options01}
                  header="select"
                  placeholder="select option"
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <SelectBox
                  options={options02}
                  header="select"
                  placeholder="select option"
                />
              </li>
            </ul>
          </GuideBox>

          <GuideSubBox>
            &lt;SelectBox options='options' header="select" placeholder="select
            option"&gt;
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>options</td>
                <td>options</td>
                <td>options 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>header</td>
                <td>header</td>
                <td>header 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>placeholder</td>
                <td>placeholder</td>
                <td>placeholder 입력</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </GuideWrapper>
      </div>
    </StyledGuideWrapper>
  );
};

export default TextFieldGuide;

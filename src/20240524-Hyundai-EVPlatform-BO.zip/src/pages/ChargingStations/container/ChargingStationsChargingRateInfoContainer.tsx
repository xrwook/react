import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import {
  LocationSubText,
  BasicTable,
  TableText,
  TableSubText,
} from '../styled/StyledChargingStations';

const ChargingStationsChargingRateInfo: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  return (
    <>
      {showModal && (
        <Modal width="600px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader>요금제 상세 정보</ModalHeader>

          <ModalContent $marginBottom="36px">
            <LocationSubText>요금제 이름</LocationSubText>
            <BasicTable>
              <colgroup>
                <col width="336px" />
                <col width="" />
              </colgroup>
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Fee</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <TableText>Early Bird</TableText>
                    <TableSubText>00:00 AM ~ 7:59 AM</TableSubText>
                  </td>
                  <td>$0.39 / kWh</td>
                </tr>
                <tr>
                  <td>
                    <TableText>Off-Peak</TableText>
                    <TableSubText>8:00 AM ~ 16:00 PM</TableSubText>
                  </td>
                  <td>$0.50 / kWh</td>
                </tr>
                <tr>
                  <td>
                    <TableText>Off-Peak</TableText>
                    <TableSubText>9:00 PM ~ 00:00 AM</TableSubText>
                  </td>
                  <td>$0.59 / kWh</td>
                </tr>
                <tr>
                  <td>
                    <TableText>Parking</TableText>
                    <TableSubText>Up to 2 hours session time</TableSubText>
                  </td>
                  <td>Free</td>
                </tr>
                <tr>
                  <td>
                    <TableText>Parking</TableText>
                    <TableSubText>After 2 hours session time</TableSubText>
                  </td>
                  <td>$0.80 / h</td>
                </tr>
              </tbody>
            </BasicTable>
          </ModalContent>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsChargingRateInfo;

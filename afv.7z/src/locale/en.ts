/* 북미 */
export default {
  common: {
    home: 'Home',
  },
};

import ko from './ko';
import en from './en';
import fr from './fr';

export default { ko, en, fr };
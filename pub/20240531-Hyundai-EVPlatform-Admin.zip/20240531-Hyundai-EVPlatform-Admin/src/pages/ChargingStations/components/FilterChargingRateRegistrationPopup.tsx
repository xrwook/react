import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import FilterLabel from 'common/Filter/FilterLabel';
import TextField from 'common/TextField';
import Select from 'common/Select/Select';
import {
  ChargingRateRegistrationPopupOption,
  ChargingRateRegistrationPopupOption2,
} from './data';

const FilterChargingRateRegistrationPopup: React.FC = () => {
  return (
    <FilterList useDetailButtons>
      <FilterItem $search>
        <TextField
          id="TextField01"
          name="text"
          type="text"
          placeholder="충전소 이름으로 검색"
          $search
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>권역 :</FilterLabel>
        <Select
          options={ChargingRateRegistrationPopupOption}
          defaultValue={ChargingRateRegistrationPopupOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>운영상태 :</FilterLabel>
        <Select
          options={ChargingRateRegistrationPopupOption2}
          defaultValue={ChargingRateRegistrationPopupOption2[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
    </FilterList>
  );
};

export default FilterChargingRateRegistrationPopup;

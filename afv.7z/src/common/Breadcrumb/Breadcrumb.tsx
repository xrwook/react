import styled from 'styled-components';

const BreadcrumbWrapper = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
`;

export interface BreadcrumbHomeProps {
  children?: any;
}

const Breadcrumb: React.FC<BreadcrumbHomeProps> = ({ children }) => {
  return <BreadcrumbWrapper>{children}</BreadcrumbWrapper>;
};

export default Breadcrumb;

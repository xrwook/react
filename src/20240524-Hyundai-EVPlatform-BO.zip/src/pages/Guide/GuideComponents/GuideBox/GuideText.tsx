import styled from 'styled-components';
import React from 'react';

export interface StyledGuideText {
  children?: React.ReactNode;
}

const StyledGuideText = styled.h1`
  font-size: ${(props) => props.theme.fontSize.fontSize7};
  font-weight: 700;
  margin-bottom: 15px;

  h3 {
    margin: 10px 0 0;
    color: ${(props) => props.theme.color.gray8};
    font-size: ${(props) => props.theme.fontSize.fontSize4};
  }

  h4 {
    margin: 10px 0 0;
    color: ${(props) => props.theme.color.gray8};
    font-size: ${(props) => props.theme.fontSize.fontSize2};
    &:before {
      content: '';
      display: inline-block;
      position: relative;
      top: -2px;
      width: 4px;
      height: 4px;
      margin-right: 4px;
      border-radius: 2px;
      background: ${(props) => props.theme.color.gray4};
    }
  }
`;

const GuideText: React.FC<StyledGuideText> = ({ children }) => {
  return <StyledGuideText>{children}</StyledGuideText>;
};

export default GuideText;

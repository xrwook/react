export const enum ServiceType {
  Hyundai = 'Hyundai',
  Kia = 'Kia',
  Genesis = 'Genesis',
  None = '',
}

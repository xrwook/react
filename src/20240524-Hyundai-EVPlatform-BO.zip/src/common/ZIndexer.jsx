const defaultZindex = 10;

const ZIndexer = ({ children }) => {
  return children({ zIndex: defaultZindex });
};

export default ZIndexer;

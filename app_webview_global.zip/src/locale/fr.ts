/* 북미 캐나다 - 퀘벡 */
export default {
    common: {
        home: 'maison',
    },
};
  
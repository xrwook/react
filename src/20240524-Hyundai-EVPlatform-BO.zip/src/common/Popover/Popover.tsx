import { PopoverBox, PopoverClose, PopoverWrapper } from './StyledPopover';

export interface PopoverProps {
  children?: any;
  onClose(): void;
  style?: any;
}

const Popover: React.FC<PopoverProps> = ({ children, onClose, style }) => {
  const handleCloseClick = (e: any) => {
    e.preventDefault();
    onClose();
  };

  return (
    <>
      <PopoverWrapper style={style}>
        <PopoverBox>
          <PopoverClose
            type="button"
            aria-label="close"
            onClick={handleCloseClick}
          />
          {children}
        </PopoverBox>
      </PopoverWrapper>
    </>
  );
};

export default Popover;

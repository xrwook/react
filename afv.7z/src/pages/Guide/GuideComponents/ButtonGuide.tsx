import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Button from 'common/Button/Button';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const Layout = styled.div`
  display: flex;
`;

const ButtonGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Button</GuideText>
        {/* mini */}
        <GuideBox>
          <Layout>
            <Button onClick={() => {}} size="mini" variant="primary">
              Button
            </Button>
            <Button onClick={() => {}} size="mini" variant="primary" disabled>
              Button
            </Button>

            <Button onClick={() => {}} size="mini" variant="secondaryGray">
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="mini"
              variant="secondaryGray"
              disabled
            >
              Button
            </Button>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Button onClick size="mini" variant="" disabled icon /&gt;
        </GuideSubBox>

        {/* small */}
        <GuideBox>
          <Layout>
            <Button onClick={() => {}} size="small" variant="primary">
              Button
            </Button>
            <Button onClick={() => {}} size="small" variant="primary" disabled>
              Button
            </Button>

            <Button onClick={() => {}} size="small" variant="secondaryGray">
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="small"
              variant="secondaryGray"
              disabled
            >
              Button
            </Button>

            <Button onClick={() => {}} size="small" variant="primary" icon>
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="small"
              variant="primary"
              disabled
              icon
            >
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="small"
              variant="secondaryGray"
              icon
            >
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="small"
              variant="secondaryGray"
              disabled
              icon
            >
              Button
            </Button>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Button onClick size="small" variant="" disabled icon /&gt;
        </GuideSubBox>

        {/* large */}
        <GuideBox>
          <Layout>
            <Button onClick={() => {}} size="large" variant="primary">
              Button
            </Button>
            <Button onClick={() => {}} size="large" variant="primary" disabled>
              Button
            </Button>

            <Button onClick={() => {}} size="large" variant="secondaryBlue">
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="large"
              variant="secondaryBlue"
              disabled
            >
              Button
            </Button>

            <Button onClick={() => {}} size="large" variant="tertiary">
              Button
            </Button>
            <Button onClick={() => {}} size="large" variant="tertiary" disabled>
              Button
            </Button>

            <Button
              onClick={() => {}}
              size="large"
              variant="secondaryBlue"
              icon
            >
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="large"
              variant="secondaryBlue"
              disabled
              icon
            >
              Button
            </Button>
            <Button onClick={() => {}} size="large" variant="tertiary" icon>
              Button
            </Button>
            <Button
              onClick={() => {}}
              size="large"
              variant="tertiary"
              disabled
              icon
            >
              Button
            </Button>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Button onClick size="large" variant="" disabled icon /&gt;
        </GuideSubBox>

        {/* 기타 */}
        <GuideBox>
          <Layout>
            <Button
              onClick={() => {}}
              size="small"
              variant="secondaryGray"
              download
              icon
            >
              엑셀 다운로드
            </Button>
            <Button
              onClick={() => {}}
              size="large"
              variant="secondaryGray"
              download
              icon
            >
              엑셀 다운로드
            </Button>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Button onClick size="" variant="secondaryGray" download icon /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default ButtonGuide;

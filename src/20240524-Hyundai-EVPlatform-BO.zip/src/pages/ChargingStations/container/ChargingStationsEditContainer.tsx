import React, { useState } from 'react';
import Title from 'common/Title';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import TextField from 'common/TextField';
import Button from 'common/Button/Button';
import Icon from 'common/Icon/Icon';
import Select from 'common/Select';
import FormFlex from 'common/FormFlex';
import Radio from 'common/Radio';
import FileSearch from 'common/FileSearch';
import AgGrid from 'common/AgGrid';
import CheckBox from 'common/CheckBox/Checkbox';
import PageFooter from 'common/PageFooter';
import Header from 'layout/Header';
import DatePicker from 'common/Datepicker/Datepicker';
import {
  NoticeText,
  Form,
  DashedHr,
  AddButton,
  SubButton,
  FormFlexWrap,
  FlexNone,
  FormWrapWith,
  DateButtonWrap,
  DateButtonList,
  DateButtonItem,
  TimeButtonList,
  TimeButtonItem,
} from '../styled/StyledChargingStations';

const ChargingStationsEdit: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  const [selectedButton, setSelectedButton] = useState('매일');
  const [selectedTimeButton, setselectedTimeButton] = useState('00:00');

  const setSelectedTimeButton = (id: any, time: any) => {
    setDateForms((dateForms) =>
      dateForms.map((form) =>
        form.id === id ? { ...form, selectedTime: time } : form,
      ),
    );
  };

  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전소 등록 관리' },
    { to: '/', text: '충전소 수정', className: 'active' },
  ];

  const columnDefs = [
    {
      headerName: '번호',
      field: 'field1',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
      maxWidth: 80,
      valueGetter: (params: any) => {
        return params.api.getDisplayedRowCount() - params.node.rowIndex;
      },
    },
    {
      headerName: '이름',
      field: 'field2',
      cellStyle: { textAlign: 'left' },
      headerClass: 'custom-align-left',
      minWidth: 242,
    },
    {
      headerName: '커넥터 타입',
      field: 'field3',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
    },
    {
      headerName: '커넥터 갯수',
      field: 'field4',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
      minWidth: 90,
    },
    {
      headerName: '충전 속도',
      field: 'field5',
      cellStyle: { textAlign: 'left' },
      headerClass: 'custom-align-left',
      minWidth: 152,
    },
    {
      headerName: '제조사',
      field: 'field6',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
    },
    {
      headerName: '모델명',
      field: 'field7',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
      minWidth: 180,
    },
    {
      headerName: '펌웨어 버전',
      field: 'field8',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
    },
    {
      headerName: '통신 개통일',
      field: 'field9',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
    },
    {
      headerName: '설치일',
      field: 'field10',
      cellStyle: { textAlign: 'center' },
      headerClass: 'custom-align-center',
    },
  ];

  const rowData = [
    {
      field1: '3',
      field2: 'ABCDEFGHIJKLMNOPQRST',
      field3: 'DC Combo',
      field4: '00',
      field5: 'Super Fast',
      field6: '아이마켓 코리아',
      field7: 'MC MS24-2DD-c',
      field8: 'v1.0.0.0',
      field9: '2024-04-23',
      field10: '2024-04-23',
    },
  ];

  const listPerPageSelectOption = [
    {
      value: '5',
      label: '5개씩 보기',
    },
    {
      value: '10',
      label: '10개씩 보기',
    },
    {
      value: '15',
      label: '15개씩 보기',
    },
    {
      value: '20',
      label: '20개씩 보기',
    },
    {
      value: '30',
      label: '30개씩 보기',
    },
  ];

  const options01 = [
    {
      value: '모든 사용자용',
      label: '모든 사용자용',
    },
    {
      value: '사업장용',
      label: '사업장용',
    },
    {
      value: '공동주택형',
      label: '공동주택형',
    },
    {
      value: '단독주택형',
      label: '단독주택형',
    },
    {
      value: '실증용',
      label: '실증용',
    },
    {
      value: '이동형',
      label: '이동형',
    },
    {
      value: '복합 충전소',
      label: '복합 충전소',
    },
    {
      value: '기타',
      label: '기타',
    },
  ];

  const options02 = [
    {
      value: '공용',
      label: '공용',
    },
    {
      value: '부분공용',
      label: '부분공용',
    },
    {
      value: '비공용',
      label: '비공용',
    },
  ];

  const options03 = [
    {
      value: '공공시설',
      label: '공공시설',
    },
    {
      value: '주차시설',
      label: '주차시설',
    },
    {
      value: '휴게시설',
      label: '휴게시설',
    },
    {
      value: '관광시설',
      label: '관광시설',
    },
    {
      value: '상업시설',
      label: '상업시설',
    },
    {
      value: '차량정비시설',
      label: '차량정비시설',
    },
  ];

  // Case : 공공시설일 경우
  const options04 = [
    {
      value: '시청',
      label: '시청',
    },
    {
      value: '구청',
      label: '구청',
    },
    {
      value: '군청',
      label: '군청',
    },
    {
      value: '주민센터(면사무소)',
      label: '주민센터(면사무소)',
    },
    {
      value: '보건소',
      label: '보건소',
    },
    {
      value: '지자체시설',
      label: '지자체시설',
    },
    {
      value: '복지관',
      label: '복지관',
    },
    {
      value: '공공기관',
      label: '공공기관',
    },
    {
      value: '도서관',
      label: '도서관',
    },
    {
      value: '의회',
      label: '의회',
    },
    {
      value: '도청',
      label: '도청',
    },
    {
      value: '체육관',
      label: '체육관',
    },
    {
      value: '기타',
      label: '기타',
    },
  ];

  // Case : 주차시설일 경우
  // const options05 = [
  //   {
  //     value: '공영주차장',
  //     label: '공영주차장',
  //   },
  //   {
  //     value: '공원주차장',
  //     label: '공원주차장',
  //   },
  //   {
  //     value: '환승주차장',
  //     label: '환승주차장',
  //   },
  //   {
  //     value: '일반주차장(민간)',
  //     label: '일반주차장(민간)',
  //   },
  //   {
  //     value: '기타',
  //     label: '기타',
  //   },
  // ];

  // Case : 휴게시설일 경우
  // const options06 = [
  //   {
  //     value: '고속도로휴게실',
  //     label: '고속도로휴게실',
  //   },
  //   {
  //     value: '지방도로휴게실',
  //     label: '지방도로휴게실',
  //   },
  //   {
  //     value: '쉼터',
  //     label: '쉼터',
  //   },
  //   {
  //     value: '기타',
  //     label: '기타',
  //   },
  // ];

  // Case: 관광시설일 경우
  // const options07 = [
  //   {
  //     value: '공원',
  //     label: '공원',
  //   },
  //   {
  //     value: '전시장',
  //     label: '전시장',
  //   },
  //   {
  //     value: '야영장',
  //     label: '야영장',
  //   },
  //   {
  //     value: '민속마을',
  //     label: '민속마을',
  //   },
  //   {
  //     value: '생태공원',
  //     label: '생태공원',
  //   },
  //   {
  //     value: '홍보관',
  //     label: '홍보관',
  //   },
  //   {
  //     value: '관광안내소',
  //     label: '관광안내소',
  //   },
  //   {
  //     value: '관광지',
  //     label: '관광지',
  //   },
  //   {
  //     value: '공연장',
  //     label: '공연장',
  //   },
  //   {
  //     value: '박물관',
  //     label: '박물관',
  //   },
  //   {
  //     value: '축구장',
  //     label: '축구장',
  //   },
  //   {
  //     value: '사격장',
  //     label: '사격장',
  //   },
  //   {
  //     value: '수목원',
  //     label: '수목원',
  //   },
  //   {
  //     value: '승마장',
  //     label: '승마장',
  //   },
  //   {
  //     value: '야구장',
  //     label: '야구장',
  //   },
  //   {
  //     value: '기타',
  //     label: '기타',
  //   },
  // ];

  // Case: 상업시설일 경우
  // const options08 = [
  //   {
  //     value: '마트',
  //     label: '마트',
  //   },
  //   {
  //     value: '백화점',
  //     label: '백화점',
  //   },
  //   {
  //     value: '숙박시설',
  //     label: '숙박시설',
  //   },
  //   {
  //     value: '골프장',
  //     label: '골프장',
  //   },
  //   {
  //     value: '카페',
  //     label: '카페',
  //   },
  //   {
  //     value: '음식점',
  //     label: '음식점',
  //   },
  //   {
  //     value: '주유소',
  //     label: '주유소',
  //   },
  //   {
  //     value: '영화관',
  //     label: '영화관',
  //   },
  //   {
  //     value: '시장',
  //     label: '시장',
  //   },
  //   {
  //     value: '직판장',
  //     label: '직판장',
  //   },
  //   {
  //     value: '편의점',
  //     label: '편의점',
  //   },
  //   {
  //     value: '유흥단지',
  //     label: '유흥단지',
  //   },
  //   {
  //     value: '기타',
  //     label: '기타',
  //   },
  // ];

  // Case: 차량정비시설일 경우
  // const options09 = [
  //   {
  //     value: '서비스센터',
  //     label: '서비스센터',
  //   },
  //   {
  //     value: '정비소',
  //     label: '정비소',
  //   },
  //   {
  //     value: '기타',
  //     label: '기타',
  //   },
  // ];

  const options10 = [{ value: 'Select 사업자', label: 'Select 사업자' }];

  const options11 = [{ value: 'Select plan', label: 'Select plan' }];

  const options12 = [
    {
      value: 'E-pit',
      label: 'E-pit',
    },
    {
      value: 'HMG PAY',
      label: 'HMG PAY',
    },
    {
      value: 'NFC',
      label: 'NFC',
    },
    {
      value: 'Plug & Charge',
      label: 'Plug & Charge',
    },
    {
      value: '제네시스 카페이',
      label: '제네시스 카페이',
    },
    {
      value: '현대 카페이',
      label: '현대 카페이',
    },
    {
      value: '기아 카페이',
      label: '기아 카페이',
    },
    {
      value: '일반 결제',
      label: '일반 결제',
    },
    {
      value: '간편 결제',
      label: '간편 결제',
    },
  ];

  const options13 = [
    {
      value: '레스토랑',
      label: '레스토랑',
    },
    {
      value: '화장실',
      label: '화장실',
    },
    {
      value: '카페시설',
      label: '카페시설',
    },
    {
      value: '숙박시설',
      label: '숙박시설',
    },
    {
      value: '쇼핑몰',
      label: '쇼핑몰',
    },
    {
      value: '식료품점',
      label: '식료품점',
    },
    {
      value: '발렛파킹',
      label: '발렛파킹',
    },
    {
      value: '하이킹',
      label: '하이킹',
    },
    {
      value: '약국',
      label: '약국',
    },
  ];

  const options14 = [
    {
      value: '3상3선식',
      label: '3상3선식',
    },
    {
      value: '3상4선식',
      label: '3상4선식',
    },
  ];

  const options15 = [
    {
      value: '주말',
      label: '주말',
    },
    {
      value: '평일',
      label: '평일',
    },
    {
      value: '날짜 지정',
      label: '날짜 지정',
    },
  ];

  const options16 = [
    {
      value: '주말 (토-일)',
      label: '주말 (토-일)',
    },
    {
      value: '평일 (월-금)',
      label: '평일 (월-금)',
    },
  ];

  const [forms, setForms] = useState<Form[]>([]);
  const [dateForms, setDateForms] = useState<Form[]>([]);

  const addForm = () => {
    const newForm = {
      id: forms.length + 1,
      selectId: `Select${forms.length + 10}`,
      textFieldId: `TextField${forms.length + 10}`,
    };
    setForms([...forms, newForm]);
  };

  const removeForm = (id: number) => {
    setForms(forms.filter((form) => form.id !== id));
  };

  const dateAddForm = () => {
    const baseId = Date.now();
    const newForm = {
      id: dateForms.length + 1,
      selectId1: `Select${baseId}A`,
      selectId2: `Select${baseId}B`,
      textFieldId: `TextField${baseId}`,
      checkId1: `CheckBox${baseId}A`,
      checkId2: `CheckBox${baseId}B`,
      selectedTime: '00:00',
    };
    setDateForms((dateForms) => [...dateForms, newForm]);
  };

  const DateRemoveForm = (id: number) => {
    setDateForms((dateForms) => dateForms.filter((form) => form.id !== id));
  };

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title titlemain="충전소 수정" $titleguide />
      <Title titlemain="기본 정보" $pagetitle />

      <section style={{ marginBottom: '24px' }}>
        <Grid $columns={2} $gap="12px 128px">
          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="이름" htmlFor="TextField01" required $row>
              <TextField
                id="TextField01"
                name="text"
                type="text"
                placeholder="Enter charging station name"
              />
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="주소" htmlFor="TextField02" required $row>
              <FormFlex>
                <FlexNone>
                  <TextField
                    id="TextField02"
                    name="text"
                    type="text"
                    placeholder="Enter zip code"
                    disabled
                    $width="231"
                  />
                </FlexNone>

                <Button
                  onClick={() => {}}
                  $size="small"
                  $variant="secondaryGray"
                  $icon="icon-search-secondaryGray"
                >
                  <Icon $widthSize={20} $heightSize={20}>
                    검색
                  </Icon>
                  주소 검색
                </Button>
                <Button
                  onClick={() => {}}
                  $size="small"
                  $variant="secondaryGray"
                >
                  위치 보정
                </Button>
                <NoticeText>
                  주소 선택 시, 위도/경도 + 권역 정보를 텍스트로 표시
                </NoticeText>
              </FormFlex>

              <FormFlex>
                <FlexNone>
                  <TextField
                    id="TextField03"
                    name="text"
                    type="text"
                    placeholder="Enter address"
                    disabled
                    $width="448"
                  />
                </FlexNone>

                <TextField
                  id="TextField04"
                  name="text"
                  type="text"
                  placeholder="Enter address detail"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="상세 위치" htmlFor="TextField05" $row>
              <TextField
                id="TextField05"
                name="text"
                type="text"
                placeholder="Enter charging station location detail"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol
              title="충전소 유형/개방 형태"
              htmlFor="Select01"
              required
              $row
            >
              <FormFlex>
                <Select
                  inputId="Select01"
                  name="Select01"
                  placeholder="충전소 유형 선택"
                  options={options01}
                  classNamePrefix="react-select"
                />
                <Select
                  inputId="Select02"
                  name="Select02"
                  placeholder="공용/부분공용/비공용"
                  options={options02}
                  classNamePrefix="react-select"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol
              title="시설 형태/유형"
              htmlFor="Select03"
              required
              $row
            >
              <FormFlex>
                <Select
                  inputId="Select03"
                  name="Select03"
                  placeholder="충전소 유형 선택"
                  options={options03}
                  classNamePrefix="react-select"
                />
                <Select
                  inputId="Select04"
                  name="Select04"
                  placeholder="유형 선택"
                  options={options04}
                  classNamePrefix="react-select"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="사업자" htmlFor="Select05" required $row>
              <Select
                inputId="Select05"
                name="Select05"
                placeholder="Select 사업자"
                options={options10}
                classNamePrefix="react-select"
                disabled
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="운영 상태" htmlFor="radio1" required $row>
              <FormFlex $gap="16px">
                <FlexNone>
                  <Radio
                    id="radio1"
                    name="radio1"
                    text="In Operation"
                    htmlFor="radio1"
                    $large
                    defaultChecked
                  />
                </FlexNone>

                <FlexNone>
                  <Radio
                    id="radio2"
                    name="radio1"
                    text="Out of service"
                    htmlFor="radio2"
                    $large
                  />
                </FlexNone>

                <FlexNone>
                  <Radio
                    id="radio3"
                    name="radio1"
                    text="Scheduled to open"
                    htmlFor="radio3"
                    $large
                  />
                </FlexNone>
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="충전 요금제" htmlFor="Select06" required $row>
              <Select
                inputId="Select06"
                name="Select06"
                placeholder="Select plan"
                options={options11}
                classNamePrefix="react-select"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="주차 가능 여부" htmlFor="radio4" required $row>
              <FormFlex $gap="16px">
                <FlexNone>
                  <Radio
                    id="radio4"
                    name="radio2"
                    text="Available"
                    htmlFor="radio4"
                    $large
                    defaultChecked
                  />
                </FlexNone>

                <FlexNone>
                  <Radio
                    id="radio5"
                    name="radio2"
                    text="Unavailable"
                    htmlFor="radio5"
                    $large
                  />
                </FlexNone>
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol
              title="운영 사업자"
              htmlFor="TextField06"
              required
              $row
            >
              <TextField
                id="TextField06"
                name="text"
                type="text"
                placeholder="Enter operator detail"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol
              title="위탁 사업자"
              htmlFor="TextField07"
              required
              $row
            >
              <TextField
                id="TextField07"
                name="text"
                type="text"
                placeholder="Enter operator detail"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="결제 방식" htmlFor="Select07" required $row>
              <Select
                inputId="Select07"
                name="Select07"
                placeholder="Select Payment Method"
                options={options12}
                classNamePrefix="react-select"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="무선 충전" htmlFor="radio6" required $row>
              <FormFlex $gap="16px">
                <FlexNone>
                  <Radio
                    id="radio6"
                    name="radio3"
                    text="Yes"
                    htmlFor="radio6"
                    $large
                    defaultChecked
                  />
                </FlexNone>

                <FlexNone>
                  <Radio
                    id="radio7"
                    name="radio3"
                    text="No"
                    htmlFor="radio7"
                    $large
                  />
                </FlexNone>
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="Tag" htmlFor="TextField08" $row>
              <TextField
                id="TextField08"
                name="text"
                type="text"
                placeholder="#을 입력하고 태그 정보를 입력, 선택"
              />
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="충전소 이미지" required $row>
              <FileSearch
                text="* 이미지 최적의 해상도 450 x 300, 10MB 이하 (jpg,png)"
                dnd
              />
            </Formcontrol>
          </GridItem>
        </Grid>
      </section>

      <Title
        titlemain="영업일 및 편의시설 정보"
        $pagetitle
        $titleguide
        $titleGuideText="Required fields"
      />

      <section style={{ marginBottom: '24px' }}>
        <Grid $columns={2} $gap="12px 40px">
          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="영업 시간 설정" $row>
              <DateButtonWrap>
                <DateButtonList>
                  <DateButtonItem
                    $selected={selectedButton === '매일'}
                    onClick={() => setSelectedButton('매일')}
                  >
                    매일
                  </DateButtonItem>
                  <DateButtonItem
                    $selected={selectedButton === '평일/주말'}
                    onClick={() => setSelectedButton('평일/주말')}
                  >
                    평일/주말
                  </DateButtonItem>
                  <DateButtonItem
                    $selected={selectedButton === '요일별 지정'}
                    onClick={() => setSelectedButton('요일별 지정')}
                  >
                    요일별 지정
                  </DateButtonItem>
                  <DateButtonItem
                    $selected={selectedButton === '사용자 지정'}
                    onClick={() => setSelectedButton('사용자 지정')}
                  >
                    사용자 지정
                  </DateButtonItem>
                </DateButtonList>
              </DateButtonWrap>

              {/* Case : 매일인 경우 */}
              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  매일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '00:00'}
                  onClick={() => setselectedTimeButton('00:00')}
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '23:59'}
                  onClick={() => setselectedTimeButton('23:59')}
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check03"
                        name="check03"
                        htmlFor="check03"
                        text="24시간 운영"
                        defaultChecked
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check04"
                      name="check04"
                      htmlFor="check04"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 매일인 경우 */}

              {/* Case : 평일/주말인 경우 */}
              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  평일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '평일 HH:MM'}
                  onClick={() => setselectedTimeButton('평일 HH:MM')}
                >
                  HH:MM
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === 'HH:MM'}
                  onClick={() => setselectedTimeButton('HH:MM')}
                >
                  HH:MM
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check05"
                        name="check05"
                        htmlFor="check05"
                        text="24시간 운영"
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check06"
                      name="check06"
                      htmlFor="check06"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  주말
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '주말 00:00'}
                  onClick={() => setselectedTimeButton('주말 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '주말 23:59'}
                  onClick={() => setselectedTimeButton('주말 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check07"
                        name="check07"
                        htmlFor="check07"
                        text="24시간 운영"
                        defaultChecked
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check08"
                      name="check08"
                      htmlFor="check08"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 평일/주말인 경우 */}

              {/* Case : 요일별 지정 경우 */}
              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  월요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '월 00:00'}
                  onClick={() => setselectedTimeButton('월 00:00')}
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '월 23:59'}
                  onClick={() => setselectedTimeButton('월 23:59')}
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check09"
                        name="check09"
                        htmlFor="check09"
                        text="24시간 운영"
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check010"
                      name="check010"
                      htmlFor="check010"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  화요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '화 00:00'}
                  onClick={() => setselectedTimeButton('화 00:00')}
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '화 23:59'}
                  onClick={() => setselectedTimeButton('화 23:59')}
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check11"
                        name="check11"
                        htmlFor="check11"
                        text="24시간 운영"
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check12"
                      name="check12"
                      htmlFor="check12"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  수요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '수 00:00'}
                  onClick={() => setselectedTimeButton('수 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '수 23:59'}
                  onClick={() => setselectedTimeButton('수 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check13"
                        name="check13"
                        htmlFor="check13"
                        text="24시간 운영"
                        disabled
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check14"
                      name="check14"
                      htmlFor="check14"
                      text="휴일"
                      defaultChecked
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  목요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '목 00:00'}
                  onClick={() => setselectedTimeButton('목 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '목 23:59'}
                  onClick={() => setselectedTimeButton('목 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check15"
                        name="check15"
                        htmlFor="check15"
                        text="24시간 운영"
                        defaultChecked
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check16"
                      name="check16"
                      htmlFor="check16"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  금요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '금 00:00'}
                  onClick={() => setselectedTimeButton('금 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '금 23:59'}
                  onClick={() => setselectedTimeButton('금 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check17"
                        name="check17"
                        htmlFor="check17"
                        text="24시간 운영"
                        defaultChecked
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check18"
                      name="check18"
                      htmlFor="check18"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  토요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '토 00:00'}
                  onClick={() => setselectedTimeButton('토 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '토 23:59'}
                  onClick={() => setselectedTimeButton('토 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check19"
                        name="check19"
                        htmlFor="check19"
                        text="24시간 운영"
                        defaultChecked
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check20"
                      name="check20"
                      htmlFor="check20"
                      text="휴일"
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>

              <TimeButtonList>
                <TimeButtonItem $day disabled>
                  일요일
                </TimeButtonItem>

                <TimeButtonItem
                  $selected={selectedTimeButton === '일 00:00'}
                  onClick={() => setselectedTimeButton('일 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '일 23:59'}
                  onClick={() => setselectedTimeButton('일 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check21"
                        name="check21"
                        htmlFor="check21"
                        text="24시간 운영"
                        disabled
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check22"
                      name="check22"
                      htmlFor="check22"
                      text="휴일"
                      defaultChecked
                    />
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 요일별 지정 경우 */}

              {/* Case : 사용자 지정 경우 */}
              <div style={{ marginBottom: '24px', marginTop: '12px' }}>
                <TimeButtonList>
                  <div style={{ width: '136px' }}>
                    <Select
                      inputId="Select25"
                      name="Select25"
                      placeholder="선택"
                      options={options15}
                      classNamePrefix="react-select"
                    />
                  </div>
                  <div style={{ width: '136px' }}>
                    <Select
                      inputId="Select26"
                      name="Select26"
                      placeholder="선택"
                      options={options16}
                      classNamePrefix="react-select"
                      disabled
                    />
                  </div>
                  <TimeButtonItem
                    $selected={selectedTimeButton === '지정 HH:MM'}
                    onClick={() => setselectedTimeButton('지정 HH:MM')}
                    disabled
                  >
                    HH:MM
                  </TimeButtonItem>
                  <TimeButtonItem
                    $selected={selectedTimeButton === '선택 HH:MM'}
                    onClick={() => setselectedTimeButton('선택 HH:MM')}
                    disabled
                  >
                    HH:MM
                  </TimeButtonItem>

                  <div style={{ marginLeft: '4px' }}>
                    <FormFlex>
                      <FlexNone>
                        {/* Case : 휴일 체크할 경우 disabled */}
                        <CheckBox
                          id="check23"
                          name="check23"
                          htmlFor="check23"
                          text="24시간 운영"
                        />
                        {/* Case : 휴일 체크할 경우 disabled */}
                      </FlexNone>

                      <CheckBox
                        id="check24"
                        name="check24"
                        htmlFor="check24"
                        text="휴일"
                      />

                      <FlexNone>
                        <div style={{ marginLeft: '4px' }}>
                          <AddButton onClick={dateAddForm} />
                        </div>
                      </FlexNone>
                    </FormFlex>
                  </div>
                </TimeButtonList>
              </div>

              {dateForms.map((form) => (
                <TimeButtonList key={form.id}>
                  <div style={{ width: '136px' }}>
                    <Select
                      inputId={form.selectId1}
                      name={form.selectId1}
                      placeholder="선택"
                      options={options15}
                      classNamePrefix="react-select"
                    />
                  </div>
                  <div style={{ width: '136px' }}>
                    <Select
                      inputId={form.selectId2}
                      name={form.selectId2}
                      placeholder="선택"
                      options={options16}
                      classNamePrefix="react-select"
                    />
                  </div>
                  <TimeButtonItem
                    $selected={form.selectedTime === '지정 10:00'}
                    onClick={() => setSelectedTimeButton(form.id, '지정 10:00')}
                  >
                    HH:MM
                  </TimeButtonItem>
                  <TimeButtonItem
                    $selected={form.selectedTime === '선택 10:00'}
                    onClick={() => setSelectedTimeButton(form.id, '선택 10:00')}
                  >
                    HH:MM
                  </TimeButtonItem>

                  <div style={{ marginLeft: '4px' }}>
                    <FormFlex>
                      <FlexNone>
                        {/* Case : 휴일 체크할 경우 disabled */}
                        <CheckBox
                          id={form.checkId1}
                          name={form.checkId1}
                          htmlFor={form.checkId1}
                          text="24시간 운영"
                        />
                        {/* Case : 휴일 체크할 경우 disabled */}
                      </FlexNone>

                      <CheckBox
                        id={form.checkId2}
                        name={form.checkId2}
                        htmlFor={form.checkId2}
                        text="휴일"
                      />

                      <FlexNone>
                        <div style={{ marginLeft: '4px' }}>
                          <SubButton onClick={() => DateRemoveForm(form.id)} />
                        </div>
                      </FlexNone>
                    </FormFlex>
                  </div>
                </TimeButtonList>
              ))}

              {/* Case : 주말을 선택할 경우 */}
              <TimeButtonList>
                <div style={{ width: '136px' }}>
                  <Select
                    inputId="Select27"
                    name="Select27"
                    placeholder="선택"
                    options={options15}
                    classNamePrefix="react-select"
                    defaultValue={options15[0]}
                  />
                </div>
                <div style={{ width: '136px' }}>
                  <Select
                    inputId="Select28"
                    name="Select28"
                    placeholder="선택"
                    options={options16}
                    classNamePrefix="react-select"
                    defaultValue={options16[0]}
                  />
                </div>
                <TimeButtonItem
                  $selected={selectedTimeButton === '지정 주말 00:00'}
                  onClick={() => setselectedTimeButton('지정 주말 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '지정 주말 23:59'}
                  onClick={() => setselectedTimeButton('지정 주말 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check25"
                        name="check25"
                        htmlFor="check25"
                        text="24시간 운영"
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check26"
                      name="check26"
                      htmlFor="check26"
                      text="휴일"
                    />

                    <FlexNone>
                      <div style={{ marginLeft: '4px' }}>
                        <SubButton onClick={() => {}} />
                      </div>
                    </FlexNone>
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 주말을 선택할 경우 */}

              {/* Case : 평일을 선택할 경우 */}
              <TimeButtonList>
                <div style={{ width: '136px' }}>
                  <Select
                    inputId="Select29"
                    name="Select29"
                    placeholder="선택"
                    options={options15}
                    classNamePrefix="react-select"
                    defaultValue={options15[1]}
                  />
                </div>
                <div style={{ width: '136px' }}>
                  <Select
                    inputId="Select30"
                    name="Select30"
                    placeholder="선택"
                    options={options16}
                    classNamePrefix="react-select"
                    defaultValue={options16[1]}
                  />
                </div>
                <TimeButtonItem
                  $selected={selectedTimeButton === '지정 평일 10:00'}
                  onClick={() => setselectedTimeButton('지정 평일 10:00')}
                  $defaultSelected
                >
                  10:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '지정 평일 18:00'}
                  onClick={() => setselectedTimeButton('지정 평일 18:00')}
                  $defaultSelected
                >
                  18:00
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check27"
                        name="check27"
                        htmlFor="check27"
                        text="24시간 운영"
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check28"
                      name="check28"
                      htmlFor="check28"
                      text="휴일"
                    />

                    <FlexNone>
                      <div style={{ marginLeft: '4px' }}>
                        <SubButton onClick={() => {}} />
                      </div>
                    </FlexNone>
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 평일을 선택할 경우 */}

              {/* Case : 날짜지정을 선택할 경우 */}
              <TimeButtonList>
                <div style={{ width: '136px' }}>
                  <Select
                    inputId="Select31"
                    name="Select31"
                    placeholder="선택"
                    options={options15}
                    classNamePrefix="react-select"
                    defaultValue={options15[2]}
                  />
                </div>
                <div style={{ width: '136px' }}>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    selectsStart
                    startDate={startDate}
                    endDate={endDate}
                    dateFormat="yyyy/MM/dd"
                  />
                </div>
                <TimeButtonItem
                  $selected={selectedTimeButton === '날짜지정 00:00'}
                  onClick={() => setselectedTimeButton('날짜지정 00:00')}
                  disabled
                >
                  00:00
                </TimeButtonItem>
                <TimeButtonItem
                  $selected={selectedTimeButton === '날짜지정 23:59'}
                  onClick={() => setselectedTimeButton('날짜지정 23:59')}
                  disabled
                >
                  23:59
                </TimeButtonItem>

                <div style={{ marginLeft: '4px' }}>
                  <FormFlex>
                    <FlexNone>
                      {/* Case : 휴일 체크할 경우 disabled */}
                      <CheckBox
                        id="check29"
                        name="check29"
                        htmlFor="check29"
                        text="24시간 운영"
                        disabled
                      />
                      {/* Case : 휴일 체크할 경우 disabled */}
                    </FlexNone>

                    <CheckBox
                      id="check30"
                      name="check30"
                      htmlFor="check30"
                      text="휴일"
                      defaultChecked
                    />

                    <FlexNone>
                      <div style={{ marginLeft: '4px' }}>
                        <SubButton onClick={() => {}} />
                      </div>
                    </FlexNone>
                  </FormFlex>
                </div>
              </TimeButtonList>
              {/* Case : 날짜지정을 선택할 경우 */}
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <DashedHr />
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="주변 주요 시설" htmlFor="Select08" $row>
              <FormFlexWrap>
                <FormFlex $width="50% - 20px">
                  <div
                    style={{
                      display: 'flex',
                      gap: '8px',
                      marginBottom: '12px',
                    }}
                  >
                    <FormWrapWith
                      style={{
                        flex: 'none',
                        width: '200px',
                      }}
                    >
                      <Select
                        inputId="Select08"
                        name="Select08"
                        placeholder="선택"
                        options={options13}
                        classNamePrefix="react-select"
                      />
                    </FormWrapWith>

                    <TextField
                      id="TextField09"
                      name="text"
                      type="text"
                      placeholder="주요시설 정보를 입력하세요"
                    />

                    <AddButton onClick={addForm} />
                  </div>
                </FormFlex>

                <FormFlex $width="50% - 20px"></FormFlex>

                {forms.map((form) => (
                  <FormFlex key={form.id} $width="50% - 20px">
                    <FormWrapWith
                      style={{
                        flex: 'none',
                        width: '200px',
                      }}
                    >
                      <Select
                        inputId={form.selectId}
                        name={form.selectId}
                        placeholder="선택"
                        options={options13}
                        classNamePrefix="react-select"
                      />
                    </FormWrapWith>

                    <TextField
                      id={form.textFieldId}
                      name="text"
                      type="text"
                      placeholder="주요시설 정보를 입력하세요"
                    />

                    <SubButton onClick={() => removeForm(form.id)} />
                  </FormFlex>
                ))}
              </FormFlexWrap>
            </Formcontrol>
          </GridItem>
        </Grid>
      </section>

      <Title titlemain="충전기 정보" $pagetitle>
        <Button onClick={() => {}} $size="small" $variant="primary">
          충전기 등록
        </Button>
      </Title>

      <section style={{ marginBottom: '24px' }}>
        <AgGrid
          rowData={rowData}
          columnDefs={columnDefs}
          hasGridTop={true}
          listPerPageSelectOption={listPerPageSelectOption}
          listPerPageDefaultOption={{
            value: '5',
            label: '5개씩 보기',
          }}
        />
      </section>

      <Title
        titlemain="에너지 정보"
        $pagetitle
        $titleguide
        $titleGuideText="Required fields"
      />

      <section style={{ marginBottom: '24px' }}>
        <Grid $columns={2} $gap="12px 128px">
          <GridItem>
            <Formcontrol
              title="차단기 용량"
              htmlFor="TextField20"
              required
              $row
            >
              <TextField
                id="TextField20"
                name="text"
                type="number"
                $innerRight="KW"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="모자분리 여부" htmlFor="radio8" $row>
              <FormFlex $gap="16px">
                <FlexNone>
                  <Radio
                    id="radio8"
                    name="radio4"
                    text="Yes"
                    htmlFor="radio8"
                    $large
                    defaultChecked
                  />
                </FlexNone>

                <FlexNone>
                  <Radio
                    id="radio9"
                    name="radio4"
                    text="No"
                    htmlFor="radio9"
                    $large
                  />
                </FlexNone>
              </FormFlex>
            </Formcontrol>
          </GridItem>

          {/* Case : Yes 옵션 선택 시 노출 */}
          <GridItem>
            <Formcontrol title="피크 전력량" htmlFor="TextField21" $row>
              <TextField
                id="TextField21"
                name="text"
                type="number"
                $innerRight="KW"
              />

              <div style={{ marginTop: '12px' }}>
                <CheckBox
                  id="check01"
                  name="check01"
                  htmlFor="check01"
                  text="피크 전력 제어 여부"
                />
              </div>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="모계량기" htmlFor="TextField22" $row>
              <TextField
                id="TextField22"
                name="text"
                type="text"
                placeholder="모계량기 번호"
                $innerRight="KW"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="VCB 차단기 사양" htmlFor="TextField23" $row>
              <FormFlex>
                <TextField
                  id="TextField23"
                  name="text"
                  type="text"
                  placeholder="모델명"
                />

                <TextField
                  id="TextField24"
                  name="text"
                  type="text"
                  placeholder="전압"
                />

                <TextField
                  id="TextField25"
                  name="text"
                  type="text"
                  placeholder="전류"
                />

                <Select
                  inputId="Select23"
                  name="Select23"
                  placeholder="전압종류"
                  options={options14}
                  classNamePrefix="react-select"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="Transfomer 사양" htmlFor="TextField26" $row>
              <TextField
                id="TextField26"
                name="text"
                type="text"
                placeholder="정격 용량"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="ACB 차단기 사양" htmlFor="TextField27" $row>
              <FormFlex>
                <TextField
                  id="TextField27"
                  name="text"
                  type="text"
                  placeholder="모델명"
                />

                <TextField
                  id="TextField28"
                  name="text"
                  type="text"
                  placeholder="0"
                />

                <TextField
                  id="TextField29"
                  name="text"
                  type="text"
                  placeholder="0"
                />

                <Select
                  inputId="Select24"
                  name="Select24"
                  placeholder="전압종류"
                  options={options14}
                  classNamePrefix="react-select"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="자계량기" htmlFor="TextField41" $row>
              <FormFlex>
                <TextField
                  id="TextField41"
                  name="text"
                  type="text"
                  placeholder="자계량기 번호"
                />
              </FormFlex>
            </Formcontrol>
          </GridItem>
          {/* Case : Yes 옵션 선택 시 노출 */}

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="전력계통 간선도" $row>
              <FileSearch text="* 10MB 이하 (pdf, doc, xls, ppt, zip)" dnd />
            </Formcontrol>
          </GridItem>
        </Grid>
      </section>

      <Title
        titlemain="계약 및 부가 정보"
        $pagetitle
        $titleguide
        $titleGuideText="Required fields"
      />

      <section>
        <Grid $columns={2} $gap="12px 128px">
          <GridItem $colStart={1} $colEnd={2}>
            <Formcontrol title="서비스 시작/종료일" $row>
              <div style={{ display: 'flex', flex: '1', alignItems: 'center' }}>
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  selectsStart
                  startDate={startDate}
                  endDate={endDate}
                  dateFormat="yyyy/MM/dd"
                />
                <span style={{ margin: '0 8px' }}>-</span>
                <DatePicker
                  selected={endDate}
                  onChange={(date) => setEndDate(date)}
                  selectsEnd
                  startDate={startDate}
                  endDate={endDate}
                  minDate={startDate}
                  dateFormat="yyyy/MM/dd"
                />
              </div>
            </Formcontrol>
          </GridItem>

          <FormFlex></FormFlex>

          <GridItem>
            <Formcontrol title="부지 사용 협약기간" $row>
              <div style={{ display: 'flex', flex: '1', alignItems: 'center' }}>
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  selectsStart
                  startDate={startDate}
                  endDate={endDate}
                  dateFormat="yyyy/MM/dd"
                />
                <span style={{ margin: '0 8px' }}>-</span>
                <DatePicker
                  selected={endDate}
                  onChange={(date) => setEndDate(date)}
                  selectsEnd
                  startDate={startDate}
                  endDate={endDate}
                  minDate={startDate}
                  dateFormat="yyyy/MM/dd"
                />
              </div>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="점용료" htmlFor="TextField30" $row>
              <TextField id="TextField30" name="text" type="text" />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="점용 허가 기간" $row>
              <div style={{ display: 'flex', flex: '1', alignItems: 'center' }}>
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  selectsStart
                  startDate={startDate}
                  endDate={endDate}
                  dateFormat="yyyy/MM/dd"
                />
                <span style={{ margin: '0 8px' }}>-</span>
                <DatePicker
                  selected={endDate}
                  onChange={(date) => setEndDate(date)}
                  selectsEnd
                  startDate={startDate}
                  endDate={endDate}
                  minDate={startDate}
                  dateFormat="yyyy/MM/dd"
                />
              </div>
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="환경부 기관 ID" htmlFor="TextField31" $row>
              <TextField
                id="TextField31"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="환경부 ID" htmlFor="TextField32" $row>
              <TextField
                id="TextField32"
                name="text"
                type="text"
                placeholder="원활한 로밍 서비스를 이용하려면 환경부 ID를 반드시 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="한전 플랫폼 기관 ID" htmlFor="TextField33" $row>
              <TextField
                id="TextField33"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="한전 플랫폼 ID" htmlFor="TextField34" $row>
              <TextField
                id="TextField34"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="Alliance 기관 ID" htmlFor="TextField35" $row>
              <TextField
                id="TextField35"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="Alliance ID" htmlFor="TextField36" $row>
              <TextField
                id="TextField36"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="현대 거점" htmlFor="TextField37" $row>
              <TextField
                id="TextField37"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="거점" htmlFor="TextField38" $row>
              <TextField
                id="TextField38"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="기아 거점" htmlFor="TextField39" $row>
              <TextField
                id="TextField39"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem>
            <Formcontrol title="제네시스 거점" htmlFor="TextField40" $row>
              <TextField
                id="TextField40"
                name="text"
                type="text"
                placeholder="ID를 입력하세요"
              />
            </Formcontrol>
          </GridItem>

          <GridItem $colStart={1} $colEnd={3}>
            <Formcontrol title="부지사용 협약서" $row>
              <FileSearch
                text="* 최대 1개, 10MB 이하 (pdf, doc, xls, ppt, zip)"
                dnd
              />
            </Formcontrol>
          </GridItem>
        </Grid>
      </section>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          취소
        </Button>
        <Button onClick={() => {}} $size="large" $variant="primary">
          저장
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargingStationsEdit;

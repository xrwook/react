import React, { useRef, useEffect, useState } from 'react';
import Title from 'common/Title';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import FormControl from 'common/FormControl';
import Button from 'common/Button';
import Icon from 'common/Icon';
import { ButtonGroup } from 'common/Button/StyledButton';
import Header from 'layout/Header';
import Accordion from 'common/Accordion';
import { ContentContainer } from 'layout/StyledLayout';
import {
  Tags,
  NormalText,
  NormalList,
  InfoList,
} from '../styled/StyledChargingStations';
import { FileAttachArea } from 'common/FileSearch/StyledFileSearch';
import CardStatus from 'common/Card/CardStatus';
import Card from 'common/Card';
import CardHeader from 'common/Card/CardHeader';
import CardItem from 'common/Card/CardItem';
import {
  CardInfo,
  CardName,
  CardValue,
  CardWrap,
} from 'common/Card/StyledCard';
import AgGrid from 'common/AgGrid/AgGrid';
import AgGridTop from 'common/AgGrid/AgGridTop';
import {
  chargerHoldingRowData,
  chargerHoldingColumnDefs,
  holdingListRowData,
  holdingListColumnDefs,
  dailyUsageRowData,
  dailyUsageColumnDefs,
  reviewInfoRowData,
  reviewInfoColumnDefs,
  chargingStationsDetailOption,
} from '../components/detailData';
import { dateSelectOption } from '../components/data';
import PageFooter from 'common/PageFooter';
// import Dropdown from 'common/Dropdown/Dropdown';

const ChargingStationsListContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전소 등록 관리' },
    { to: '/', text: '충전소 상세', className: 'active' },
  ];

  const [cardTotalCnt, setCardTotalCnt] = useState<any>(0);
  const cardWrap = useRef<HTMLDivElement>(null);
  const cardTotal = cardWrap.current?.children.length;
  useEffect(() => {
    setCardTotalCnt(cardTotal);
  }, [cardTotal]);

  // dummy images
  const images = [
    { id: 1, name: '/images/dummy/img-attach.png' },
    { id: 2, name: '/images/dummy/img-attach01.jfif' },
    { id: 3, name: '/images/dummy/img-attach02.jfif' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title titlemain="충전소 상세" $titlesub="Last Updated 2024-00-00 00:00">
        <ButtonGroup $gap={8}>
          <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
            삭제
          </Button>
          <Button onClick={() => {}} $size="large" $variant="primary">
            수정
          </Button>
        </ButtonGroup>
      </Title>
      <ContentContainer $gap="48px">
        <Accordion title="기본 정보" open>
          <Grid $columns={2} $gap="12px 120px">
            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="충전소 주소" $detail $row>
                <NormalText>
                  Charging Station Address, CA, 90001 (latitude/longitude
                  information)
                  <Button
                    $variant="secondaryGray"
                    $size="mini"
                    onClick={() => {}}
                  >
                    지도 보기
                  </Button>
                </NormalText>
              </FormControl>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="상세위치" $detail $row>
                On the far right side of the parking lot
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="충전소 유형/개발 형태" $detail $row>
                Public
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="사업 유형/구분" $detail $row>
                Parking Facility
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="사업자" $detail $row>
                {/* DD : 사업자 아이콘
                    icon-cpo-cp / icon-cpo-cpo6 / icon-cpo-ea / icon-cpo-evgo / icon-cpo-shell
                */}
                <Icon $widthSize={16} $heightSize={16} $name={'icon-cpo-cp'}>
                  ChargePoint 아이콘
                </Icon>
                <span style={{ paddingLeft: '8px' }}>ChargePoint</span>
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="운영 상태" $detail $row>
                In operation
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="요금제" $detail $row>
                <NormalText>
                  Affiliate Plan
                  <Button
                    $variant="secondaryGray"
                    $size="mini"
                    onClick={() => {}}
                  >
                    요금제 상세
                  </Button>
                </NormalText>
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주차 가능 여부" $detail $row>
                Padid parking
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주차비용 여부" $detail $row>
                유료
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주차비 정보" $detail $row>
                10분당 500원
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="운영 사업자" $detail $row>
                ChargePoint Operator / 1-833-632-2778
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="위탁 사업자" $detail $row>
                -
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="결제 방식" $detail $row>
                H-Pay, Plug & Charge, NFC, General payment, Hyundai Car-Pay,
                Genesis Car-Pay, KIA Car-Pay
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="무선 충전" $detail $row>
                미지원
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="태그" $detail $row>
                <Tags>
                  <span className="tag">Plug&Charge</span>
                  <span className="tag">Public</span>
                  <span className="tag">Employee-only </span>
                  <span className="tag">Residents-only </span>
                  <span className="tag">Customers-only</span>
                  <span className="tag">Free-Parking</span>
                </Tags>
              </FormControl>
            </GridItem>

            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="충전소 이미지" $detail $row>
                <FileAttachArea>
                  {images.map((image: any) => (
                    <div
                      className="file-attach-area"
                      key={image.id}
                      data-file={image.name.replace(/^.*\//, '')}
                    >
                      <img src={image.name} />
                    </div>
                  ))}
                </FileAttachArea>
              </FormControl>
            </GridItem>
          </Grid>
        </Accordion>
        <Accordion title="영업일 및 편의시설 정보" open>
          <Grid $columns={2} $gap="12px 128px">
            <GridItem>
              <FormControl title="영업 시간" $detail $row>
                매일 24시간 영업
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주변 주요 시설" $detail $row>
                <NormalList>
                  <li className="normal-item">
                    <span>Restroom</span>
                    <span>Orange Town & Country Shopping Center</span>
                  </li>
                  <li className="normal-item">
                    <span>Wi-Fi</span>
                    <span>Free Wi-Fi</span>
                  </li>
                  <li className="normal-item">
                    <span>Restaurant</span>
                    <span>IN-N-OUT BURGER</span>
                  </li>
                  <li className="normal-item">
                    <span>Cafe</span>
                    <span>Starbucks</span>
                  </li>
                </NormalList>
              </FormControl>
            </GridItem>
          </Grid>
        </Accordion>

        <section className="content-section">
          <Title titlemain="충전기 상태/현황" $pagetitle>
            <Button onClick={() => {}} $size="small" $variant="primary">
              충전기 등록
            </Button>
          </Title>
          <AgGridTop totalCount={cardTotalCnt} $marginTop={24}></AgGridTop>
          <CardWrap ref={cardWrap}>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
          </CardWrap>
        </section>

        <Accordion title="충전기 대기 현황" open>
          <AgGrid
            rowData={chargerHoldingRowData}
            columnDefs={chargerHoldingColumnDefs}
            hasGridTop={true}
            noneButton
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={chargingStationsDetailOption[0]}
          />
        </Accordion>
        <Accordion title="당일 대기 내역" open>
          <AgGrid
            rowData={holdingListRowData}
            columnDefs={holdingListColumnDefs}
            hasGridTop={true}
            noneButton
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={chargingStationsDetailOption[0]}
          />
        </Accordion>
        <Accordion title="당일 이용 현황" open>
          <InfoList>
            <dt>충전 횟수</dt>
            <dd>1회</dd>
            <dt>충전량</dt>
            <dd>123kWh</dd>
            <dt>매출액</dt>
            <dd>100,000,000원</dd>
          </InfoList>
          <AgGrid
            rowData={dailyUsageRowData}
            columnDefs={dailyUsageColumnDefs}
            hasGridTop={true}
            noneButton
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={chargingStationsDetailOption[0]}
          />
        </Accordion>
        <Accordion title="리뷰 정보" open>
          <AgGrid
            rowData={reviewInfoRowData}
            columnDefs={reviewInfoColumnDefs}
            hasGridTop={true}
            hasDate
            noneButton
            dateSelectOption={dateSelectOption}
            dateSelectDefaultOption={dateSelectOption[0]}
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={chargingStationsDetailOption[0]}
          />
        </Accordion>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          목록으로 돌아가기
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargingStationsListContainer;

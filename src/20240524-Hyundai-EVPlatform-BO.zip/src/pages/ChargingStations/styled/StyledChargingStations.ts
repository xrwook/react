import styled from 'styled-components';
import { AgGridContainer } from 'common/AgGrid/StyledAgGrid';

export const RenderWrap = styled.div`
  display: flex;
  gap: 14px;
  height: 100%;
  align-items: center;
`;

export const RenderCommonWrap = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;

  .react-select__value-container {
  }

  .react-select__value-container {
    line-height: 1;
  }

  .react-select__control {
    padding: 0 8px;
  }

  .react-select__indicators {
    height: 100%;
  }
`;

export const RenderGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
`;

export const RenderBox = styled.div`
  display: flex;
  gap: 4px;
  height: 20px;
  align-items: center;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
`;

export const RenderCurrent = styled.span`
  color: ${(props) => props.theme.primary};

  &:after {
    content: '/';
    display: inline-block;
    vertical-align: top;
    color: ${(props) => props.theme.gray4};
  }
`;

export const RenderTotal = styled.span`
  color: ${(props) => props.theme.gray4};
`;

export const RenderConnectType = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
  color: ${(props) => props.theme.color.text2};
  line-height: 24px;
  height: 100%;
`;

// ChargingStationsRegistration
export const NoticeText = styled.p`
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  font-weight: 400;
  color: ${(props) => props.theme.color.gray4};
`;

export const DashedHr = styled.hr`
  border: none;
  height: 1px;
  background: #000;
  background: repeating-linear-gradient(
    90deg,
    #c2c5d2,
    #c2c5d2 6px,
    transparent 6px,
    transparent 9px
  );
  margin: 12px 0;
`;

export const AddButton = styled.button`
  position: relative;
  width: 32px;
  height: 32px;
  border-radius: 4px;
  padding: 6px 10px;
  box-sizing: border-box;
  background-color: ${(props) => props.theme.color.primary};

  &:hover {
    border: 1px solid #7a78ff;
    background-color: #7a78ff;
  }

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -12px;
    margin-left: -12px;
    transform: translateX(0);
    width: 24px;
    height: 24px;
    background: url('/images/icons/icon-plus.svg') no-repeat;
  }
`;

export const SubButton = styled.button`
  position: relative;
  width: 32px;
  height: 32px;
  border-radius: 4px;
  padding: 6px 10px;
  box-sizing: border-box;
  border: 1px solid ${(props) => props.theme.color.gray3};

  &:hover {
    border: 1px solid ${(props) => props.theme.color.gray2};
    background-color: ${(props) => props.theme.color.gray1};
  }

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -12px;
    margin-left: -12px;
    transform: translateX(0);
    width: 24px;
    height: 24px;
    background: url('/images/icons/icon-subtraction.svg') no-repeat;
  }
`;

export const FormFlexWrap = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0px 40px;
`;

export const FlexNone = styled.div`
  flex: none !important;
`;

export const FormWrapWith = styled.div`
  flex: none;
  width: 200px;
`;

export const DateButtonWrap = styled.div`
  width: 371px;
  margin-bottom: 24px;
`;

export const DateButtonList = styled.div`
  display: flex;
  align-items: center;
`;

export const DateButtonItem = styled.button<{
  $selected?: boolean;
  $defaultSelected?: boolean;
}>`
  width: 100%;
  padding: 6px 20px;
  box-sizing: border-box;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 500;
  white-space: nowrap;
  line-height: 20px;
  color: ${(props) =>
    props.$selected
      ? props.theme.color.white
      : props.$defaultSelected
        ? props.theme.color.gray8
        : props.theme.color.gray8};
  background-color: ${(props) =>
    props.$selected ? props.theme.color.primary : 'white'};
  border: ${(props) =>
    props.$selected
      ? `1px solid ${props.theme.color.primary}`
      : `1px solid ${props.theme.color.gray3}`};
  border-left: none;

  &:first-child {
    border-left: ${(props) =>
      props.$selected
        ? `1px solid ${props.theme.color.primary}`
        : `1px solid ${props.theme.color.gray3}`};
    border-radius: 4px 0 0 4px;
  }

  &:last-child {
    border-radius: 0 4px 4px 0;
  }
`;

export const TimeButtonList = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;

  & + & {
    margin-top: 12px;
  }
`;

export const DayButtonItem = styled.button`
  width: 100px;
  padding: 6px 10px;
  box-sizing: border-box;
  background-color: #f9f9f9;
  border: 1px solid ${(props) => props.theme.color.gray2};
  color: ${(props) => props.theme.color.text5};
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
  text-align: center;
  border-radius: 4px;
`;

export const TimeButtonItem = styled.button<{
  $day?: boolean;
  $selected?: boolean;
  disabled?: boolean;
  $defaultSelected?: boolean;
}>`
  position: relative;
  width: 100px;
  padding: 6px 10px;
  box-sizing: border-box;
  background-color: ${(props) =>
    props.$selected
      ? props.theme.color.white
      : props.disabled
        ? '#F9F9F9'
        : props.theme.color.white};
  border: ${(props) =>
    props.$selected
      ? `1px solid ${props.theme.color.primary}`
      : props.disabled
        ? `1px solid ${props.theme.color.gray2}`
        : `1px solid ${props.theme.color.gray3}`};
  color: ${(props) =>
    props.$selected
      ? props.theme.color.gray8
      : props.$defaultSelected
        ? props.theme.color.gray8
        : props.theme.color.gray4};
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
  text-align: ${(props) => (props.$day ? 'center' : 'left')};
  border-radius: 4px;

  ${(props) =>
    !props.$day &&
    `
  &::before {
    content: '';
    position: absolute;
    top: 50%;
    right: 10px; // Modified to include margin directly
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: url('/images/icons/icon-time.svg') no-repeat center;
  }
`}
`;

export interface Form {
  id: number;
  selectId?: string;
  textFieldId?: string;
  checkId?: string;
  selectId1?: string;
  selectId2?: string;
  checkId1?: string;
  checkId2?: string;
  selectedTime?: string;
}

// ChargingStationsBulkRegistration
export const GuideBox = styled.div`
  margin: 24px 0 12px 0;
`;

export const GuideText = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: ${(props) => props.theme.fontSize.fontSize4};
  line-height: 24px;
  color: ${(props) => props.theme.color.text3};
  font-weight: 500;
`;

export const TextColor = styled.div`
  margin-top: 4px;
  font-size: ${(props) => props.theme.fontSize.fontSize5};
  line-height: 24px;
  color: ${(props) => props.theme.color.textSub};
  font-weight: 600;
`;

// ChargingStationAddressSearch
export const Map = styled.div`
  position: relative;
  width: 100%;
  height: 480px;
  margin-bottom: 24px;
  border: 1px solid ${(props) => props.theme.color.gray1};
  border-radius: 8px;
  background-size: contain;
  background-repeat: no-repeat;
  // 임시로 넣은 이미지
  background-image: url('/images/dummy/img-map.png');
`;

export const MapSearch = styled.div`
  position: absolute;
  top: 10px;
  left: 10px;
  width: 320px;
`;

export const MapLocation = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

// ChargingStationsChargerEdit
export const Section = styled.div`
  padding-bottom: 40px;
  margin-bottom: 30px;
  border-bottom: 1px dashed #dadce4;

  &:last-child {
    padding-bottom: 0;
    margin-bottom: 0;
    border-bottom: unset;
  }
`;

export const SectionTitle = styled.div`
  margin-bottom: 24px;
  font-size: ${(props) => props.theme.fontSize.fontSize7};
  line-height: 32px;
  color: ${(props) => props.theme.color.text1};
  font-weight: 500;
`;

// ChargingStationsDetail
export const EllipsisText = styled.span`
  display: inline-block;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  & + button {
    margin-left: 8px;
  }
`;

export const NormalText = styled.div`
  button {
    display: inline-flex;
    margin-left: 8px;
  }
`;

export const Tags = styled.div`
  display: flex;
  flex-wrap: wrap;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => props.theme.color.tagColor};
  line-height: 20px;
  font-weight: 400;
  gap: 2px;

  .tag {
    &::before {
      content: '#';
    }
  }
`;

export const NormalList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 8px;
  .normal-item {
    display: flex;
    column-gap: 12px;
    font-size: ${(props) => props.theme.fontSize3};
    color: ${(props) => props.theme.color.text4};

    span:first-child {
      width: 100px;
    }
  }
`;

export const InfoList = styled.dl`
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 15px;
  line-height: 24px;
  font-weight: 600;
  color: #434343;
  dd {
    margin-right: 12px;
    color: ${(props) => props.theme.color.textSub};
    font-weight: 500;

    &:last-child {
      margin-right: 0;
    }
  }
  & + ${AgGridContainer} {
    margin-top: 24px;
  }
`;

// ChargingStationsLocation
export const LocationSubText = styled.h3`
  margin-bottom: 24px;
  font-size: ${(props) => props.theme.fontSize.fontSize4};
  color: ${(props) => props.theme.color.gray7};
  font-weight: 500;
`;

// ChargingStationsChargingRateInfo
export const BasicTable = styled.table`
  width: 100%;
  height: auto;
  text-align: left;
  thead th {
    padding: 14px;
    font-size: ${(props) => props.theme.fontSize.fontSize2};
    color: ${(props) => props.theme.color.text1};
    font-weight: 600;
    background-color: #f5f6fa;
    border-top: 1px solid ${(props) => props.theme.color.gray3};
    border-bottom: 1px solid ${(props) => props.theme.color.gray3};
  }
  tr {
    background-color: ${(props) => props.theme.color.white};
  }
  td {
    vertical-align: middle;
    padding: 11.5px 14px;
    font-size: ${(props) => props.theme.fontSize.fontSize3};
    font-weight: 400;
    line-height: 20px;
    color: ${(props) => props.theme.color.text2};
    background-color: ${(props) => props.theme.color.white};
    border-bottom: 1px solid ${(props) => props.theme.color.gray1};
  }
`;

export const TableText = styled.div`
  font-weight: 500;
`;

export const TableSubText = styled.span`
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  font-weight: 400;
  line-height: 20px;
`;

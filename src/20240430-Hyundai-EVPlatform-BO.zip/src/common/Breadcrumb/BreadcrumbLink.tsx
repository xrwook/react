import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import homeLineIcon from 'style/assets/images/icon-home-line.svg';

const BreadcrumbItem = styled.div`
  position: relative;
  display: inline-block;
  padding-left: 25px;
`;

const BreadcrumbItemLink = styled(NavLink)`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray4};

  &.active {
    color: ${(props) => props.theme.color.primary};
    font-weight: 600;
  }

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    width: 5px;
    height: 12px;
    margin: 0 10px;
    background: url(${homeLineIcon}) no-repeat;
  }
`;

export interface BreadcrumbProps {
  children?: any;
  to?: any;
  className?: any;
}

const BreadcrumbLink: React.FC<BreadcrumbProps> = ({
  children,
  to,
  className,
  ...props
}) => {
  return (
    <BreadcrumbItem {...props}>
      <BreadcrumbItemLink to={to} className={className}>
        {children}
      </BreadcrumbItemLink>
    </BreadcrumbItem>
  );
};

export default BreadcrumbLink;

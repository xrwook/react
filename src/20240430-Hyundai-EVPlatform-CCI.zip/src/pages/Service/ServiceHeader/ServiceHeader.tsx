import React from 'react';
import {
  HeaderWrap,
  Logo,
  Menu,
  MenuIList,
  MenuItem,
  MenuLink,
  HeaderBox,
} from 'pages/Service/StyledService/ServiceHader';

interface HeaderProps {
  logo: string;
  menuOptions: { title: string; url: string }[];
}

const ServiceHeader: React.FC<HeaderProps> = ({ logo, menuOptions }) => {
  return (
    <HeaderBox>
      <HeaderWrap>
        <Logo>{logo}</Logo>
        <Menu>
          <MenuIList>
            {menuOptions.map((option, index) => (
              <MenuItem key={index}>
                <MenuLink href={option.url}>{option.title}</MenuLink>
              </MenuItem>
            ))}
          </MenuIList>
        </Menu>
      </HeaderWrap>
    </HeaderBox>
  );
};

export default ServiceHeader;

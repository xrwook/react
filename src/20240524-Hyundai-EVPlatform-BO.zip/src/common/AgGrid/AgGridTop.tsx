import React from 'react';
import { AgGridTopStyle, AgGridTopRight, Total } from './StyledAgGrid';

export interface AgGridTopProps {
  totalCount?: any;
  children?: any;
  $marginTop?: number;
}

const AgGridTop: React.FC<AgGridTopProps> = ({
  totalCount,
  children,
  $marginTop,
}) => {
  return (
    <AgGridTopStyle $marginTop={$marginTop}>
      <Total>
        Total<strong>{totalCount}</strong>
      </Total>
      <AgGridTopRight>{children}</AgGridTopRight>
    </AgGridTopStyle>
  );
};

export default AgGridTop;

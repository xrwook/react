import { useState } from 'react';
import Title from 'common/Title';
import Header from 'layout/Header';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import DatePicker from 'common/Datepicker/Datepicker';
import TextField from 'common/TextField';
import FormFlex from 'common/FormFlex';
import AgGrid from 'common/AgGrid/AgGrid';
import FormcontrolItem from 'common/FormcontrolItem';
import Radio from 'common/Radio';
import Button from 'common/Button';
import Icon from 'common/Icon';
import { ContentContainer } from 'layout/StyledLayout';
import {
  ChargingRateRegistrationcolumnDefs,
  ChargingRateDetailFareRowData,
} from '../components/detailData';
import { FlexNone, FormText } from '../styled/StyledChargingStations';
import PageFooter from 'common/PageFooter';

const ChargingRateRegistrationContainer: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전 요금 관리' },
    { to: '/', text: '요금제 등록', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="요금제 등록"
        $titleguide
        $titleGuideText="표시는 필수 입력항목입니다"
      />

      <ContentContainer $gap="48px">
        <section>
          <Title titlemain="기본 정보" $pagetitle />

          <Grid $columns={2} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="요금제 이름" $row required>
                <TextField
                  id="TextField01"
                  name="TextField01"
                  type="text"
                  placeholder="요금제 이름을 입력하세요."
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="적용기간" $row required>
                <FormFlex>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    selectsStart
                    startDate={startDate}
                    dateFormat="yyyy/MM/dd"
                  />
                  <div className="divider"></div>
                  <DatePicker
                    selected={endDate}
                    onChange={(date) => setEndDate(date)}
                    selectsEnd
                    endDate={endDate}
                    minDate={startDate}
                    dateFormat="yyyy/MM/dd"
                  />
                </FormFlex>
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="요금제 설명" $row>
                <TextField
                  id="TextField02"
                  name="TextField02"
                  type="text"
                  placeholder="요금제 설명 내용을 입력하세요."
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title titlemain="요금 설정" $pagetitle />

          <Grid $columns={1} margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="충전 요금" $row required>
                <FormFlex>
                  <AgGrid
                    rowData={ChargingRateDetailFareRowData}
                    columnDefs={ChargingRateRegistrationcolumnDefs}
                    hasPaging={false}
                    hasGridTop={false}
                    noneButton
                  />
                </FormFlex>
              </Formcontrol>
            </GridItem>
          </Grid>

          <Grid $columns={1} $gap="12px 8px" margin="48px 0 0 0">
            <GridItem>
              <Formcontrol title="미출차 과금설정" $row>
                <FormFlex>
                  <FlexNone>
                    <FormFlex>
                      <FormText>과금 시작시간</FormText>
                      <TextField
                        id="TextField01"
                        name="TextField01"
                        type="text"
                        placeholder="0"
                        $width="60"
                      />
                    </FormFlex>
                  </FlexNone>
                  <FlexNone>
                    <FormFlex>
                      <FormText>분 경과 시부터</FormText>
                      <TextField
                        id="TextField02"
                        name="TextField02"
                        type="text"
                        placeholder="0"
                        $width="60"
                      />
                    </FormFlex>
                  </FlexNone>
                  <FlexNone>
                    <FormFlex>
                      <FormText>분당</FormText>
                      <TextField
                        id="TextField03"
                        name="TextField03"
                        type="number"
                        placeholder="숫자로 입력하세요"
                        $innerRight="원"
                        $width="200"
                      />
                    </FormFlex>
                  </FlexNone>
                </FormFlex>
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="비회원 미출차 보증금" $detail $row>
                <FormcontrolItem>
                  <TextField
                    id="TextField04"
                    name="TextField04"
                    type="number"
                    placeholder="숫자로 입력하세요"
                    $innerRight="원"
                    $width="448"
                  />
                </FormcontrolItem>
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="충전소" $detail $row>
                <FormFlex $gap="16px">
                  <FlexNone>
                    <Radio
                      id="radio8"
                      name="radio4"
                      text="전체 적용"
                      htmlFor="radio8"
                      $large
                      defaultChecked
                    />
                  </FlexNone>

                  <FlexNone>
                    <Radio
                      id="radio9"
                      name="radio4"
                      text="충전소 지정"
                      htmlFor="radio9"
                      $large
                    />
                  </FlexNone>

                  {/* DD: '전체 적용' 옵션 선택 시, 버튼은 비활성 처리 */}
                  <Button
                    onClick={() => {}}
                    $size="small"
                    $variant="secondaryGray"
                    $icon="icon-search-secondaryGray"
                  >
                    <Icon $widthSize={20} $heightSize={20}>
                      검색
                    </Icon>
                    충전소 검색
                  </Button>
                </FormFlex>
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>
      </ContentContainer>

      <PageFooter>
        <Button
          onClick={() => {}}
          $size="large"
          $variant="secondaryBlue"
          $width={65}
        >
          취소
        </Button>
        <Button onClick={() => {}} $size="large" $variant="primary" $width={65}>
          등록
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargingRateRegistrationContainer;

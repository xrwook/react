import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Dropdown from 'common/Dropdown/Dropdown';
// import TestDate from 'common/text';

const DropdownGuide = () => {
  const option = [
    {
      value: 'option01option01',
      label: 'option01option01',
    },
    {
      value: 'option02option02',
      label: 'option02option02',
    },
    {
      value: 'option03option03',
      label: 'option03option03',
    },
    {
      value: 'option04option04',
      label: 'option04option04',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>
          Dropdown(datepicker 완료 시 수정 : sample version)
        </GuideText>
        <GuideBox>
          <Dropdown options={option} placeholder="Placeholder" />
          <Dropdown options={option} disabled placeholder="Placeholder" />
          <Dropdown options={option} $readOnly placeholder="Placeholder" />
          <Dropdown
            options={option}
            placeholder="Placeholder"
            $day
            $transparent
          />
        </GuideBox>
        <GuideSubBox>&lt;Dropdown /&gt;</GuideSubBox>
        {/* <TestDate /> */}
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default DropdownGuide;

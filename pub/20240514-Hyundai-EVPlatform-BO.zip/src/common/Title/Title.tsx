import {
  TitleGuide,
  TitleLayout,
  TitleMain,
  TitleRight,
  TitleSub,
  TitleTop,
} from './StyledTitle';

export interface TitleProps {
  titlemain?: any;
  $titlesub?: any;
  $titleguide?: any;
  children?: any;
  $pagetitle?: any;
}

const Title: React.FC<TitleProps> = ({
  titlemain,
  $titlesub,
  $titleguide,
  children,
  $pagetitle,
}) => {
  return (
    <TitleLayout>
      <TitleTop $pagetitle={$pagetitle}>
        <TitleMain $pagetitle={$pagetitle}>{titlemain}</TitleMain>
        <TitleRight>
          {children}
          <TitleGuide $titleguide={$titleguide}>
            표시는 필수 입력항목입니다
          </TitleGuide>
        </TitleRight>
      </TitleTop>
      <TitleSub $titlesub={$titlesub}>{$titlesub}</TitleSub>
    </TitleLayout>
  );
};

export default Title;

import styled from 'styled-components';
import CheckIcon from 'style/assets/images/common/icon-check.svg';
import DisabledIcon from 'style/assets/images/common/icon-disabled.svg';

const CheckboxWrapper = styled.div`
  display: flex;
  align-items: center;
  vertical-align: middle;
`;

const StyledCheckbox = styled.input<CheckBoxProps>`
  appearance: none;
  display: inline-block;
  width: 18px;
  height: 18px;
  border-radius: 2px;
  transition: all 150ms;
  border: 1px solid ${(props) => props.theme.color.textDimed};
  background-color: ${(props) => props.theme.color.white};
  background-repeat: no-repeat;
  background-size: contain;
  cursor: pointer;

  &:checked {
    background-image: url(${CheckIcon});
    background-size: contain;
    border: none;
  }

  &:checked:hover {
    opacity: 0.7;
  }

  &:checked:disabled {
    background-image: url(${DisabledIcon});
    background-size: contain;
    border: none;
  }

  &:disabled {
    border: 1px solid #dbdde5;
    background-color: #f5f6fa;
  }
`;

const StyledCheckBoxText = styled.span<CheckBoxProps>`
  margin-left: 9px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => (props.disabled ? '#CDCDCD' : '#434860')};
  line-height: 20px;
  font-weight: 400;
`;

export interface CheckBoxProps {
  id?: string;
  name?: string;
  text?: string;
  htmlFor?: string;
  disabled?: boolean;
  checked?: boolean;
  defaultChecked?: boolean;
  className?: string;
}

const CheckBox: React.FC<CheckBoxProps> = ({
  id,
  name,
  text,
  htmlFor,
  disabled,
  checked,
  defaultChecked,
  className,
}) => {
  return (
    <CheckboxWrapper>
      <StyledCheckbox
        type="checkbox"
        id={id}
        name={name}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        className={className}
      />
      <label htmlFor={htmlFor}>
        {text && (
          <StyledCheckBoxText disabled={disabled}>{text}</StyledCheckBoxText>
        )}
      </label>
    </CheckboxWrapper>
  );
};

export default CheckBox;

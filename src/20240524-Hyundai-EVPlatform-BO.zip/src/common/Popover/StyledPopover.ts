import styled from 'styled-components';
import closeIcon from '/images/icons/icon-close.svg';

export const PopoverWrapper = styled.div<{ style?: any }>`
  position: absolute;
  z-index: 100;
`;

export const PopoverBox = styled.div`
  position: relative;
  width: 290px;
  height: auto;
  padding: 10px 34px 10px 16px;
  font-size: 14px;
  line-height: 20px;
  color: #575e7d;
  border: 1px solid ${(props) => props.theme.color.gray3};
  border-radius: 4px;
  background-color: ${(props) => props.theme.color.white};
`;

export const PopoverClose = styled.button`
  position: absolute;
  right: 10px;
  top: 10px;
  width: 20px;
  height: 20px;
  background: url(${closeIcon}) no-repeat;
`;

import React from 'react';
import styled from 'styled-components';

const FullFooterWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: flex-end;
  padding: 24px 30px;
  font-size: 1rem;
`;

export interface FullFooterProps {
  children?: React.ReactNode;
}

const FullFooter: React.FC<FullFooterProps> = ({ children }) => {
  return <FullFooterWrapper>{children}</FullFooterWrapper>;
};

export default FullFooter;

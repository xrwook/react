import styled from 'styled-components';

export const FooterContainer = styled.nav`
  flex: none;
  display: flex;
  justify-content: center;
  width: 100%;
  background-color: rgba(255, 255, 255, 1);
  padding: 11px 39px 18px;
  box-sizing: border-box;
  z-index: 1000;
  box-shadow: 0 -9px 19px -1px rgba(0, 0, 0, 0.03);
`;

export const Menu = styled.div`
  width: 100%;
`;

export const MenuIList = styled.ul`
  display: flex;
`;

export const MenuLink = styled.a`
  display: block;
  text-decoration: none;
  color: inherit;
  padding: 9px 0 5px;
  box-sizing: border-box;
  text-align: center;
  img {
    display: block;
    width: 24px;
    height: 24px;
    margin: 0 auto 2px;
`;

export const MenuText = styled.span`
  display: block;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  font-weight: bold;
  margin-top: 10px;
  color: ${(props) => props.color || '#bbb'};
`;

export const MenuItem = styled.li`
  flex: 1;
  min-width: 0;

  &:hover {
    ${MenuText} {
      color: #000;
      font-weight: bold;
    }
  }
`;

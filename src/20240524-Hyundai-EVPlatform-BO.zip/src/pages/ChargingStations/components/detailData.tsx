import ChargingStationsConnectTypeRender from './ChargingStationsConnectTypeRender';
import ChargingStationsButtonRender from './ChargingStationsButtonRender';
import ChargingStationsLabelRender from './ChargingStationsLabelRender';
import ChargingStationsFormRender from './ChargingStationsFormRender';
import { ButtonGroup } from 'common/Button/StyledButton';

export const chargerHoldingColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 240,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 222,
  },
  {
    headerName: '커넥터 타입',
    field: 'field4',
    minWidth: 200,
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: '대기 차량',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '예상 대기 시간 (분)',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기표 번호',
    field: 'field7',
  },
  {
    headerName: '대기 상세',
    field: 'field8',
  },
  {
    headerName: '-',
    field: 'field9',
    minWidth: 132,
    cellRenderer: (props: any) => {
      return <ChargingStationsButtonRender buttonName={props.value} />;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const chargerHoldingRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Type2',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CHAdeMO',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Combo',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
];

export const holdingListColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 200,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 200,
  },
  {
    headerName: '커넥터 타입',
    field: 'field4',
    minWidth: 200,
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: '대기자 회원 코드',
    field: 'field5',
    minWidth: 160,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '차량 종류',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기표 발급 시간',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '배차 완료 시간',
    field: 'field8',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기 시간',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const holdingListRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Type2',
    field5: '123123123',
    field6: '아이오닉6',
    field7: '2024-04-23 12:13',
    field8: '2024-04-23 12:13',
    field9: '30분',
  },
];

export const dailyUsageColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 200,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 200,
  },
  {
    headerName: '충전시작/완료 시간',
    field: 'field4',
    minWidth: 280,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전시간',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전량',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전 금액',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 그룹',
    field: 'field8',
    minWidth: 132,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 코드',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '차량 종류',
    field: 'field10',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const dailyUsageRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: '2024-04-23 12:13 - 2024-04-23 12:13',
    field5: '00분 00초',
    field6: '123 kWh',
    field7: '10,000 원',
    field8: '프라임',
    field9: '123123123',
    field10: '아이오닉6',
  },
];

export const reviewInfoColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '상태',
    field: 'field2',
    minWidth: 120,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsLabelRender status={props.value} />;
    },
  },
  {
    headerName: '작성일',
    field: 'field3',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원그룹',
    field: 'field4',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 코드',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '리뷰 내용',
    field: 'field6',
  },
  {
    headerName: '평점',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '등록일',
    field: 'field8',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '담당자',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '-',
    field: 'field10',
    minWidth: 92,
    cellRenderer: (props: any) => {
      return <ChargingStationsButtonRender buttonName={props.value} />;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const reviewInfoRowData = [
  {
    field1: '-',
    field2: 'pending',
    field3: '2024-04-23 12:13',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: '삭제',
  },
  {
    field1: '-',
    field2: 'completed',
    field3: '2024-04-23 12:13',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: 'Delete',
  },
  {
    field1: '-',
    field2: 'notAllowed',
    field3: '2024-04-23 12:13',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: '삭제',
  },
];

export const chargingStationsDetailOption = [
  {
    value: '5',
    label: '5개씩보기',
  },
  {
    value: '10',
    label: '10개씩보기',
  },
  {
    value: '15',
    label: '15개씩보기',
  },
  {
    value: '20',
    label: '20개씩보기',
  },
];

export const chargerRegistrationColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: 'EVSE',
    field: 'field2',
    minWidth: 240,
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    sortable: true,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
        />
      );
    },
  },
  {
    headerName: '위치',
    field: 'field4',
    minWidth: 110,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: () => {
      return (
        <ChargingStationsFormRender
          selectOption={[
            { value: '1', label: '오른쪽' },
            { value: '2', label: '왼쪽' },
          ]}
        />
      );
    },
  },
  {
    headerName: '환경부 ID',
    field: 'field5',
    minWidth: 212,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
          buttonName={'중복 확인'}
        />
      );
    },
  },
  {
    headerName: '커넥터 타입',
    field: 'field6',
    minWidth: 168,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field7',
    minWidth: 80,
    cellRenderer: (props: any) => {
      return <ChargingStationsButtonRender buttonName={props.value} />;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const chargerRegistrationRowData = [
  {
    field1: '-', //input
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01', //input
    field4: '오른쪽', //select
    field5: '', //input
    field6: 'CCS Type2',
    field7: '보기',
  },
];

export const ChargingStationsChargerEditColumnDefs = [
  {
    headerName: 'EVSE',
    field: 'field1',
    minWidth: 240,
  },
  {
    headerName: '번호',
    field: 'field2',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    sortable: true,
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: '위치',
    field: 'field4',
    minWidth: 110,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: () => {
      return (
        <ChargingStationsFormRender
          selectOption={[
            { value: '1', label: '오른쪽' },
            { value: '2', label: '왼쪽' },
          ]}
        />
      );
    },
  },
  {
    headerName: '환경부 ID',
    field: 'field5',
    minWidth: 240,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
          buttonName={'중복 확인'}
        />
      );
    },
  },
  {
    headerName: '커넥터 타입',
    field: 'field6',
    minWidth: 148,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field7',
    minWidth: 80,
    cellRenderer: (props: any) => {
      return <ChargingStationsButtonRender buttonName={props.value} />;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargingStationsChargerEditRowData = [
  {
    field1: 'Evse 1 [KREPTE000215000101]',
    field2: '-', //input
    field3: 'Connetor 01', //input
    field4: '오른쪽', //select
    field5: '', //input
    field6: 'CCS Type2',
    field7: '보기',
  },
];

export const ChargingStationsChargerInfoColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 60,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: 'EVSE',
    field: 'field2',
    minWidth: 220,
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    cellStyle: { textAlign: 'center' },
    sortable: true,
  },
  {
    headerName: '충전기 상태',
    field: 'field4',
    minWidth: 90,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '통신 상태',
    field: 'field5',
    minWidth: 90,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '환경부 ID',
    field: 'field6',
    minWidth: 120,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '커넥터 타입',
    field: 'field7',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field8',
    minWidth: 179,
    cellRenderer: () => {
      return (
        <div style={{ padding: '9px 0' }}>
          <ButtonGroup $gap={8}>
            <ChargingStationsButtonRender buttonName="보기" />
            <ChargingStationsButtonRender buttonName="재전송" />
            <ChargingStationsButtonRender buttonName="이력확인" />
          </ButtonGroup>
        </div>
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargingStationsChargerInfoRowData = [
  {
    field1: '-',
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01 (R)',
    field4: '미연결',
    field5: '미연결',
    field6: 'HD_191005_01',
    field7: 'CCS Type2',
    field8: '-',
  },
  {
    field1: '-',
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01 (L)',
    field4: '미연결',
    field5: '미연결',
    field6: 'HD_191005_01',
    field7: 'CCS Type2',
    field8: '-',
  },
];

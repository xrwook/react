import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Tooltip from 'common/Tooltip';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const Layout = styled.div`
  width: 300px;
  height: 100px;
  margin: 0 auto;
  position: relative;
`;

const LayoutTop = styled.div`
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
`;

const LayoutLeft = styled.div`
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
`;

const LayoutRight = styled.div`
  position: absolute;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
`;

const LayoutBottom = styled.div`
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
`;

const TooltipGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Tooltip</GuideText>
        <GuideBox>
          <Layout>
            <LayoutTop>
              <Tooltip
                message="Tooltips shouldn’t really exceed one line, but sometimes it’s unavoidable"
                $direction="top"
              >
                TOP
              </Tooltip>
            </LayoutTop>
            <LayoutLeft>
              <Tooltip message="Tooltip" $direction="left" $auto>
                LEFT
              </Tooltip>
            </LayoutLeft>
            <LayoutRight>
              <Tooltip message="Dashboard" $direction="right" $auto>
                RIGHT
              </Tooltip>
            </LayoutRight>
            <LayoutBottom>
              <Tooltip
                message="Tooltips shouldn’t really exceed one line, but sometimes it’s unavoidableTooltips shouldn’t really exceed one line, but sometimes it’s unavoidable"
                $direction="bottom"
              >
                BOTTOM
              </Tooltip>
            </LayoutBottom>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          {`<Tooltip message="Tooltip" $direction="left | right | top | bottom" $auto>
                Tootip
              </Tooltip>`}
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>message</td>
              <td>message="Tooltip"</td>
              <td>툴팁 메세지</td>
              <td></td>
            </tr>
            <tr>
              <td>$direction</td>
              <td>$direction="left"</td>
              <td>툴팁 방향 left | right | top | bottom</td>
              <td></td>
            </tr>
            <tr>
              <td>$auto</td>
              <td>$auto</td>
              <td>툴팁 사이즈 width 값 auto 선택</td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TooltipGuide;

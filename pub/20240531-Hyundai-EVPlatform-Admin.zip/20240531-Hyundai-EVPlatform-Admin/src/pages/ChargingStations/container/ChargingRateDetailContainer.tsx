import Header from 'layout/Header';
import Title from 'common/Title';
import Button from 'common/Button';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import FormcontrolItem from 'common/FormcontrolItem';
import Labels from 'common/Labels';
import AgGrid from 'common/AgGrid/AgGrid';
import PageFooter from 'common/PageFooter';
import TextField from 'common/TextField';
import FormFlex from 'common/FormFlex';
import { ButtonGroup } from 'common/Button/StyledButton';
import { ContentContainer } from 'layout/StyledLayout';
import { listPerPageSelectOption } from '../components/data';
import {
  ChargingRateDetailcolumnDefs,
  ChargingRateDetailRowData,
  ChargingRateDetailFarecolumnDefs,
  ChargingRateDetailFareRowData,
} from '../components/detailData';
import { FlexNone, FormText } from '../styled/StyledChargingStations';

const ChargingRateDetailContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전 요금 관리' },
    { to: '/', text: '요금 상세', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title titlemain="요금제 상세">
        <ButtonGroup $gap={8} $direction={'row'}>
          <Button
            onClick={() => {}}
            $size="large"
            $variant="secondaryBlue"
            $width={65}
          >
            삭제
          </Button>
          <Button
            onClick={() => {}}
            $size="large"
            $variant="secondaryBlue"
            $width={92}
          >
            적용 종료
          </Button>
          <Button
            onClick={() => {}}
            $size="large"
            $variant="secondaryBlue"
            $width={104}
          >
            요금제 복사
          </Button>
        </ButtonGroup>
      </Title>

      <ContentContainer $gap="48px">
        <section>
          <Title titlemain="24년 개인택시복지 법인 요금제" $pagetitle />
          <Grid $columns={2} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="상태" $detail $row>
                <FormcontrolItem>
                  <Labels $color="green" $size="medium">
                    적용중
                  </Labels>
                </FormcontrolItem>
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="적용기간" $detail $row>
                <FormcontrolItem>2023-11-10 ~ 2024-01-16</FormcontrolItem>
              </Formcontrol>
            </GridItem>
          </Grid>

          <Grid $columns={1} $gap="12px 0px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="설명" $detail $row>
                <FormcontrolItem>요금제 설명을 표시합니다.</FormcontrolItem>
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title
            titlemain="요금 정보"
            $pagetitle
            $titleguide
            $titleguideBlack
            $titleGuideText="KRW 기준"
          />

          <Grid $columns={1} $gap="12px 8px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="충전 요금" $detail $row>
                <FormFlex>
                  <AgGrid
                    rowData={ChargingRateDetailFareRowData}
                    columnDefs={ChargingRateDetailFarecolumnDefs}
                    hasPaging={false}
                    hasGridTop={false}
                    noneButton
                  />
                </FormFlex>
              </Formcontrol>
            </GridItem>
          </Grid>

          <Grid $columns={1} $gap="12px 8px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="미출차 과금" $row>
                <FormFlex>
                  <FlexNone>
                    <FormFlex>
                      <FormText>과금 시작시간</FormText>
                      <TextField
                        id="TextField01"
                        name="TextField01"
                        type="text"
                        value="5"
                        readOnly
                        $width="60"
                      />
                    </FormFlex>
                  </FlexNone>
                  <FlexNone>
                    <FormFlex>
                      <FormText>분 경과 시부터</FormText>
                      <TextField
                        id="TextField02"
                        name="TextField02"
                        type="text"
                        value="1"
                        readOnly
                        $width="60"
                      />
                    </FormFlex>
                  </FlexNone>
                  <FlexNone>
                    <FormFlex>
                      <FormText>분당</FormText>
                      <TextField
                        id="TextField03"
                        name="TextField03"
                        type="text"
                        value="100"
                        $innerRight="원"
                        readOnly
                        $width="200"
                      />
                    </FormFlex>
                  </FlexNone>
                </FormFlex>
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="비회원 미출차 보증금" $detail $row>
                <FormcontrolItem>
                  <TextField
                    id="TextField04"
                    name="TextField04"
                    type="number"
                    value="200"
                    $innerRight="원"
                    readOnly
                    $width="448"
                  />
                </FormcontrolItem>
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title titlemain="적용 충전소" $pagetitle />

          <div style={{ marginTop: '24px' }}>
            <AgGrid
              rowData={ChargingRateDetailRowData}
              columnDefs={ChargingRateDetailcolumnDefs}
              hasPaging={false}
              hasGridTop={true}
              listPerPageSelectOption={listPerPageSelectOption}
              listPerPageDefaultOption={{
                value: '20',
                label: '20개씩보기',
              }}
            />
          </div>
        </section>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          목록으로 돌아가기
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargingRateDetailContainer;

import styled from 'styled-components';

const TextareaStyle = styled.textarea<TextareaProps>`
  display: block;
  padding: 6px 10px;
  width: 100%;
  height: ${(props) => props.height};
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  font-weight: 500;
  color: ${(props) =>
    props.disabled ? '#CDCDCD' : props.readOnly ? '#A0A4B6' : '#434860'};
  border: ${(props) =>
    props.disabled
      ? '1px solid #DADCE4'
      : props.readOnly
        ? '1px solid #DADCE4'
        : props.error
          ? '1px solid #DB3232'
          : `1px solid #C2C5D2`};
  border-radius: 4px;
  background-color: ${(props) =>
    props.readOnly ? '#F9F9F9' : props.disabled ? '#F9F9F9' : '#fff'};

  &::placeholder {
    color: ${(props) => props.theme.color.gray4};
  }

  &:hover {
    border: ${(props) =>
      props.error ? '1px solid #DB3232' : '1px solid #5755FF'};
  }

  &:focus {
    outline: none;
    border: 1px solid ${(props) => props.theme.color.primary};
  }

  &:disabled {
    &:not(:hover) {
      pointer-events: none;
    }
  }
`;

export interface TextareaProps {
  id?: any;
  name?: any;
  value?: any;
  placeholder?: any;
  disabled?: any;
  readOnly?: any;
  error?: any;
  height?: any;
  defaultValue?: any;
}

const Textarea: React.FC<TextareaProps> = ({
  id,
  name,
  value,
  height,
  placeholder,
  disabled,
  readOnly,
  error,
  defaultValue,
}) => {
  return (
    <TextareaStyle
      id={id}
      name={name}
      value={value}
      height={height}
      disabled={disabled}
      readOnly={readOnly}
      placeholder={placeholder}
      error={error ? 'true' : undefined}
      defaultValue={defaultValue}
    />
  );
};

export default Textarea;

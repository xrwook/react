import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import TextField from 'common/TextField';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const TextFieldGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>TextField</GuideText>
        <GuideBox>
          <TextField
            id="TextField01"
            name="text"
            type="text"
            placeholder="입력해주세요"
          />
          <TextField
            id="TextField02"
            name="readOnly"
            type="text"
            placeholder="입력해주세요"
            value="readOnly"
            readOnly
          />
          <TextField
            id="TextField03"
            name="disabled"
            type="text"
            placeholder="입력해주세요"
            value="disabled"
            disabled
          />
          <TextField
            id="TextField04"
            name="number"
            type="number"
            placeholder="숫자만 입력해주세요"
          />
          <TextField
            id="TextField04"
            name="error"
            type="text"
            placeholder="error"
            error
          />
        </GuideBox>
        <GuideSubBox>
          &lt;TextField id="" name="" type="" placeholder="" /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" readOnly
          /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" disabled
          /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" error
          /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default TextFieldGuide;

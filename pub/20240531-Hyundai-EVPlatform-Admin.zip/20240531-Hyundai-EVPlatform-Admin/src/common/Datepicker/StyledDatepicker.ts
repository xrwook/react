import styled from 'styled-components';
import calenderIcon from '/images/icons/icon-calender.svg';
import previousIcon from '/images/icons/icon-previous.svg';
import nextIcon from '/images/icons/icon-next.svg';
import ReactDatePicker from 'react-datepicker';

export const DatePickerWrapper = styled.div`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
  }

  .react-datepicker-wrapper {
    width: 100%;
  }

  .react-datepicker__input-container::after {
    content: '';
    position: absolute;
    display: inline-block;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: url(${calenderIcon}) no-repeat;
  }
  .react-datepicker__triangle {
    display: none;
  }

  .react-datepicker-popper {
    top: 38px !important;
    transform: unset !important;
    z-index: 50;
  }
  .react-datepicker {
    position: relative;
    width: 334px;
    height: auto;
    padding: 30px 30px 0 30px;
    border: 1px solid #c2c5d2;
  }

  .react-datepicker__month-container {
    width: 100%;
  }
  .react-datepicker__header:not(.react-datepicker__header--has-time-select) {
    border-top-right-radius: unset;
  }
  .react-datepicker__header {
    padding: 0;
    background-color: #fff;
    border-bottom: none;

    > div:first-child {
      margin: 0 !important;
    }
  }
  .react-datepicker__navigation {
    width: 20px;
    height: 20px;
  }
  .react-datepicker__navigation--previous {
    top: 32px;
    left: 30px;
  }
  .react-datepicker__navigation-icon--previous::before {
    content: '';
    display: block;
    width: 20px;
    height: 20px;
    transform: unset;
    background: url(${previousIcon}) no-repeat;
    border: unset;
  }
  .react-datepicker__navigation--next {
    top: 32px;
    right: 30px;
  }
  .react-datepicker__navigation-icon--next::before {
    content: '';
    display: block;
    width: 20px;
    height: 20px;
    transform: unset;
    background: url(${nextIcon}) no-repeat;
    border: unset;
  }
  .react-datepicker__current-month {
    display: none;
  }
  .react-datepicker__day-names {
    margin-top: 24px;
  }
  .react-datepicker__day-name {
    width: 34px;
    margin: 0 3px;
    font-size: 14px;
    line-height: 20px;
    color: #868ba2;
    font-weight: 500;
  }
  .react-datepicker__month {
    margin: 12px 0 24px 0;
  }
  .react-datepicker__day {
    width: 30px;
    margin: 0 5px;
    font-size: 14px;
    line-height: 30px;
    color: #2d3145;
    font-weight: 500;
  }
  .react-datepicker__day--outside-month {
    color: #caccd7 !important;
    pointer-events: none;
  }
  .react-datepicker__week {
    height: 30px;
    margin: 4px 0;
  }
  .react-datepicker__day--selected .react-datepicker__day--in-selecting-range,
  .react-datepicker__day--in-range,
  .react-datepicker__day--selected,
  .react-datepicker__day--selected.react-datepicker__day:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start.react-datepicker__day--selecting-range-start,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-start.react-datepicker__day--selecting-range-start:hover,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end.react-datepicker__day--selecting-range-end,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--range-end.react-datepicker__day--selecting-range-end:hover {
    width: 30px;
    color: #5755ff !important;
    border-radius: 100% !important;
    background-color: #3d50ff1a !important;
  }
  .react-datepicker__day--in-selecting-range,
  .react-datepicker__day--in-range,
  .react-datepicker__day:hover,
  .react-datepicker__month-text:hover,
  .react-datepicker__quarter-text:hover,
  .react-datepicker__year-text:hover {
    border-radius: 100% !important;
    background-color: #f0f1f4 !important;
  }
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--in-selecting-range,
  .react-datepicker__day.react-datepicker__day--in-range.react-datepicker__day--in-selecting-range:hover {
    border-radius: 100% !important;
    background-color: #f0f1f4 !important;
  }
  .react-datepicker__header__dropdown,
  .react-datepicker__header__dropdown--select {
    display: inline-block;
    height: 30px;
    padding-top: 3px;
  }
  .react-datepicker__month-select,
  .react-datepicker__year-select {
    appearance: none;
  }
  .react-datepicker__year-dropdown-container--select,
  .react-datepicker__month-dropdown-container--select,
  .react-datepicker__month-year-dropdown-container--select {
    margin: 0 4px;
    font-size: 16px;
    line-height: 24px;
    color: #2d3145;
    font-weight: 600;
  }
  .react-datepicker__today-button {
    position: relative;
    bottom: 0;
    height: 58px;
    background: #fff;
    border-top: 1px solid #d9d9d9;
    font-size: 14px;
    line-height: 24px;
    color: #434860;
    font-weight: 500;
    padding: 14px 0 0 0;
  }
`;

export const DatePickerStyle = styled(ReactDatePicker)`
  position: relative;
  width: 100%;
  height: 32px;
  padding: 6px 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  border: 1px solid ${(props) => props.theme.color.gray3};
  background-color: ${(props) => props.theme.color.white};
  border-radius: 4px;

  &:focus {
    border: 1px solid #5755ff;
  }
`;

export const DropDownContainer = styled.div<{ value?: any }>`
  position: relative;

  + * {
    margin-left: 12px;
  }
`;

export const DropDownHeader = styled.div<{ value?: any }>`
  padding: 0 8px;
  font-size: 16px;
  line-height: 24px;
  color: #2d3145;
  font-weight: 600;
  border-radius: 4px;

  &.open {
    background-color: #f0f1f4;
  }
`;

export const PrevButton = styled.button`
  display: block;
  position: absolute;
  top: 2px;
  left: 0;
  width: 20px;
  height: 20px;
  background: url(${previousIcon}) no-repeat;
`;

export const NextButton = styled.button`
  display: block;
  position: absolute;
  top: 2px;
  right: 0;
  width: 20px;
  height: 20px;
  background: url(${nextIcon}) no-repeat;
`;

export const DropDownListContainer = styled.div`
  position: absolute;
  top: 26px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 100;
`;

export const DropDownList = styled.ul<{ value?: any }>`
  width: 112px;
  height: 232px;
  margin: 0;
  padding: 7px 8px 7px 7px;
  background-color: #fff;
  border: 1px solid #dadce4;
  border-radius: 4px;
  box-sizing: border-box;
  overflow-y: auto;
  box-shadow: 0 0 15px #0000001a;
`;

export const ListItem = styled.li`
  padding: 8px 12px;
  font-size: 14px;
  line-height: 20px;
  color: #434860;
  border-radius: 6px;
  list-style: none;

  &:hover {
    color: #5755ff;
    font-weight: 600;
    background-color: #e0e5ff80;
    transition: all 150ms;
  }
`;

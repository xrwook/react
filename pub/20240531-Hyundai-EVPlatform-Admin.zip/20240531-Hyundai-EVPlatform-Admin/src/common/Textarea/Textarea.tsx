import { useState } from 'react';
import {
  GuideText,
  TextareaCount,
  TextareaLayout,
  TextareaStyle,
} from './StyledTextarea';

export interface TextareaProps {
  id?: any;
  name?: any;
  value?: any;
  placeholder?: any;
  disabled?: any;
  readOnly?: any;
  $error?: any;
  height?: any;
  defaultValue?: any;
  maxLength?: any;
  $errorMessage?: any;
  total?: any;
}

const Textarea: React.FC<TextareaProps> = ({
  id,
  name,
  value,
  height,
  placeholder,
  disabled,
  readOnly,
  $error,
  defaultValue,
  $errorMessage,
  maxLength,
  total,
}) => {
  const [count, setCount] = useState(0);
  const onInputHandler = (e: any) => {
    setCount(e.target.value.length);
  };

  return (
    <>
      <TextareaStyle
        id={id}
        name={name}
        value={value}
        height={height}
        disabled={disabled}
        readOnly={readOnly}
        placeholder={placeholder}
        $error={$error}
        defaultValue={defaultValue}
        onChange={onInputHandler}
        maxLength={maxLength}
      />
      <TextareaLayout>
        <GuideText $errorMessage={$errorMessage}>{$errorMessage}</GuideText>
        <TextareaCount>
          <span>{count}</span>
          <span>/{total}</span>
        </TextareaCount>
      </TextareaLayout>
    </>
  );
};

export default Textarea;

import { useState } from 'react';
import { StyledGuideWrapper, StyledWrapper } from './GuideBox/GuideWrapper';
import { AlertLine } from 'common/Alert/StyledAlert';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Alert from 'common/Alert/Alert';
import AlertHeader from 'common/Alert/AlertHeader';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import Grid from 'common/Grid';

const AlertGuide = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [showAlertHeader, setShowAlertHeader] = useState(false);
  const [showAlertButton, setShowAlertButton] = useState(false);
  const [showAlertScroll, setShowAlertScroll] = useState(false);

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Alert</GuideText>
        <GuideBox>
          <Grid $columns={4}>
            <Button
              onClick={() => setShowAlert(true)}
              $variant="primary"
              $size={'small'}
            >
              Open Alert (기본)
            </Button>
            {showAlert && (
              <Alert width="396px" height="auto">
                <AlertHeader>다이얼로그 타이틀 한글</AlertHeader>
                <AlertContent>
                  다이얼로그 상세 내용을 여기에 입력하세요.
                  <br />
                  다이얼로그 상세 내용을 한 번 더 여기에 입력하세요.
                </AlertContent>
                <AlertFooter>
                  <Button
                    onClick={() => setShowAlert(false)}
                    $size="large"
                    $variant="secondaryBlue"
                  >
                    취소
                  </Button>
                  <Button onClick={() => {}} $size="large" $variant="primary">
                    등록
                  </Button>
                </AlertFooter>
              </Alert>
            )}

            <Button
              onClick={() => setShowAlertHeader(true)}
              $variant="secondaryBlue"
              $size={'small'}
            >
              Open Alert (header 없음)
            </Button>
            {showAlertHeader && (
              <Alert width="400px" height="auto">
                <AlertContent>
                  개인택시복지 법인 요금제를 강제로 종료하시겠습니까?
                </AlertContent>
                <AlertFooter>
                  <Button
                    onClick={() => setShowAlertHeader(false)}
                    $size="large"
                    $variant="secondaryBlue"
                  >
                    취소
                  </Button>
                  <Button
                    onClick={() => setShowAlertHeader(false)}
                    $size="large"
                    $variant="primary"
                  >
                    적용 종료
                  </Button>
                </AlertFooter>
              </Alert>
            )}

            <Button
              onClick={() => setShowAlertButton(true)}
              $variant="primary"
              $size={'small'}
            >
              Open Alert (버튼 한개)
            </Button>
            {showAlertButton && (
              <Alert width="400px" height="auto">
                <AlertHeader>다이얼로그 타이틀 한글</AlertHeader>
                <AlertContent>
                  다이얼로그 상세 내용을 여기에 입력하세요.
                  <br />
                  다이얼로그 상세 내용을 한 번 더 여기에 입력하세요.
                  <AlertLine />
                  기타 부연 설명은 여기에 입력하세요.
                </AlertContent>
                <AlertFooter>
                  <Button
                    onClick={() => setShowAlertButton(false)}
                    $size="large"
                    $variant="primary"
                  >
                    확인
                  </Button>
                </AlertFooter>
              </Alert>
            )}

            <Button
              onClick={() => setShowAlertScroll(true)}
              $size="large"
              $variant="secondaryBlue"
            >
              Open Alert (scroll)
            </Button>
            {showAlertScroll && (
              <Alert width="400px" height="auto">
                <AlertHeader>다이얼로그 타이틀 한글</AlertHeader>
                <AlertContent>
                  Dialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog Dialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog body text goes hereDialog body text goes
                  hereDialog body text goes hereDialog body text goes hereDialog
                  body text goes hereDialog body text goes hereDialog body text
                  goes hereDialog
                </AlertContent>
                <AlertFooter>
                  <Button
                    $size="large"
                    $variant="secondaryBlue"
                    onClick={() => setShowAlertScroll(false)}
                  >
                    취소
                  </Button>
                  <Button
                    onClick={() => setShowAlertScroll(false)}
                    $size="large"
                    $variant="primary"
                  >
                    확인
                  </Button>
                </AlertFooter>
              </Alert>
            )}
          </Grid>
        </GuideBox>
        <GuideSubBox>
          &lt;Alert width="" height=""&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;AlertHeader&gt; 타이틀 &lt;/AlertHeader&gt;{' '}
          <br />
          &nbsp;&nbsp;&nbsp;&lt;AlertContent&gt; 컨텐츠 영역
          &lt;/AlertContent&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;AlertFooter&gt; 버튼 영역 &lt;/AlertFooter&gt;{' '}
          <br />
          &lt;/Alert&gt;
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>width</td>
              <td>width="400px"</td>
              <td>Alert 넓이값</td>
              <td></td>
            </tr>
            <tr>
              <td>height</td>
              <td>height="400px"</td>
              <td>Alert 높이값</td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default AlertGuide;

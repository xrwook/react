import styled from 'styled-components';
import { TextareaProps } from './Textarea';

export const TextareaStyle = styled.textarea<TextareaProps>`
  display: block;
  width: 100%;
  height: ${(props) => props.height};
  padding: 6px 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) =>
    props.disabled
      ? `${props.theme.color.textDimed}`
      : props.readOnly
        ? `${props.theme.color.gray4}`
        : `${props.theme.color.gray8}`};
  font-weight: 500;
  border: ${(props) =>
    props.disabled
      ? `1px solid ${props.theme.color.gray2}`
      : props.readOnly
        ? `1px solid ${props.theme.color.gray2}`
        : props.$error
          ? '1px solid #DB3232'
          : `1px solid ${props.theme.color.gray3}`};
  border-radius: 4px;
  background-color: ${(props) =>
    props.readOnly
      ? '#F9F9F9'
      : props.disabled
        ? '#F9F9F9'
        : `${props.theme.color.white}`};

  &::placeholder {
    color: ${(props) => props.theme.color.gray4};
  }

  &:hover {
    border: ${(props) =>
      props.$error
        ? '1px solid #DB3232'
        : `1px solid ${props.theme.color.primary}`};
  }

  &:focus {
    border: 1px solid
      ${(props) => (props.$error ? '#DB3232' : props.theme.color.primary)};
    outline: none;
  }

  &:disabled {
    &:not(:hover) {
      pointer-events: none;
    }
  }
`;

export const TextareaLayout = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 4px;
`;

export const TextareaCount = styled.div`
  display: flex;
  align-items: center;
  margin-top: 2px;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray4};
  font-weight: 500;
`;

export const GuideText = styled.div<TextareaProps>`
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  color: #db3232;
  font-weight: 500;
`;

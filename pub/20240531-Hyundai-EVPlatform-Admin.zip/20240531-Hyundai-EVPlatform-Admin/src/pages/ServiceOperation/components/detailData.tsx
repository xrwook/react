import ChargingStationsButtonRender from '../../ChargingStations/components/ChargingStationsButtonRender';

export const dailyUsageRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: '2024-04-23 12:13 - 2024-04-23 12:13',
    field5: '00분 00초',
    field6: '123 kWh',
    field7: '10,000 원',
    field8: '프라임',
    field9: '123123123',
    field10: '아이오닉6',
  },
];

export const dailyUsageColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 200,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 200,
  },
  {
    headerName: '충전시작/완료 시간',
    field: 'field4',
    minWidth: 280,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전 시간',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전량',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전 금액',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원그룹',
    field: 'field8',
    minWidth: 132,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원번호',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '차량종류',
    field: 'field10',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const chargingStationsDetailOption = [
  {
    value: '5',
    label: '5개씩보기',
  },
  {
    value: '10',
    label: '10개씩보기',
  },
  {
    value: '15',
    label: '15개씩보기',
  },
  {
    value: '20',
    label: '20개씩보기',
  },
];

export const reviewInfoRowData = [
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '프라임',
    field4: '123123123',
    field5:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field6: '충전 성공',
    field7: '2024-04-23 12:13',
    field8: '김현대 매니저',
    field9: '삭제',
  },
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '프라임',
    field4: '123123123',
    field5:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field6: '충전 성공',
    field7: '2024-04-23 12:13',
    field8: '김현대 매니저',
    field9: 'Delete',
  },
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '프라임',
    field4: '123123123',
    field5:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field6: '충전 실패',
    field7: '2024-04-23 12:13',
    field8: '김현대 매니저',
    field9: '삭제',
  },
];

export const reviewInfoColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '작성일',
    field: 'field2',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 160,
  },
  {
    headerName: '회원그룹',
    field: 'field3',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 120,
  },
  {
    headerName: '회원번호',
    field: 'field4',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 160,
  },
  {
    headerName: '리뷰내용',
    field: 'field5',
  },
  {
    headerName: '충전여부',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 100,
  },
  {
    headerName: '등록일시',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 160,
  },
  {
    headerName: '담당자',
    field: 'field8',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    maxWidth: 160,
  },
  {
    headerName: '-',
    field: 'field9',
    minWidth: 92,
    maxWidth: 92,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

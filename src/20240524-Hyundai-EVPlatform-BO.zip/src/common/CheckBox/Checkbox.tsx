import {
  CheckboxWrapper,
  StyledCheckBoxText,
  StyledCheckbox,
} from './StyledCheckbox';

export interface CheckBoxProps {
  id?: string;
  name?: any;
  text?: any;
  htmlFor?: any;
  disabled?: any;
  checked?: any;
  defaultChecked?: any;
  className?: any;
  type?: any;
  onChange?: any;
}

const CheckBox: React.FC<CheckBoxProps> = ({
  id,
  name,
  text,
  disabled,
  checked,
  defaultChecked,
  className,
  onChange,
}) => {
  return (
    <CheckboxWrapper>
      <StyledCheckbox
        type="checkbox"
        id={id}
        name={name}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        className={className}
        onChange={onChange}
      />
      <label htmlFor={id}>
        {text && (
          <StyledCheckBoxText disabled={disabled}>{text}</StyledCheckBoxText>
        )}
      </label>
    </CheckboxWrapper>
  );
};

export default CheckBox;

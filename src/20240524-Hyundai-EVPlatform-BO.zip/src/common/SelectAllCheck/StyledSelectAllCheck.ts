import styled from 'styled-components';
import arrowIcon from '/images/icons/icon-select-arrow.svg';
import arrowActiveIcon from '/images/icons/icon-select-arrow-active.svg';
import checkIcon from '/images/icons/icon-check.svg';
import reactSelect from 'react-select';
import { SelectAllCheckProps } from './SelectAllCheck';

export const SelectStyle = styled(reactSelect)<SelectAllCheckProps>`
  .react-select__control {
    padding: 6px 8px;
    min-height: 32px;
    height: 32px;
    width: auto;
    border-radius: 4px;
    border: ${(props) =>
      props.disabled
        ? '1px solid #dadce4'
        : props.readonly
          ? '1px solid #dadce4'
          : props.$transparent
            ? 'transparent'
            : '1px solid #c2c5d2'};
    color: ${(props) =>
      props.isDisabled ? '#cdcdcd' : props.readonly ? '#A0A4B6' : '#434860'};
    background-color: ${(props) =>
      props.isDisabled ? '#f9f9f9' : props.readonly ? '#F9F9F9' : '#fff'};
    box-shadow: none;
  }
  .react-select__control--is-focused {
    border-color: #5755ff !important;
    .react-select__indicator {
      background-image: ${(props) =>
        props.readonly ? ` url(${arrowIcon})` : `url(${arrowActiveIcon})`};
    }
  }
  .react-select__control .react-select__value-container {
    padding: 0 32px 0 0;
    display: flex;
  }
  .react-select__single-value {
    margin: 0;
    font-size: 14px;
    line-height: 20px;
    color: ${(props) =>
      props.isDisabled
        ? '#cdcdcd'
        : props.readonly
          ? '#A0A4B6'
          : props.$transparent
            ? '#455DD7'
            : '#434860'};
    font-weight: ${(props) => (props.$transparent ? '500' : '400')};
  }
  .react-select__placeholder {
    margin-left: 0;
    margin-right: 0;
    font-size: 14px;
    line-height: 20px;
    color: ${(props) =>
      props.isDisabled ? '#cdcdcd' : props.readonly ? '#A0A4B6' : '#434860'};
  }
  .react-select__input {
    margin-top: 4px;
    height: 20px;
  }
  .react-select__input-container {
    position: absolute;
    top: 0;
    margin: 0;
    padding: 0;
  }
  .react-select__indicators {
    display: block;
    height: 20px;
  }
  .react-select__indicator {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    padding: 0;
    width: 20px;
    height: 20px;
    background-image: url(${arrowIcon});
    opacity: ${(props) =>
      props.isDisabled ? '0.5' : props.readonly ? '0.5' : '1'};

    svg {
      display: none;
    }
  }
  .react-select__indicator-separator {
    display: none;
  }
  .react-select--is-focused {
    border: 1px solid red;
  }
  .react-select__menu {
    box-shadow: 0 6px 10px #0000000d;
    border: 1px solid #caccd7;
    border-radius: 4px;
    padding: 8px;
    width: 100%;
    max-width: 300px;
    min-width: 200px;
  }
  .react-select__option {
    height: 36px;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 14px;
    line-height: 20px;
    color: #434860;
    font-weight: 400;
    display: flex;
    align-items: center;
  }
  .react-select__option--is-focused {
    background-color: #f8f9fb;
  }
  .react-select__option--is-selected {
    background-color: transparent;
  }
  .checkbox {
    appearance: none;
    width: 18px;
    height: 18px;
    border: 1px solid #cdcdcd;
    border-radius: 2px;
    margin-right: 9px;

    &:checked {
      width: 18px;
      height: 18px;
      border: none;
      background-size: contain;
      background: url(${checkIcon}) no-repeat;
    }
  }
  .react-select__multi-value {
    border-radius: 0;
    margin: 0;
    background-color: transparent;
    position: relative;

    + .react-select__multi-value {
      padding-left: 6px;

      &::after {
        content: ',';
        font-size: 14px;
        position: absolute;
        bottom: 2px;
        left: 0;
      }
    }
  }
  .react-select__multi-value__label {
    background-color: transparent;
    color: ${(props) =>
      props.isDisabled ? '#cdcdcd' : props.readonly ? '#A0A4B6' : '#434860'};
    font-size: 14px;
    line-height: 20px;
    padding: 0;
  }
  .react-select__multi-value__remove {
    display: none;
  }
`;

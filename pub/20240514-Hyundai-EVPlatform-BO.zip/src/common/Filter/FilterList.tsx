import { useState, useRef, useEffect } from 'react';
import { FilterListStyle, FilterListWrap } from './StyledFilter';
import Button from 'common/Button/Button';
export interface FilterListProps {
  children?: any;
  useDetailButtons?: boolean;
}

const FilterList: React.FC<FilterListProps> = ({
  children,
  useDetailButtons,
}) => {
  const [expanded, setExpanded] = useState(false);
  const [detailButton, setDetailButton] = useState(
    useDetailButtons && useDetailButtons,
  );
  const filterList = useRef<any>(null);
  const handleClick = () => {
    setExpanded(!expanded);
  };

  useEffect(() => {
    const observer = new ResizeObserver((entries: any[]) => {
      for (const entry of entries) {
        const { height } = entry.contentRect;

        if (height < 50) {
          setDetailButton(false);
        } else {
          setDetailButton(true);
        }
      }
    });
    observer.observe(filterList?.current);
  }, []);

  return (
    <FilterListWrap className={expanded ? 'filter-expanded' : ''}>
      <FilterListStyle className="filter-list" ref={filterList}>
        {children}
      </FilterListStyle>
      {detailButton && (
        <div className="filter-detail-button-group">
          {!expanded ? (
            <Button
              onClick={handleClick}
              $size="mini"
              $variant="secondaryGray"
              className="filter-detail-button__detail"
            >
              더보기
            </Button>
          ) : (
            <>
              <Button
                onClick={() => {}}
                $size="mini"
                $variant="secondaryGray"
                className="filter-detail-button__detail"
              >
                초기화
              </Button>
              <Button
                onClick={handleClick}
                $size="mini"
                $variant="secondaryGray"
                className="filter-detail-button__detail"
              >
                간략히
              </Button>
            </>
          )}
        </div>
      )}
    </FilterListWrap>
  );
};

export default FilterList;

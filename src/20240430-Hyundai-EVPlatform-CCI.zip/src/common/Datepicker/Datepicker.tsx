import styled from 'styled-components';
import ReactDatePicker, {
  ReactDatePickerProps,
  registerLocale,
} from 'react-datepicker';
import { ko } from 'date-fns/locale/ko';
import 'react-datepicker/dist/react-datepicker.css';

registerLocale('ko', ko);

const DatePickerWrapper = styled.div`
  width: auto;
`;

const StyledDatePicker = styled(ReactDatePicker)`
  border: 1px solid #e0e0e0;
  padding: 8px 15px;
  border-radius: 4px;

  .react-datepicker__input-container::after {
    content: '';
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    width: 18px;
    height: 18px;
    z-index: 100;
  }

  .react-datepicker__triangle {
    display: none;
  }

  .react-datepicker__header {
    padding: 12px 0 6px 0;
    background-color: #ffffff;
  }

  .react-datepicker__current-month {
    font-size: 13px;
    font-weight: 600;
    color: #20222f;
    line-height: 19px;
  }
`;

const DatePicker = ({ ...props }: ReactDatePickerProps) => {
  return (
    <DatePickerWrapper>
      <StyledDatePicker
        {...props}
        disabledKeyboardNavigation
        dateFormatCalendar="yyyy년 MM월"
        locale="ko"
        className="color-navy300 border-color-gray500"
      />
    </DatePickerWrapper>
  );
};

export default DatePicker;

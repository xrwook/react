import React from 'react';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Progress from 'common/Progress';
import TextProgress from 'common/TextProgress';
import ReckoningProgress from 'common/ReckoningProgress';

const ProgressGuide: React.FC = () => {
  return (
    <GuideWrapper>
      <div style={{ padding: '50px' }}>
        <section>
          <GuideText>Progress</GuideText>
          <GuideBox>
            <Progress total={5} current={1} background="#1890FF" />
            <br />
            <br />
            <Progress total={5} current={4} background="#1AB46A" />
          </GuideBox>
          <GuideSubBox>
            &lt;Progress total={5} current={1} background="#1890FF"&gt; <br />
            &lt;Progress total={5} current={4} background="#1AB46A"&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>total</td>
                <td>total</td>
                <td>총 단계 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>current</td>
                <td>current</td>
                <td>step 단계 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>background</td>
                <td>background</td>
                <td>background 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>TextProgress</GuideText>
          <GuideBox>
            <TextProgress
              steps={[
                '본인인증',
                '계약자정보',
                '금융조건',
                '면허정보',
                '약관동의',
                '본인인증',
                'ARS',
              ]}
              current={3}
              borderBottom="#1890FF"
              textColor="#1890FF"
              border="#1890FF"
            />
            <br />
            <br />
            <br />
            <TextProgress
              steps={[
                '본인인증',
                '계약자정보',
                '금융조건',
                '면허정보',
                '약관동의',
                '본인인증',
                'ARS',
              ]}
              current={7}
              borderBottom="#1AB46A"
              textColor="#1AB46A"
              border="#1AB46A"
            />
          </GuideBox>
          <GuideSubBox>
            &lt;TextProgress steps='' current={3}
            borderBottom="#1890FF" textColor="#1890FF" border="#1890FF"&gt;{' '}
            <br />
            &lt;TextProgress steps='' current={7}
            borderBottom="#1AB46A" textColor="#1AB46A" border="#1AB46A"&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>steps</td>
                <td>steps</td>
                <td>총 단계 기입</td>
                <td>-</td>
              </tr>
              <tr>
                <td>current</td>
                <td>current</td>
                <td>step 단계 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>borderBottom</td>
                <td>borderBottom</td>
                <td>선 색상 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>textColor</td>
                <td>textColor</td>
                <td>textColor 색상 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>border</td>
                <td>border</td>
                <td>동그라미 색상 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>ReckoningProgress</GuideText>
          <GuideBox>
            <ReckoningProgress minPercentage={53} maxPercentage={72} />
          </GuideBox>
          <GuideSubBox>
            &lt;ReckoningProgress minPercentage='' maxPercentage=''&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>minPercentage</td>
                <td>minPercentage</td>
                <td>최소값 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>maxPercentage</td>
                <td>maxPercentage</td>
                <td>최대값 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>
      </div>
    </GuideWrapper>
  );
};

export default ProgressGuide;

import { useState } from 'react';
import {
  DeleteButton,
  InputText,
  InputWrapper,
  SearchButton,
} from './StyledTextField';

export interface TextFieldProps {
  type?: any;
  id?: any;
  name?: any;
  placeholder?: any;
  disabled?: any;
  readOnly?: any;
  $error?: any;
  $inputValue?: any;
  value?: any;
  $search?: any;
}

const TextField: React.FC<TextFieldProps> = ({
  type,
  id,
  name,
  placeholder,
  disabled,
  readOnly,
  $error,
  $search,
  value,
}) => {
  const [inputValue, setInputValue] = useState('');

  const handleChange = (event: any) => {
    setInputValue(event.target.value);
  };
  const handleClearInput = (event: any) => {
    event.stopPropagation();
    setInputValue('');
  };

  return (
    <InputWrapper className={inputValue ? 'input-typing' : ''}>
      <InputText
        id={id}
        name={name}
        type={type}
        value={value}
        $inputValue={inputValue}
        onChange={handleChange}
        disabled={disabled}
        readOnly={readOnly}
        placeholder={placeholder}
        $error={$error}
      />
      {inputValue && (
        <DeleteButton onClick={handleClearInput} $search={$search} />
      )}
      <SearchButton
        $search={$search}
        disabled={disabled}
        readOnly={readOnly}
        $inputValue={inputValue}
      />
    </InputWrapper>
  );
};

export default TextField;

import { Route, Routes } from 'react-router-dom';
import KiaBrandTest from '../pages/brand/KiaBrandTest';

const KiaRoute = () => {
  return (
    <Routes>
      <Route path="brand" element={<KiaBrandTest />} />
    </Routes>
  );
};

export default KiaRoute;
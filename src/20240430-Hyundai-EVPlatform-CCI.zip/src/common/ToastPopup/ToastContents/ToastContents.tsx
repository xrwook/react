import React from 'react';
import styled from 'styled-components';

const ToastContentsWrapper = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 20px 30px 24px 30px;
`;

export interface ToastContentsProps {
  children?: React.ReactNode;
}

const ToastContents: React.FC<ToastContentsProps> = ({ children }) => {
  return <ToastContentsWrapper>{children}</ToastContentsWrapper>;
};

export default ToastContents;

import styled, { css } from 'styled-components';
import { FilterItemProps } from './FilterItem';
import { InputWrapper } from 'common/TextField/StyledTextField';
import { SelectText } from 'common/Select/StyledSelect';
import { DropdownWrapper } from 'common/Dropdown/StyledDropdown';
import {
  MenuInner,
  MenuContainer,
} from 'common/SelectSearch/StyledSelectSearch';
import { OptionWrapper } from 'common/DropdownOptionDay/StyledDropdownOptionDay';

export const FilterListWrap = styled.div`
  position: relative;

  &:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    border-bottom: 1px solid #d9d9d9;
  }

  .filter-detail-button-group {
    height: 32px;
    display: inline-flex;
    align-items: center;
    gap: 10px;
  }
`;

export const FilterListStyle = styled.div`
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  position: relative;
  max-width: 1800px;
  padding-bottom: 4px;

  .filter-detail-button-group {
    margin-left: 12px;
    margin-bottom: 12px;
  }
`;

export const FilterItemStyle = styled.div<FilterItemProps>`
  position: relative;
  display: flex;
  align-items: center;
  padding: ${(props) =>
    props.$search ? '0' : props.$button ? '0 0 0 4px' : '0 8px 0 12px'};
  margin-bottom: 12px;
  margin-right: ${(props) => (props.$search ? '12px' : '8px')};

  > [class*='-container'],
  ${DropdownWrapper},${MenuInner} {
    position: static;
  }

  ${OptionWrapper}, ${MenuContainer} {
    left: 12px;
  }

  .filter {
    .react-select__menu {
      left: 0;
    }
  }
  .react-select__menu {
    left: 12px;
  }

  ${(props) => {
    if (props.$search) {
      return css`
        ${InputWrapper} {
          &.input-typing {
            input {
              padding-right: 50px;
            }
          }
        }
      `;
    }
  }}

  &:hover {
    border-radius: 4px;
    background-color: ${(props) =>
      props.$button ? 'none' : `${props.theme.color.gray1}`};
  }

  > div > input {
    width: ${(props) => (props.$search ? '296px' : 'auto')};
    ${(props) => {
      if (props.$search) {
        return css`
          padding-right: 26px;
        `;
      }
    }}
  }

  .react-select__control {
    margin-bottom: 0;
    line-height: 32px;
  }

  .react-select__indicators {
    height: 100%;
  }

  .react-select__input-container {
    position: relative;
  }

  .react-select__input {
    position: absolute;
    left: 0;
  }

  .react-select__value-container {
    height: 100%;
    line-height: 18px;
  }

  ${SelectText} {
    max-width: 400px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;

export const FilterLabeltyle = styled.div`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: #434343;
  font-weight: 600;
`;

import { ModalFooterWrapper } from './StyledModal';

export interface ModalFooterProps {
  children?: any;
}

const ModalFooter: React.FC<ModalFooterProps> = ({ children }) => {
  return (
    <>
      <ModalFooterWrapper>{children}</ModalFooterWrapper>
    </>
  );
};

export default ModalFooter;

import React from 'react';
import styled from 'styled-components';

const ButtonListWrap = styled.div`
  display: flex;
  align-items: stretch;
  justify-content: flex-start;
  width: 100%;
  height: auto;

  button + button {
    margin-left: 1rem;
  }
`;

export interface ButtonListProps {
  children?: React.ReactNode;
}

const ButtonList: React.FC<ButtonListProps> = ({ children }) => {
  return <ButtonListWrap>{children}</ButtonListWrap>;
};

export default ButtonList;

import { Route, Routes, BrowserRouter } from 'react-router-dom';
import { Layout } from 'common/Tab/Layout';
import { Home_ } from 'common/Tab/Home';
import { AxiosQuery } from 'pages/Subpage/AxiosQuery';
import { ReactQuery } from 'pages/Subpage/ReactQuery';
import Home from 'pages/Home';
import GuideRoute from 'routes/GuideRoute';
import PrivateRoute from 'routes/PrivateRoute';
import PublicRoute from 'routes/PublicRoute';
import React from 'react';
import { ServiceType } from 'types/serviceType';
import HyundaiRoute from 'routes/HyundaiRoute';
import KiaRoute from 'routes/KiaRoute';
import GenesisRoute from 'routes/GenesisRoute';
import MainLayout from 'layout/MainLayout';
import SubLayout from 'layout/SubLayout';
import ChargingStationsListContainer from 'pages/ChargingStations/container/ChargingStationsListContainer';
import PublishingRoute from './PublishingRoute';

export interface RouterProps {
  serviceType: ServiceType;
}

const Router: React.FC<RouterProps> = ({ serviceType }) => (
  <BrowserRouter>
    <Routes>
      <Route
        path="/"
        element={
          <PublicRoute>
            <Home />
          </PublicRoute>
        }
      />
      <Route
        path="/tab"
        element={
          <PrivateRoute>
            {/* <Articles /> */}
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Home_ />} />
        <Route path="axios-query" element={<AxiosQuery />} />
        <Route path="react-query" element={<ReactQuery />} />
        {/* 임시 레이아웃 Route */}
        {/* <Route path="/main" element={<GlobalLayout />} /> */}
      </Route>
      <Route path="main" element={<MainLayout />} />
      <Route path="/" element={<SubLayout />}>
        <Route
          path="ChargingStationsList"
          element={<ChargingStationsListContainer />}
        />
      </Route>
    </Routes>
    {/* GuideRoute / PublishingRoute 추가 */}
    <GuideRoute />
    <PublishingRoute />
    {/* DD : 어드민 분기 처리 미결정으로 우선 주석 처리함 */}
    {/* {serviceType == ServiceType.Hyundai ? (
      <HyundaiRoute />
    ) : serviceType == ServiceType.Kia ? (
      <KiaRoute />
    ) : serviceType == ServiceType.Genesis ? (
      <GenesisRoute />
    ) : (
      <></>
    )} */}
  </BrowserRouter>
);

export default Router;

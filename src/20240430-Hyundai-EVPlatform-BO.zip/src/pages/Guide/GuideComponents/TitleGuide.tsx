import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Title from 'common/Title/Title';
import Button from 'common/Button/Button';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const TitleGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Title</GuideText>
        <GuideBox>
          <Title
            titlemain="Current Page Title"
            titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
          >
            <Button onClick={() => {}} size="mini" variant="primary">
              Button
            </Button>
          </Title>
        </GuideBox>
        <GuideSubBox>
          &lt;Title id="" text="" name="" htmlFor="" defaultChecked large /&gt;{' '}
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default TitleGuide;

import styled from 'styled-components';
import { IconProps } from './Icon';

export const IconStyle = styled.div<IconProps>`
  display: inline-flex;
  width: ${(props) => props.$widthSize}px;
  height: ${(props) => props.$heightSize}px;
  background: url('/images/icons/${(props) => props.$name}.svg') no-repeat
    center / cover;
  vertical-align: top;

  .blind-text {
    overflow: hidden;
    position: absolute;
    clip: rect(0, 0, 0, 0);
    clip-path: polygon(0 0, 0 0, 0 0);
    width: 1px;
    height: 1px;
    margin: -1px;
  }
`;

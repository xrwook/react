import { styled } from 'styled-components';
import { AgGridContainer } from 'common/AgGrid/StyledAgGrid';

export const RenderWrap = styled.div`
  display: flex;
  gap: 14px;
  height: 100%;
  align-items: center;
`;

export const RenderCommonWrap = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;

  .react-select__value-container {
  }

  .react-select__value-container {
    line-height: 1;
  }

  .react-select__control {
    padding: 0 8px;
  }

  .react-select__indicators {
    height: 100%;
  }
`;

export const RenderGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
`;

export const RenderBox = styled.div`
  display: flex;
  gap: 4px;
  height: 20px;
  align-items: center;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
`;

export const RenderCurrent = styled.span`
  color: ${(props) => props.theme.primary};

  &:after {
    content: '/';
    display: inline-block;
    vertical-align: top;
    color: ${(props) => props.theme.gray4};
  }
`;

export const RenderTotal = styled.span`
  color: ${(props) => props.theme.gray4};
`;

export const RenderConnectType = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 400;
  color: ${(props) => props.theme.color.text2};
  line-height: 24px;
  height: 100%;
`;

// ChargingStationStatusChargingStationLocation
export const Map = styled.div`
  position: relative;
  width: 100%;
  height: 480px;
  margin-bottom: 24px;
  border: 1px solid ${(props) => props.theme.color.gray1};
  border-radius: 8px;
  background-size: contain;
  background-repeat: no-repeat;
  // 임시로 넣은 이미지
  background-image: url('/images/dummy/img-map.png');
`;
export const LocationSubText = styled.h3`
  margin-bottom: 24px;
  font-size: ${(props) => props.theme.fontSize.fontSize4};
  color: ${(props) => props.theme.color.gray7};
  font-weight: 500;
`;

// ChargingStationStatusChargingRateInfo
export const BasicTable = styled.table`
  width: 100%;
  height: auto;
  text-align: left;
  thead th {
    padding: 14px;
    font-size: ${(props) => props.theme.fontSize.fontSize2};
    color: ${(props) => props.theme.color.text1};
    font-weight: 600;
    background-color: #f5f6fa;
    border-top: 1px solid ${(props) => props.theme.color.gray3};
    border-bottom: 1px solid ${(props) => props.theme.color.gray3};
  }
  tr {
    background-color: ${(props) => props.theme.color.white};
  }
  td {
    vertical-align: middle;
    padding: 11.5px 14px;
    font-size: ${(props) => props.theme.fontSize.fontSize3};
    font-weight: 400;
    line-height: 20px;
    color: ${(props) => props.theme.color.text2};
    background-color: ${(props) => props.theme.color.white};
    border-bottom: 1px solid ${(props) => props.theme.color.gray1};
  }
`;

export const TableText = styled.div`
  font-weight: 500;
`;

export const TableSubText = styled.span`
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  font-weight: 400;
  line-height: 20px;
`;

// ChargingStationStatusDetail
export const NormalText = styled.div`
  button {
    display: inline-flex;
    margin-left: 8px;
  }
`;

export const Tags = styled.div`
  display: flex;
  flex-wrap: wrap;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => props.theme.color.tagColor};
  line-height: 20px;
  font-weight: 400;
  gap: 2px;

  .tag {
    &::before {
      content: '#';
    }
  }
`;

export const NormalList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 8px;
  .normal-item {
    display: flex;
    column-gap: 12px;
    font-size: ${(props) => props.theme.fontSize3};
    color: ${(props) => props.theme.color.text4};

    span:first-child {
      width: 100px;
    }
  }
`;

export const InfoList = styled.dl`
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 15px;
  line-height: 24px;
  font-weight: 600;
  color: #434343;
  dd {
    margin-right: 12px;
    color: ${(props) => props.theme.color.textSub};
    font-weight: 500;

    &:last-child {
      margin-right: 0;
    }
  }
  & + ${AgGridContainer} {
    margin-top: 24px;
  }
`;

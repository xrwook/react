import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Toggle from 'common/Toggle';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const ToggleGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Toggle-Switch</GuideText>
        <GuideBox>
          <Toggle />
          <Toggle disabled />
          <Toggle defaultChecked />
          <Toggle defaultChecked disabled />
          <Toggle label="Label" />
          <Toggle label="Label" disabled />
          <Toggle label="Label" defaultChecked />
          <Toggle label="Label" defaultChecked disabled />
        </GuideBox>
        <GuideSubBox>
          &lt;Toggle /&gt; <br />
          &lt;Toggle disabled /&gt; <br />
          &lt;Toggle defaultChecked /&gt; <br />
          &lt;Toggle defaultChecked disabled /&gt; <br />
          &lt;Toggle label="" /&gt; <br />
          &lt;Toggle label="" disabled /&gt; <br />
          &lt;Toggle label="" defaultChecked /&gt; <br />
          &lt;Toggle label="" defaultChecked disabled /&gt; <br />
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default ToggleGuide;

import React from 'react';
import styled from 'styled-components';

const ReckoningProgressContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Step = styled.div<{ $background: string }>`
  width: 15px;
  height: 15px;
  margin-left: 5px;
  margin-bottom: 20px;
  background-color: ${(props) => props.$background};
`;

const TextWrapper = styled.div`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: flex-start;
`;

const MinIndexText = styled.span`
  position: absolute;
  left: 0px;
  top: 0;
  color: #000;
  white-space: nowrap;
`;

const MaxIndexText = styled.span`
  position: absolute;
  left: 0;
  top: 0;
  color: #000;
  white-space: nowrap;
`;

const RestIndexText = styled.span`
  position: absolute;
  left: 0;
  top: -45px;
  transform: translateX(-50%);
  color: #1890ff;
  white-space: nowrap;
`;

interface ReckoningProgressProps {
  minPercentage: number;
  maxPercentage: number;
}

const ReckoningProgress: React.FC<ReckoningProgressProps> = ({
  minPercentage,
  maxPercentage,
}) => {
  const total = 20;
  const minIndex = Math.ceil((minPercentage / 100) * total);
  const maxIndex = Math.ceil((maxPercentage / 100) * total);
  const differencePercentage = maxPercentage - minPercentage;

  return (
    <ReckoningProgressContainer>
      {[...Array(total)].map((_, index) => {
        let backgroundColor = '#ddd';

        if (index <= minIndex) {
          backgroundColor = '#1AB46A';
        } else if (index > minIndex && index < maxIndex) {
          backgroundColor = '#1890FF';
        }

        return (
          <React.Fragment key={index}>
            <Step $background={backgroundColor} />
            {index === minIndex - 1 && (
              <TextWrapper>
                <MinIndexText>{minPercentage}%</MinIndexText>
              </TextWrapper>
            )}
            {index === maxIndex - 1 && (
              <TextWrapper>
                <MaxIndexText>{maxPercentage}%</MaxIndexText>
              </TextWrapper>
            )}
            {index === maxIndex - (maxIndex - minIndex) * 0.5 && (
              <TextWrapper>
                <RestIndexText>{differencePercentage}%</RestIndexText>
              </TextWrapper>
            )}
          </React.Fragment>
        );
      })}
    </ReckoningProgressContainer>
  );
};

export default ReckoningProgress;

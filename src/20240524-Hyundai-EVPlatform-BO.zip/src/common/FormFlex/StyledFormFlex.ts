import styled from 'styled-components';
import { FormFlexProps } from './FormFlex';

export const FormFlexWrap = styled.div<FormFlexProps>`
  display: flex;
  align-items: center;
  gap: ${(props) => props.$gap || '8px'};
  width: ${(props) => (props.$width ? `calc(${props.$width})` : '100%')};
  & + & {
    margin-top: 12px;
  }

  & > div {
    flex: 1;
  }
`;

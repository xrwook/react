const GenesisBrandTest = () => {
  return <div>Genesis Brand Page</div>;
};

export default GenesisBrandTest;

import { useState } from 'react';
import Button from 'common/Button';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import Modal from 'common/Modal';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import ModalHeader from 'common/Modal/ModalHeader';
import Icon from 'common/Icon';
import FileSearch from 'common/FileSearch/FileSearch';
import { ButtonGroup } from 'common/Button/StyledButton';
import { GuideBox, GuideText } from '../styled/StyledChargingStations';

const ChargingStationsBulkRegistrationContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);

  return (
    <>
      {showModal && (
        <Modal width="480px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader>일괄 등록</ModalHeader>
          <ModalContent $marginBottom="30px">
            <Grid>
              <GridItem>
                {/* 파일 업로드 기능 작업중 */}
                <Formcontrol title="파일 업로드" required htmlFor="TextField01">
                  <FileSearch dnd />
                </Formcontrol>
              </GridItem>
            </Grid>
            <GuideBox>
              <GuideText style={{ gap: '4px' }}>
                <Icon $widthSize={16} $heightSize={16} $name={'icon-guide'} />
                반드시 양식에 맞는 파일을 업로드 해야합니다.
              </GuideText>
              <GuideText>
                샘플 양식을 다운로드 받아 파일 작성 후 업로드 해주세요.
              </GuideText>
            </GuideBox>
            <ButtonGroup $gap={6} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="small"
                $variant="secondaryGray"
                $width={120}
              >
                공통코드 가이드
              </Button>
              <Button
                onClick={() => {}}
                $size="small"
                $variant="secondaryGray"
                $icon={'icon-download'}
              >
                <Icon $widthSize={20} $heightSize={20} />
                엑셀 다운로드
              </Button>
            </ButtonGroup>
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="secondaryBlue"
                $width={80}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={80}
                disabled
              >
                업로드
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationsBulkRegistrationContainer;

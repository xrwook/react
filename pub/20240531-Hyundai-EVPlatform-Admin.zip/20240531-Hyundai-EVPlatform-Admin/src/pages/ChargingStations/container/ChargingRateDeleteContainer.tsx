import { useState } from 'react';
import Alert from 'common/Alert';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';

const ChargingRateDeleteContainer: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);
  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        충전소 삭제
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertContent>
            <span style={{ fontWeight: '600', color: '#434860' }}>
              개인택시복지 법인 요금제
            </span>
            를 삭제하시겠습니까?
          </AlertContent>
          <AlertFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => setShowAlert(false)}
                $size="large"
                $variant="tertiary"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                삭제
              </Button>
            </ButtonGroup>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargingRateDeleteContainer;

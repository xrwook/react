import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Textarea from 'common/Textarea/Textarea';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TextareaGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Textarea</GuideText>
        <GuideBox>
          <Textarea
            id="textarea01"
            name="text"
            height="100px"
            placeholder="Enter long form text here"
          />
          <Textarea
            id="textarea02"
            name="readOnly"
            height="100px"
            placeholder="Enter long form text here"
            value="readOnly"
            readOnly
          />
          <Textarea
            id="textarea03"
            name="disabled"
            height="100px"
            placeholder="Enter long form text here"
            value="disabled"
            disabled
          />
          <Textarea
            id="textarea04"
            name="error"
            height="100px"
            defaultValue="Enter long form text here"
            $error
            $guideText="Invaild message content"
          />
        </GuideBox>
        <GuideSubBox>
          &lt;Textarea id="" name="" placeholder="" /&gt; <br />
          &lt;Textarea id="" name="" placeholder="" value="" readOnly /&gt;
          <br />
          &lt;Textarea id="" name="" placeholder="" value="" disabled /&gt;
          <br />
          &lt;Textarea id="" name="" placeholder="" value="" $error
          $guideText="" /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TextareaGuide;

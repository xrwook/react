import React, { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import {
  AgGridWrap,
  AgGridContainer,
  AgGridTop,
  Total,
  AgGridTopRight,
} from './StyledAgGrid';
import Pagination from 'common/Pagination/Pagination';
import Button from 'common/Button/Button';
import Dropdown from 'common/Dropdown/Dropdown';

export interface AgGridProps {
  rowData?: any[];
  columnDefs?: any[];
  hasPaging?: boolean;
  hasGridTop?: boolean;
  itemsPerPage?: number;
  defaultNumberButtons?: number;
  listPerPageSelectOption?: any;
  listPerPageDefalutOption?: any;
}

const AgGrid: React.FC<AgGridProps> = ({
  rowData,
  columnDefs,
  hasPaging,
  hasGridTop,
  listPerPageSelectOption,
  listPerPageDefalutOption,
}) => {
  const [gridApi, setGridApi] = useState(null);
  const [rowCount, setRowCount] = useState(null);
  const [selectedOption, setSelectedOption] = useState(20);

  const defaultColDef = { sortable: false, resizable: true, flex: 1 };
  const onGridReady = (params: any) => {
    setGridApi(params.api);
    setRowCount(params.api.getDisplayedRowCount());
    params.api.sizeColumnsToFit();
  };
  const handleClick = (prop: any) => {
    const stringValue: string = prop;
    const changeNumberValue: number = parseInt(stringValue, 10);
    setSelectedOption(changeNumberValue);
  };

  return (
    <AgGridContainer>
      {hasGridTop && (
        <AgGridTop>
          <Total>
            Total<strong>{rowCount}</strong>
          </Total>
          <AgGridTopRight>
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryGray"
              download
              $icon
            >
              엑셀 다운로드
            </Button>
            <Dropdown
              options={listPerPageSelectOption}
              defaultOption={listPerPageDefalutOption}
              onClick={handleClick}
            />
          </AgGridTopRight>
        </AgGridTop>
      )}
      <AgGridWrap className="ag-theme-alpine">
        <AgGridReact
          columnDefs={columnDefs}
          rowData={rowData}
          rowSelection="multiple"
          reactiveCustomComponents
          onGridReady={onGridReady}
          defaultColDef={defaultColDef}
          pagination={true}
          paginationPageSize={selectedOption}
          suppressPaginationPanel={true}
        />
      </AgGridWrap>
      {hasPaging && <Pagination gridApi={gridApi} />}
    </AgGridContainer>
  );
};

export default AgGrid;

import { TabRadioWrapper } from './StyledTabRadio';

export interface TabRadioProps {
  children?: any;
}

const TabRadio: React.FC<TabRadioProps> = ({ children }) => {
  return <TabRadioWrapper>{children}</TabRadioWrapper>;
};

export default TabRadio;

import styled from 'styled-components';
import { FormcontrolItemProps } from './FormcontrolItem';

export const FormItemWrap = styled.div<FormcontrolItemProps>`
  display: flex;
  align-items: ${(props) => (props.$center ? 'center' : 'flex-start')};
  gap: ${(props) => (props.$small ? '8px' : props.$none ? '0' : '10px')};
`;

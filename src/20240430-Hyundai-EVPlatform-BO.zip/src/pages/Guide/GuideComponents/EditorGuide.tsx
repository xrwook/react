import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Editor from 'common/Editor';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const EditorGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Editor</GuideText>
        <GuideBox>
          <Editor height="auto" />
        </GuideBox>
        <GuideSubBox>&lt;Editor height="auto"" /&gt;</GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default EditorGuide;

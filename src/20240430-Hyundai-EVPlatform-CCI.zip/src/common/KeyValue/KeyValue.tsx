import React from 'react';
import styled from 'styled-components';

const KeyValueWrapper = styled.div`
  display: block;
`;

const KeyValueList = styled.dl`
  margin: 0;
  padding: 0;
`;

const KeyValueItem = styled.div`
  display: flex;
  align-items: flex-start;
  font-size: 0.9375rem;
  color: #000;
  line-height: 1.125rem;
  padding: 10px;
`;

const KeyValueKey = styled.dt`
  flex: none;
  margin-right: 8px;
`;

const KeyValueValue = styled.dd`
  flex: 1;
  min-width: 0;
  text-align: right;
  margin: 0;
`;

interface KeyValueProps {
  items: { label: string; value: string }[];
}

const KeyValue: React.FC<KeyValueProps> = ({ items }) => {
  return (
    <KeyValueWrapper>
      <KeyValueList>
        {items.map((item, index) => (
          <KeyValueItem key={index}>
            <KeyValueKey>{item.label}</KeyValueKey>
            <KeyValueValue>{item.value}</KeyValueValue>
          </KeyValueItem>
        ))}
      </KeyValueList>
    </KeyValueWrapper>
  );
};

export default KeyValue;

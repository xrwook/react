import React from 'react';

const PublishingList: React.FC = () => {
  return (
    <>
      <div></div>
    </>
  );
};

export default PublishingList;

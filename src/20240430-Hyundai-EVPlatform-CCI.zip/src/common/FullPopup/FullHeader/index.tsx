export { default } from './FullHeader';

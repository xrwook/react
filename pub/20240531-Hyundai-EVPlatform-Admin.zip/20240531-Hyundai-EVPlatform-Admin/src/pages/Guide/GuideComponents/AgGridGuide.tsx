import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import AgGrid from 'common/AgGrid/AgGrid';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const AgGridGuide = () => {
  const columnDefs = [
    {
      headerName: 'No',
      field: 'id',
      width: 88,
      editable: true,
    },
    { headerName: 'Name', field: 'name', width: 150 },
    {
      headerName: 'SubName',
      field: 'name',
      width: 150,
    },
    { headerName: 'Job', field: 'name', width: 306, unSortIcon: true },
  ];

  const rowData = [
    {
      id: 1,
      name: 'John',
    },
    {
      id: 2,
      name: 'Alice',
    },
    {
      id: 3,
      name: 'Park',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>AgGird</GuideText>
        <GuideBox>
          <AgGrid rowData={rowData} columnDefs={columnDefs} />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125;
        </GuideSubBox>
        <GuideBox>
          <AgGrid rowData={rowData} columnDefs={columnDefs} hasPaging={true} />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125; hasPaging=&#123;true&#125; /&gt;
        </GuideSubBox>
        <GuideBox>
          <AgGrid rowData={rowData} columnDefs={columnDefs} hasDate={true} />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125; hasGridTop=&#123;true&#125;
          hasDate=&#123;true&#125; /&gt;
        </GuideSubBox>
        <GuideBox>
          <AgGrid
            rowData={rowData}
            columnDefs={columnDefs}
            hasGridTop={true}
            hasCheckbox={true}
          />
        </GuideBox>
        <GuideSubBox>
          &lt;AgGrid rowData=&#123;rowData&#125;
          columnDefs=&#123;columnDefs&#125; hasCheckbox=&#123;true&#125; /&gt;
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>rowData</td>
              <td>{`rowData={rowData}`}</td>
              <td>cell data</td>
              <td>[]</td>
            </tr>
            <tr>
              <td>columnDefs</td>
              <td>{`columnDefs={columnDefs}`}</td>
              <td>header data</td>
              <td>[]</td>
            </tr>
            <tr>
              <td>hasGrid</td>
              <td>{`hasGridTop={true}`}</td>
              <td>hasGridTop(총, 선택, 버튼, 드롭다운) 유무</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>hasPaging</td>
              <td>{`hasPaging={true}`}</td>
              <td>pagination 유무</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>hasDate</td>
              <td>{`hasDate={true}`}</td>
              <td>개월 드랍박스 유무</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>hasCheckbox</td>
              <td>{`hasCheckbox={true}`}</td>
              <td>체크박스 유무</td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default AgGridGuide;

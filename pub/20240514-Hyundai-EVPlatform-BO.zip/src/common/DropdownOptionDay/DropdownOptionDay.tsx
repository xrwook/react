import { useState } from 'react';
import {
  OptionWrapper,
  OptionHeader,
  OptionHeaderTitle,
  OptionLayout,
  OptionFooter,
} from './StyledDropdownOptionDay';
import Select from 'common/Select';
import TabRadio from 'common/TabRadio';
import TabRadioItem from 'common/TabRadio/TabRadioItem';
import DatePicker from 'common/Datepicker/Datepicker';
import Button from 'common/Button';

export interface DropdownOptionDayProps {
  $day?: any;
  className?: any;
}

const optionDay = [
  {
    value: '등록일',
    label: '등록일',
  },
  {
    value: '최종 수정일',
    label: '최종 수정일',
  },
];

const DropdownOptionDay: React.FC<DropdownOptionDayProps> = ({ $day }) => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());
  return (
    <OptionWrapper $day={$day}>
      <OptionHeader>
        <OptionHeaderTitle>기간</OptionHeaderTitle>
        <Select
          placeholder="등록일"
          options={optionDay}
          classNamePrefix="react-select"
          className="filter"
        />
      </OptionHeader>
      <TabRadio>
        <TabRadioItem
          id="radio01"
          name="radio01"
          htmlFor="radio01"
          text="1주일"
          $borderfirst
          defaultChecked
        />
        <TabRadioItem
          id="radio02"
          name="radio01"
          htmlFor="radio02"
          text="1개월"
        />
        <TabRadioItem
          id="radio03"
          name="radio01"
          htmlFor="radio03"
          text="3개월"
        />
        <TabRadioItem
          id="radio04"
          name="radio01"
          htmlFor="radio04"
          text="직접입력"
          $borderlast
        />
      </TabRadio>
      <OptionLayout>
        <DatePicker
          selected={startDate}
          onChange={(date) => setStartDate(date)}
          selectsStart
          startDate={startDate}
          endDate={endDate}
          dateFormat="yyyy/MM/dd"
        />
        <div className="divider"></div>
        <DatePicker
          selected={endDate}
          onChange={(date) => setEndDate(date)}
          selectsEnd
          startDate={startDate}
          endDate={endDate}
          minDate={startDate}
          dateFormat="yyyy/MM/dd"
        />
      </OptionLayout>
      <OptionFooter>
        <Button onClick={() => {}} $size="small" $variant="transparent">
          초기화
        </Button>
        <Button onClick={() => {}} $size="small" $variant="transparentPurple">
          적용
        </Button>
      </OptionFooter>
    </OptionWrapper>
  );
};

export default DropdownOptionDay;

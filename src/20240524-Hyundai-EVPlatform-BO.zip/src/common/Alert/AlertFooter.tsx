import { AlertFooterWrapper } from './StyledAlert';

export interface AlertFooterProps {
  children?: any;
}

const AlertFooter: React.FC<AlertFooterProps> = ({ children }) => {
  return (
    <>
      <AlertFooterWrapper>{children}</AlertFooterWrapper>
    </>
  );
};

export default AlertFooter;

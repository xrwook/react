import ChargingStationsConnectTypeRender from './ChargingStationsConnectTypeRender';
import ChargingStationsButtonRender from './ChargingStationsButtonRender';
import ChargingStationsLabelRender from './ChargingStationsLabelRender';
import ChargingStationsFormRender from './ChargingStationsFormRender';
import { ButtonGroup } from 'common/Button/StyledButton';

export const chargerHoldingColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 240,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 222,
  },
  {
    headerName: '커넥터 타입',
    field: 'field4',
    minWidth: 200,
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: '대기 차량',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '예상 대기 시간 (분)',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기표 번호',
    field: 'field7',
  },
  {
    headerName: '대기 상세',
    field: 'field8',
  },
  {
    headerName: '-',
    field: 'field9',
    minWidth: 132,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const chargerHoldingRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Type2',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CHAdeMO',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Combo',
    field5: '1',
    field6: '5 minutes',
    field7: '#0001',
    field8: '-',
    field9: '강제취소',
  },
];

export const holdingListColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 200,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 200,
  },
  {
    headerName: '커넥터 타입',
    field: 'field4',
    minWidth: 200,
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: '대기자 회원 코드',
    field: 'field5',
    minWidth: 160,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '차량 종류',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기표 발급 시간',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '배차 완료 시간',
    field: 'field8',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '대기 시간',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const holdingListRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: 'CCS Type2',
    field5: '123123123',
    field6: '아이오닉6',
    field7: '2024-04-23 12:13',
    field8: '2024-04-23 12:13',
    field9: '30분',
  },
];

export const dailyUsageColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전기 이름',
    field: 'field2',
    minWidth: 200,
  },
  {
    headerName: '충전 속도',
    field: 'field3',
    minWidth: 200,
  },
  {
    headerName: '충전시작/완료 시간',
    field: 'field4',
    minWidth: 280,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전시간',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전량',
    field: 'field6',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '충전 금액',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 그룹',
    field: 'field8',
    minWidth: 132,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 코드',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '차량 종류',
    field: 'field10',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const dailyUsageRowData = [
  {
    field1: '-',
    field2: 'ABCDEFGHIJKLMNOPQRST',
    field3: 'Super Fast (Max.150 kW)',
    field4: '2024-04-23 12:13 - 2024-04-23 12:13',
    field5: '00분 00초',
    field6: '123 kWh',
    field7: '10,000 원',
    field8: '프라임',
    field9: '123123123',
    field10: '아이오닉6',
  },
];

export const reviewInfoColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  // {
  //   headerName: '상태',
  //   field: 'field2',
  //   minWidth: 120,
  //   headerClass: 'custom-align-center',
  //   cellStyle: { textAlign: 'center' },
  //   cellRenderer: (props: any) => {
  //     return <ChargingStationsLabelRender status={props.value} />;
  //   },
  // },
  {
    headerName: '작성일',
    field: 'field2',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '리뷰 유형',
    field: 'field3',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원그룹',
    field: 'field4',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '회원 코드',
    field: 'field5',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '리뷰 내용',
    field: 'field6',
  },
  {
    headerName: '평점',
    field: 'field7',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '등록일',
    field: 'field8',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '담당자',
    field: 'field9',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '-',
    field: 'field10',
    minWidth: 92,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const reviewInfoRowData = [
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '일반',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: '삭제',
  },
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '이미지',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: 'Delete',
  },
  {
    field1: '-',
    field2: '2024-04-23 12:13',
    field3: '이미지',
    field4: '프라임',
    field5: '123123123',
    field6:
      '리뷰 내용을 표시합니다 리뷰 내용을 표시합니다 리뷰 내용을 표시합니다',
    field7: '10.0',
    field8: '2024-04-23 12:13',
    field9: '김현대 매니저',
    field10: '삭제',
  },
];

export const chargingStationsDetailOption = [
  {
    value: '5',
    label: '5개씩보기',
  },
  {
    value: '10',
    label: '10개씩보기',
  },
  {
    value: '15',
    label: '15개씩보기',
  },
  {
    value: '20',
    label: '20개씩보기',
  },
];

export const chargerRegistrationColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: 'EVSE',
    field: 'field2',
    minWidth: 240,
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    sortable: true,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
        />
      );
    },
  },
  {
    headerName: '위치',
    field: 'field4',
    minWidth: 110,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: () => {
      return (
        <ChargingStationsFormRender
          selectOption={[
            { value: '1', label: '오른쪽' },
            { value: '2', label: '왼쪽' },
          ]}
        />
      );
    },
  },
  {
    headerName: '환경부 ID',
    field: 'field5',
    minWidth: 212,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
          buttonName={'중복 확인'}
        />
      );
    },
  },
  {
    headerName: '커넥터 타입',
    field: 'field6',
    minWidth: 168,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field7',
    minWidth: 80,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const chargerRegistrationRowData = [
  {
    field1: '-', //input
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01', //input
    field4: '오른쪽', //select
    field5: '', //input
    field6: 'CCS Type2',
    field7: '보기',
  },
];

export const ChargingStationsChargerEditColumnDefs = [
  {
    headerName: 'EVSE',
    field: 'field1',
    minWidth: 240,
  },
  {
    headerName: '번호',
    field: 'field2',
    maxWidth: 80,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    sortable: true,
    cellRenderer: (props: any) => {
      return <ChargingStationsFormRender textFieldValue={props.value} />;
    },
  },
  {
    headerName: '위치',
    field: 'field4',
    minWidth: 110,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: () => {
      return (
        <ChargingStationsFormRender
          selectOption={[
            { value: '1', label: '오른쪽' },
            { value: '2', label: '왼쪽' },
          ]}
        />
      );
    },
  },
  {
    headerName: '환경부 ID',
    field: 'field5',
    minWidth: 240,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'123123123'}
          buttonName={'중복 확인'}
        />
      );
    },
  },
  {
    headerName: '커넥터 타입',
    field: 'field6',
    minWidth: 148,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field7',
    minWidth: 80,
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargingStationsChargerEditRowData = [
  {
    field1: 'Evse 1 [KREPTE000215000101]',
    field2: '-', //input
    field3: 'Connetor 01', //input
    field4: '오른쪽', //select
    field5: '', //input
    field6: 'CCS Type2',
    field7: '보기',
  },
];

export const ChargingStationsChargerInfoColumnDefs = [
  {
    headerName: '번호',
    field: 'field1',
    maxWidth: 60,
    valueGetter: (params: any) => {
      return params.api.getDisplayedRowCount() - params.node.rowIndex;
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: 'EVSE',
    field: 'field2',
    minWidth: 220,
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 140,
    cellStyle: { textAlign: 'center' },
    sortable: true,
  },
  {
    headerName: '충전기 상태',
    field: 'field4',
    minWidth: 90,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '통신 상태',
    field: 'field5',
    minWidth: 90,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '환경부 ID',
    field: 'field6',
    minWidth: 120,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '커넥터 타입',
    field: 'field7',
    minWidth: 140,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return <ChargingStationsConnectTypeRender connetType={props.value} />;
    },
  },
  {
    headerName: 'QR 코드',
    field: 'field8',
    minWidth: 179,
    cellRenderer: () => {
      return (
        <div style={{ padding: '9px 0' }}>
          <ButtonGroup $gap={8}>
            <ChargingStationsButtonRender
              buttonName="보기"
              buttonType="tertiary"
            />
            <ChargingStationsButtonRender
              buttonName="재전송"
              buttonType="tertiary"
            />
            <ChargingStationsButtonRender
              buttonName="이력확인"
              buttonType="tertiary"
            />
          </ButtonGroup>
        </div>
      );
    },
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargingStationsChargerInfoRowData = [
  {
    field1: '-',
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01 (R)',
    field4: '미연결',
    field5: '미연결',
    field6: 'HD_191005_01',
    field7: 'CCS Type2',
    field8: '-',
  },
  {
    field1: '-',
    field2: 'Evse 1 [KREPTE000215000101]',
    field3: 'Connetor 01 (L)',
    field4: '미연결',
    field5: '미연결',
    field6: 'HD_191005_01',
    field7: 'CCS Type2',
    field8: '-',
  },
];

export const ChargingRateListcolumnDefs = [
  {
    headerName: '요금제 이름',
    field: 'field1',
    minWidth: 200,
  },
  {
    headerName: '요금제 설명',
    field: 'field2',
    sortable: true,
    minWidth: 272,
  },
  {
    headerName: '상태',
    field: 'field3',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    minWidth: 124,
    cellRenderer: (props: any) => {
      return <ChargingStationsLabelRender status={props.value} />;
    },
  },
  {
    headerName: '적용요금',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    minWidth: 128,
  },
  {
    headerName: '적용기간',
    field: 'field5',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    minWidth: 280,
  },
  {
    headerName: '적용 충전소',
    field: 'field6',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    minWidth: 100,
  },
  {
    headerName: '등록일시',
    field: 'field7',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    sortable: true,
    minWidth: 200,
  },
  {
    headerName: '최근수정일시',
    field: 'field8',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    sortable: true,
    minWidth: 200,
  },
];

export const ChargingRateListRowData = [
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용중',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료 ',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료 ',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료 ',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료 ',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
  {
    field1: '24년 유선충전 요금제',
    field2: '24년 개인택시복지 법인 요금제',
    field3: '적용종료 ',
    field4: '지정요금',
    field5: 'YYYY-MM-DD ~ YYYY-MM-DD',
    field6: '10',
    field7: 'YYYY-MM-DD HH:MM:SS',
    field8: 'YYYY-MM-DD HH:MM:SS',
  },
];

export const ChargingRateDetailcolumnDefs = [
  {
    headerName: '충전소 이름',
    field: 'field1',
  },
  {
    headerName: '권역',
    field: 'field2',
    maxWidth: 149,
  },
  {
    headerName: '충전소 주소',
    field: 'field3',
  },
  {
    headerName: '충전소 유형',
    field: 'field4',
    maxWidth: 149,
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
  },
  {
    headerName: '충전 시설 유형',
    field: 'field5',
    maxWidth: 149,
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
  },
  {
    headerName: '시설 구분',
    field: 'field6',
    maxWidth: 149,
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
  },
  {
    headerName: '운영 시작일',
    field: 'field7',
    maxWidth: 149,
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
  },
];

export const ChargingRateDetailRowData = [
  {
    field1: '현대41타워 충전소',
    field2: '서울특별시',
    field3: '서울특별시 양천구 목동서로 123-1',
    field4: '모든 사용자용',
    field5: '공공시설',
    field6: '도청',
    field7: '2023-11-10',
  },
  {
    field1: '현대41타워 충전소',
    field2: '서울특별시',
    field3: '서울특별시 양천구 목동서로 123-1',
    field4: '모든 사용자용',
    field5: '공공시설',
    field6: '도청',
    field7: '2023-11-10',
  },
  {
    field1: '현대41타워 충전소',
    field2: '서울특별시',
    field3: '서울특별시 양천구 목동서로 123-1',
    field4: '모든 사용자용',
    field5: '공공시설',
    field6: '도청',
    field7: '2023-11-10',
  },
];

export const ChargingRateDetailFarecolumnDefs = [
  {
    headerName: '회원등급',
    field: 'field1',
    maxWidth: 161,
  },
  {
    headerName: '콘텐트',
    field: 'field2',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
          readOnly
        />
      );
    },
  },
  {
    headerName: '완속',
    field: 'field3',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
          readOnly
        />
      );
    },
  },
  {
    headerName: '중속',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
          readOnly
        />
      );
    },
  },
  {
    headerName: '급속',
    field: 'field5',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
          readOnly
        />
      );
    },
  },
  {
    headerName: '초급속',
    field: 'field6',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
          readOnly
        />
      );
    },
  },
];

export const ChargingRateDetailFareRowData = [
  {
    field1: '회원등급 1',
    field2: '100',
    field3: '100',
    field4: '150',
    field5: '200',
    field6: '300',
  },
  {
    field1: '회원등급 2',
    field2: '100',
    field3: '100',
    field4: '150',
    field5: '200',
    field6: '300',
  },
  {
    field1: '비회원',
    field2: '100',
    field3: '100',
    field4: '150',
    field5: '200',
    field6: '300',
  },
];

export const ChargingRateDetailFarePopupcolumnDefs = [
  {
    headerName: '복사 항목 선택',
    checkboxSelection: true,
    headerCheckboxSelection: true,
    width: 52,
    field: 'field1',
  },
];

export const ChargingRateDetailFarePopupRowData = [
  {
    field1: '전체',
  },
  {
    field1: '적용 기간',
  },
  {
    field1: '요금 설정',
  },
  {
    field1: '미출차 과금설정',
  },
  {
    field1: '비회원 미출차 보증금',
  },
  {
    field1: '공공기관 등록용 요금정보',
  },
  {
    field1: '적용 충전소',
  },
];

export const ChargingRateRegistrationPopupcolumnDefs = [
  {
    headerName: '충전소 이름',
    maxWidth: 280,
    field: 'field1',
    sortable: true,
  },
  {
    headerName: '권역',
    maxWidth: 240,
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    field: 'field2',
  },
  {
    headerName: '충전소 주소 (권역)',
    maxWidth: 400,
    field: 'field3',
  },
  {
    headerName: '운영상태',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    maxWidth: 164,
  },
];

export const ChargingRateRegistrationPopupRowData = [
  {
    field1: 'HD Charging Station',
    field2: 'CA',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: '이마트 세종점 HD충전소',
    field2: '세종특별자치시',
    field3: '세종특별자치시 금송로 687',
    field4: '운영중',
  },
  {
    field1: 'HD Charging Station',
    field2: '세종특별자치시',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: '코스트코 양평점 HD충전소',
    field2: 'CA',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: '이마트 세종점 HD충전소',
    field2: '세종특별자치시',
    field3: '세종특별자치시 금송로 687',
    field4: '운영중',
  },
  {
    field1: 'HD Charging Station',
    field2: '서울특별시',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: '코스트코 양평점 HD충전소',
    field2: 'CA',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: 'HD Charging Station',
    field2: '서울특별시',
    field3: '3600 S La Brea Ave, Los Angeles, CA 90016',
    field4: '운영중',
  },
  {
    field1: '코스트코 양평점 HD충전소',
    field2: '서울특별시',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
  {
    field1: 'HD Charging Station',
    field2: 'CA',
    field3: '6101 W Manchester Ave, Los Angeles, CA48101',
    field4: '운영중',
  },
];

export const ChargingRateRegistrationcolumnDefs = [
  {
    headerName: '회원등급',
    field: 'field1',
    maxWidth: 161,
  },
  {
    headerName: '콘텐트',
    field: 'field2',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
        />
      );
    },
  },
  {
    headerName: '완속',
    field: 'field3',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
        />
      );
    },
  },
  {
    headerName: '중속',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
        />
      );
    },
  },
  {
    headerName: '급속',
    field: 'field5',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
        />
      );
    },
  },
  {
    headerName: '초급속',
    field: 'field6',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'100'}
          $innerRight="원"
        />
      );
    },
  },
];

export const ChargerIssuesRegistrationcolumnDefs = [
  {
    headerName: '담당자 구분',
    field: 'field1',
    minWidth: 346,
    cellRenderer: () => {
      return (
        <ChargingStationsFormRender
          placeholder="담당자 유형 선택"
          selectOption={[
            { value: '유지보수 담당자', label: '유지보수 담당자' },
          ]}
        />
      );
    },
  },
  {
    headerName: '휴대폰 번호',
    field: 'field2',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'휴대폰 번호 ‘-’ 없이 입력'}
        />
      );
    },
    minWidth: 346,
  },
  {
    headerName: '매니저명',
    field: 'field3',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'담당자 이름 입력'}
        />
      );
    },
    minWidth: 346,
  },
  {
    headerName: '소속',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsFormRender
          textFieldValue={props.value}
          placeholder={'담당자 소속 입력'}
        />
      );
    },
    minWidth: 346,
  },
  {
    headerName: '삭제',
    field: 'field5',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsButtonRender
          buttonName={props.value}
          buttonType="tertiary"
        />
      );
    },
    maxWidth: 160,
  },
];

export const ChargerIssuesRegistrationrowData = [
  {
    field1: '',
    field2: '',
    field3: '',
    field4: '',
    field5: '삭제',
  },
];

export const ChargerIssuesEditColumnDefs = [
  {
    headerName: 'EVSE',
    field: 'field1',
    maxWidth: 312,
  },
  {
    headerName: '충전기 번호',
    field: 'field2',
    minWidth: 120,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '커넥터 이름',
    field: 'field3',
    minWidth: 314,
    sortable: true,
  },
  {
    headerName: '충전기 상태',
    field: 'field4',
    minWidth: 160,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '통신 상태',
    field: 'field5',
    minWidth: 160,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '커넥터 타입',
    field: 'field6',
    minWidth: 240,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
    cellRenderer: (props: any) => {
      return (
        <ChargingStationsConnectTypeRender connetType={props.value} $center />
      );
    },
  },
  {
    headerName: '환경부 ID',
    field: 'field7',
    minWidth: 240,
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargerIssuesEditRowData = [
  {
    field1: 'Evse 1 [KREPTE000215000101]',
    field2: '01',
    field3: 'Connetor 01 (R)',
    field4: '미연결',
    field5: '미연결',
    field6: 'CCS Type2',
    field7: 'HD_191005_01',
  },
];

export const ChargerIssuesDetailColumnDefs = [
  {
    headerName: '담당자 구분',
    field: 'field1',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '휴대폰 번호',
    field: 'field2',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '매니저명',
    field: 'field3',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
  {
    headerName: '소속',
    field: 'field4',
    headerClass: 'custom-align-center',
    cellStyle: { textAlign: 'center' },
  },
];

export const ChargerIssuesDetailRowData = [
  {
    field1: '유지보수 담당자',
    field2: '01000000000',
    field3: '담당자 이름',
    field4: '담당자 소속',
  },
];

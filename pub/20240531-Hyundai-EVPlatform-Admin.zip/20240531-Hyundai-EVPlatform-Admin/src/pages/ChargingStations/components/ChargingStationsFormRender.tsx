import Button from 'common/Button/Button';
import TextField from 'common/TextField/TextField';
import Select, { Option } from 'common/Select/Select';

import {
  RenderCommonWrap,
  RenderGroup,
} from '../styled/StyledChargingStations';

export interface ChargingStationsFormRenderProps {
  textFieldValue?: any;
  buttonName?: string;
  placeholder?: string;
  textFieldReadOnly?: boolean;
  selectOption?: any;
  options?: Option;
  $innerRight?: any;
  readOnly?: any;
}

const ChargingStationsFormRender: React.FC<ChargingStationsFormRenderProps> = ({
  textFieldValue,
  placeholder,
  buttonName,
  selectOption,
  $innerRight,
  readOnly,
}) => {
  return (
    <RenderCommonWrap>
      <RenderGroup>
        {selectOption && (
          <Select
            $height={'28'}
            options={selectOption}
            defaultValue={selectOption[0]}
            classNamePrefix="react-select"
            menuPortalTarget={document.body}
          />
        )}
        {textFieldValue !== undefined && (
          <TextField
            $height={'28'}
            placeholder={placeholder}
            value={textFieldValue}
            $innerRight={$innerRight}
            readOnly={readOnly}
          />
        )}
        {buttonName && (
          <Button $size="mini" $variant="tertiary" onClick={() => {}}>
            {buttonName}
          </Button>
        )}
      </RenderGroup>
    </RenderCommonWrap>
  );
};

export default ChargingStationsFormRender;

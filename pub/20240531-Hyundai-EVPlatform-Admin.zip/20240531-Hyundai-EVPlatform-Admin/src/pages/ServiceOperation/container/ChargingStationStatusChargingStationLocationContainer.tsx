import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import { Map, LocationSubText } from '../styled/StyledServiceOperation';

const ChargingStationStatusChargingStationLocationContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  return (
    <>
      {showModal && (
        <Modal width="800px" height="auto" onClose={() => setShowModal(false)}>
          <ModalHeader>충전소 위치</ModalHeader>

          <ModalContent $marginBottom="12px">
            <LocationSubText>
              충전소 이름 (Charging Station Address, CA, 90001 (위도/경도 정보)
              )
            </LocationSubText>
            {/* 지도 영역 */}
            <Map></Map>
            {/* // */}
          </ModalContent>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationStatusChargingStationLocationContainer;

import { createGlobalStyle } from 'styled-components';
import '../fonts/pretendard/style.css';
import timeIcon from '/images/icons/icon-time.svg';
import checkIcon from '/images/icons/icon-check.svg';
import previousIcon from '/images/icons/icon-previous.svg';
import nextIcon from '/images/icons/icon-next.svg';

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after {
    box-sizing: border-box;
  }

  html, body {
    font-size: 16px;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
    font-weight: 400;
    -webkit-text-size-adjust: none;
    text-size-adjust: none;
    word-break: break-all;
    -webkit-overflow-scrolling: touch
  }
  html, body, div, span, applet, object, iframe,
  h1, h2, h3, h4, h5, h6, p, blockquote, pre,
  a, abbr, acronym, address, big, cite, code,
  del, dfn, em, img, ins, kbd, q, s, samp,
  small, strike, strong, sub, sup, tt, var,
  b, u, i, center,
  dl, dt, dd, ol, ul, li,
  fieldset, form, label, legend,
  table, caption, tbody, tfoot, thead, tr, th, td,
  article, aside, canvas, details, embed, 
  figure, figcaption, footer, header, hgroup, 
  menu, nav, output, ruby, section, summary,
  time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font: inherit;
    vertical-align: baseline;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
  }
  ol, ul {
    list-style: none;
  }
  blockquote, q {
    quotes: none;
  }
  blockquote:before, blockquote:after,
  q:before, q:after {
    content: '';
    content: none;
  }
  table {
    border-collapse: collapse;
    border-spacing: 0;
  }
  a {
    color: inherit;
    text-decoration: none
  }
  button, input, select, table, textarea {
    font-size: inherit;
    color: inherit;
    font-family: inherit;
    font-weight: inherit
  }
  h1, h2, h3, h4, h5, h6, strong {
    font-size: inherit;
    line-height: inherit;
    font-weight: inherit
  }
  textarea {
    border: 0;
    word-break: keep-all;
    word-wrap: break-word
  }
  button, label, a {
    cursor: pointer;
    &:disabled {
      cursor: default;
    }
  }
  button, input {
    border-radius: 0;
    border: 0;
    background-color: unset
  }
  input, select, textarea, button {
    outline: none;
  }
  /* scrollbar custom */

  /* 스크롤바 */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  /* 스크롤바 막대 */
  ::-webkit-scrollbar-thumb {
    background: #caccd7;
    border-radius: 12px 12px 12px 12px;
  }

  /* 스크롤바 트랙 */
  ::-webkit-scrollbar-track {
  }

  
  /* time-datepicker */
  .time .react-datepicker__input-container::after {
    background-image: url(${timeIcon}) !important;
  }

  /* common */
  .blind-text {
    overflow: hidden;
    position: absolute;
    clip: rect(0, 0, 0, 0);
    clip-path: polygon(0 0, 0 0, 0 0);
    width: 1px;
    height: 1px;
    margin: -1px;
  }
  
  /* ag-grid */

  .ag-tooltip-custom {
    display: none;
  }

  .ag-tooltip-custom.active {
    display: block;
  }

  .ag-root-wrapper {
    border: unset;
    border-radius: 0;
    overflow: visible;

    .custom-align-center .ag-header-cell-label {
      justify-content: center;
    }
  }
  .ag-paging-panel {
    border-top: 0;
  }
  .ag-paging-page-size {
    display: none;
  }
  .ag-paging-row-summary-panel {
    display: none;
  }
  .ag-header, .ag-advanced-filter-header {
    height: 44px !important;
    min-height: 44px !important;
    background-color: #F5F6FA;
    border-top: 1px solid #C2C5D2;
    border-bottom: 1px solid #C2C5D2;
  }
  .ag-header:hover {
    background-color: #E7E9F1;
  }
  .ag-header-container {
    width: 100%;
  }
  .ag-header.ag-header-allow-overflow .ag-header-row {
    width: 100% !important;
  }
  .ag-header-cell {
    .ag-sort-indicator-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
    }
    &.ag-header-cell-sortable {
      .ag-sort-order {
        display: block !important;
        font-size: 0;
        &::after {
          content: '';
          display: inline-block;
          width: 16px;
          height: 16px;
          background: url('/images/icons/icon-table-sort-default.svg') no-repeat center right / 12px 16px; 
        }
      }
    }
    .ag-icon-asc {
      &::before {
        display: none;
      }
      &::after {
        background: url('/images/icons/icon-table-sort-asc.svg') no-repeat center right / 12px 16px; 
      }
    }
    .ag-icon-desc {
      &::before {
        display: none;
      }
      &::after {
        background: url('/images/icons/icon-table-sort-desc.svg') no-repeat center right / 12px 16px; 
      }
    }
  }
  .ag-header-cell-resize {
    display: none;
  }
  
  .ag-header-cell, .ag-header-group-cell {
    height: 44px !important;
    padding: 0 14px !important;
  }
  
  .ag-header-cell-label{ 
    align-items: center;
    justify-content: flex-start;
  }
  .ag-header-cell-text {
    font-size: 13px;
    line-height: 16px;
    font-weight: 600;
    color: #212430;
  }
  .ag-center-cols-container {
    width: 100% !important;
  }
  .ag-cell {
    text-align: left;
    padding: 0 14px;
  }
  .ag-row {
    height: 44px;
    border-bottom: 1px solid #F0F1F4;
  }
  .ag-row-odd {
    background-color: #ffffff;
  }
  .ag-checkbox-input-wrapper {
    width: 18px;
    height: 18px;
    border-radius: 2px;
  }
  .ag-checkbox-input-wrapper input, .ag-checkbox-input-wrapper input {
    width: 18px;
    height: 18px;
  }
  .ag-checkbox-input-wrapper::after {
    content: '';
    width: 18px;
    height: 18px;
    border-radius: 2px;
    border: 1px solid #CDCDCD;
  }
  .ag-checkbox-input-wrapper.ag-checked::before{
    border: none;
    background-image: url(${checkIcon}) !important;
    background-size: cover !important;
    width: 18px !important;
  }
  .ag-checkbox-input-wrapper.ag-checked::after {
    content: none;
  }
  .ag-checkbox-input-wrapper.ag-indeterminate::before {
    background-image: none;
  }
  .ag-checkbox-input-wrapper.ag-indeterminate::after {
    content: '';
  }
  .ag-checkbox-input-wrapper:focus-within, .ag-checkbox-input-wrapper:active {
    box-shadow: unset;
  }
  .ag-row-selected::before {
    background-color: transparent;
  }
  .ag-row-hover.ag-row-selected::before {
    background-color: transparent !important;
    background-image: none;
  }
  .ag-row-hover, .ag-row-hover:not(.ag-full-width-row)::before {
    background-color: #F5F7FF;
  }
  .ag-cell-inline-editing  {
    border: 1px solid;
  }
  .ag-body {
    min-height: auto;
    flex: 0;
  }
  .ag-root-wrapper-body.ag-layout-normal {
    height: auto;
  }
  .ag-has-focus .ag-cell-focus {
    border-color: transparent !important;
  }

  /* datePicker */
  .flatpickr-calendar {
    border: 1px solid #C2C5D2 !important;
    border-radius: 4px !important;
    width: 334px;
    padding: 30px 30px 0px 30px !important;
    box-shadow: unset !important;
  }

  .flatpickr-calendar:before, .flatpickr-calendar:after {
    content: unset !important;
  }
  .flatpickr-months .flatpickr-prev-month, .flatpickr-months .flatpickr-next-month {
    top: 32px;
    height: 20px;
  }
  .flatpickr-months .flatpickr-prev-month svg, .flatpickr-months .flatpickr-next-month svg {
    display: none;
  }
  .flatpickr-months .flatpickr-prev-month.flatpickr-prev-month {
    left: 30px;
    width: 20px;
    height: 20px;
    background: url(${previousIcon}) no-repeat;
  }
  .flatpickr-months .flatpickr-next-month.flatpickr-next-month {
    right: 30px;
    width: 20px;
    height: 20px;
    background: url(${nextIcon}) no-repeat;
  }
  .flatpickr-months .flatpickr-month {
    height: 24px;
    color: #2D3145;
  }
  .flatpickr-current-month {
    padding: 0;
    height: 24px;
    font-size: 16px;
    line-height: 24px;
    font-weight: 600;
  }
  .flatpickr-innerContainer {
    margin-top: 24px;
  }
  .flatpickr-weekdays {
    height: 20px;
  }
  .flatpickr-weekdays .flatpickr-weekdaycontainer {
    flex: unset;
  }
  span.flatpickr-weekday {
    font-size: 11px;
    line-height: 20px;
    color: #868BA2;
    font-weight: 600;
    width: 34px;

    + span.flatpickr-weekday {
      margin-right: 6px;
    }
  }
  .flatpickr-days {
    width: 100% !important;
  }
  .dayContainer {
    width: 274px;
    min-width: 274px;
    max-width: 274px;
    margin-top: 6px;
    justify-content: normal;
  }
  .flatpickr-day {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    max-width: 30px;
    height: 30px;
    font-size: 14px;
    line-height: 20px;
    color: #2D3145;
    font-weight: 500;
    margin: 0 4px;
  }
  .flatpickr-day.today, .flatpickr-day.selected {
    color: #fff;
    border: none;
    padding: 0 5px;
    background-color: #5755FF;
  }
  .flatpickr-day:hover {
    color: #5755FF;
    background-color: #F0F1F4;
  }
  .flatpickr-day.today:hover {
    color: #5755FF;
    background-color: #F0F1F4;
  }
  .flatpickr-calendar.rangeMode {
    width: 670px !important;
  }
  .flatpickr-calendar.rangeMode .flatpickr-months::before {
    content: '';
    display: block;
    position: absolute;
    left: 50%;
    height: 66%;
    border-left: 1px solid #DADCE4;
  }
  .flatpickr-weekdaycontainer + .flatpickr-weekdaycontainer {
    margin-left: 61px;
  }
  .dayContainer + .dayContainer {
    position: relative;
    margin-left: 61px;
    box-shadow: unset;
  }
  .flatpickr-day.inRange {
    position: relative;
    -webkit-box-shadow: unset;
    box-shadow: unset;
    background: #E0E5FF;

    ::after {
      content: '';
      position: absolute;
      display: block;
      width: 100%;
      height: 30px;
      background-color: red;
    }
  }
  .flatpickr-day.inRange.today {
    color: #2D3145;
  }
  .flatpickr-day.inRange, 
  .flatpickr-day.prevMonthDay.inRange, 
  .flatpickr-day.nextMonthDay.inRange, 
  .flatpickr-day.today.inRange, 
  .flatpickr-day.prevMonthDay.today.inRange, 
  .flatpickr-day.nextMonthDay.today.inRange {
    background: #F5F6FF;
    border-color: transparent;
    -webkit-box-shadow: -15px 0 0 #F5F6FF, 15px 0 0 #F5F6FF;
    box-shadow: -15px 0 0 #F5F6FF, 15px 0 0 #F5F6FF;
    z-index: -10;
  }
  .flatpickr-day.selected, 
  .flatpickr-day.startRange, 
  .flatpickr-day.endRange {
    background: none;
    border: none;
  }
  .flatpickr-day.selected.startRange + 
  .endRange:not(:nth-child(7n+1)), 
  .flatpickr-day.startRange.startRange + 
  .endRange:not(:nth-child(7n+1)), 
  .flatpickr-day.endRange.startRange + 
  .endRange:not(:nth-child(7n+1)) {
    box-shadow: unset;
  }
  .flatpickr-day.selected.startRange, 
  .flatpickr-day.startRange.startRange, 
  .flatpickr-day.endRange.startRange, 
  .flatpickr-day.selected.endRange, 
  .flatpickr-day.startRange.endRange, 
  .flatpickr-day.endRange.endRange {
    border-radius: 100%;
  }
  .flatpickr-day.selected, 
  .flatpickr-day.startRange, 
  .flatpickr-day.endRange, 
  .flatpickr-day.selected.inRange, 
  .flatpickr-day.startRange.inRange, 
  .flatpickr-day.endRange.inRange, 
  .flatpickr-day.selected:focus, 
  .flatpickr-day.startRange:focus, 
  .flatpickr-day.endRange:focus, 
  .flatpickr-day.selected:hover, 
  .flatpickr-day.startRange:hover, 
  .flatpickr-day.endRange:hover, 
  .flatpickr-day.selected.prevMonthDay, 
  .flatpickr-day.startRange.prevMonthDay, 
  .flatpickr-day.endRange.prevMonthDay, 
  .flatpickr-day.selected.nextMonthDay, 
  .flatpickr-day.startRange.nextMonthDay, 
  .flatpickr-day.endRange.nextMonthDay {
    background-color: #5755FF;
  }
  .flatpickr-calendar.multiMonth 
  .flatpickr-days 
  .dayContainer:nth-child(n+1) 
  .flatpickr-day.inRange:nth-child(7n+7) {
    border-top-right-radius: 50%;
    border-bottom-right-radius: 50%;
  }
  .flatpickr-calendar.multiMonth 
  .flatpickr-days 
  .dayContainer:nth-child(n+1) 
  .flatpickr-day.inRange:nth-child(7n+1) {
    border-top-left-radius: 50%;
    border-bottom-left-radius: 50%;
    box-shadow: unset;
  }
  .flatpickr-current-month .flatpickr-monthDropdown-months {
    border: 1px solid;
    padding: 0 8px;
    font-size: 16px;
    line-height: 24px;
    color: #2D3145;
    font-weight: 600;
  }
  .flatpickr-day.hidden {
    visibility: visible;
  }
  
  /* react-select */
  div.react-select__menu-portal {
    z-index: 900;
    .react-select__menu {
      font-size: 14px;
      box-shadow: 0 6px 10px #0000000d;
      border: 1px solid #caccd7;
      padding: 8px;
      z-index: 20;
    }
    .react-select__option {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 36px;
      padding: 8px 6px 8px 9px;
      border-radius: 4px;

      label {
        flex: 1;
        font-size: 14px;
        border-radius: 6px;
        line-height: 36px;
        color: #434860;
        font-weight: 400;
        padding-left: 9px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        word-break: break-all;
      }

      label[for='checkbox-*'] {
        position: relative;
        width: 100%;
        height: 100%;
      }
    }
    .react-select__option--is-focused {
      background-color: #f8f9fb;
    }
    .react-select__option--is-selected {
      background-color: transparent !important;
      font-weight: 500;
      color: #455dd7;
    }
  }
`;

export default GlobalStyle;

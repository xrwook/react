import styled from 'styled-components';

export const RenderWrap = styled.div`
  display: flex;
  gap: 14px;
  height: 100%;
  align-items: center;
`;

export const RenderBox = styled.div`
  display: flex;
  gap: 4px;
  height: 20px;
  align-items: center;
  font-size: 14px;
  font-weight: 400;
`;

export const RenderCurrent = styled.span`
  color: #5755ff;

  &:after {
    content: '/';
    display: inline-block;
    vertical-align: top;
    color: #a0a4b6;
  }
`;

export const RenderTotal = styled.span`
  color: #a0a4b6;
`;

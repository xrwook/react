import React from 'react';
import styled from 'styled-components';

interface PageTitleProps {
  children: React.ReactNode;
}

const StyledTitle = styled.h2`
  font-size: 30px;
  font-weight: 700;
  color: #000;
  margin-bottom: 1.5rem;
`;

const PageTitle: React.FC<PageTitleProps> = ({ children }) => {
  return <StyledTitle>{children}</StyledTitle>;
};

export default PageTitle;

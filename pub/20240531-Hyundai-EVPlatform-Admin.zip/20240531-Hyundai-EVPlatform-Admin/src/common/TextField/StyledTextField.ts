import styled from 'styled-components';
import { TextFieldProps } from './TextField';
import deleteIcon from '/images/icons/icon-delete.svg';
import searchIcon from '/images/icons/icon-search.svg';
import disabledIcon from '/images/icons/icon-search-secondaryGray-disabled.svg';
import testIcon from '/images/icons/icon-search-secondaryGray.svg';

export const InputWrapper = styled.div`
  position: relative;
  flex: 1;
`;

export const InputText = styled.input<TextFieldProps>`
  display: block;
  width: ${(props) => (props.$width ? props.$width + 'px' : '100%')};
  height: ${(props) => (props.$height ? props.$height + 'px' : '32px')};
  padding: 5px 9px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) =>
    props.disabled
      ? `${props.theme.color.textDimed}`
      : props.readOnly
        ? `${props.theme.color.gray4}`
        : `${props.theme.color.gray8}`};
  font-weight: 400;
  border: ${(props) =>
    props.disabled
      ? `1px solid ${props.theme.color.gray2}`
      : props.readOnly
        ? `1px solid ${props.theme.color.gray2}`
        : props.$error
          ? '1px solid #DB3232'
          : `1px solid ${props.theme.color.gray3}`};
  border-radius: 4px;
  background-color: ${(props) =>
    props.readOnly
      ? '#F9F9F9'
      : props.disabled
        ? '#F9F9F9'
        : `${props.theme.color.white}`};

  &::placeholder {
    color: ${(props) => props.theme.color.gray4};
  }

  &:hover {
    border: ${(props) =>
      props.$error
        ? '1px solid #DB3232'
        : props.$verified
          ? `1px solid ${props.theme.color.gray3}`
          : `1px solid ${props.theme.color.primary}`};
  }

  &:focus {
    border: 1px solid
      ${(props) =>
        props.$error
          ? '#DB3232'
          : props.$verified
            ? `1px solid ${props.theme.color.gray3}`
            : '#0057ff'};
    outline: none;
  }

  &:disabled {
    pointer-events: none;
  }

  &::-webkit-inner-spin-button {
    margin: 0;
    -webkit-appearance: none;
  }
  &::-webkit-outer-spin-button {
    margin: 0;
    -webkit-appearance: none;
  }
`;

export const DeleteButton = styled.button<TextFieldProps>`
  position: absolute;
  top: 50%;
  right: ${(props) => (props.$search ? '34px' : '9px')};
  transform: translateY(-50%);
  margin-top: ${(props) =>
    props.$errorMessage ? '-10px' : props.$verifiedMessage ? '-10px' : '0'};
  width: 14px;
  height: 14px;
  background: url(${deleteIcon}) no-repeat;
`;

export const SearchButton = styled.button<TextFieldProps>`
  display: ${(props) => (props.$search ? 'block' : 'none')};
  position: absolute;
  top: 50%;
  right: 9px;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background: ${(props) =>
    props.readOnly
      ? `url(${disabledIcon})`
      : props.disabled
        ? `url(${disabledIcon})`
        : props.$inputValue
          ? `url(${testIcon})`
          : `url(${searchIcon})`};
  background-repeat: no-repeat;
`;

export const ErrorMessage = styled.div`
  display: flex;
  align-items: center;
  color: #db3232;
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  margin-top: 2px;
  padding-left: 4px;
  white-space: nowrap;
`;

export const VerifiedMessage = styled.div`
  display: flex;
  align-items: center;
  color: #009b6d;
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  margin-top: 2px;
  padding-left: 4px;
  white-space: nowrap;
`;

export const InnerRight = styled.span<TextFieldProps>`
  position: absolute;
  top: 50%;
  right: 9px;
  transform: translateY(-50%);
  font-size: 14px;
  font-weight: 400;
  color: ${(props) =>
    props.readOnly ? '#a0a4b6' : props.value ? '#434860' : '#a0a4b6'};
`;

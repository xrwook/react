import styled from 'styled-components';
import CheckIcon from 'style/assets/images/common/icon-check-radio.svg';
import DisabledIcon from 'style/assets/images/common/icon-disabled-radio.svg';

const RadioWrapper = styled.div`
  display: flex;
  align-items: center;
  vertical-align: middle;
`;

const StyledRadio = styled.input<RadioProps>`
  appearance: none;
  display: inline-block;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  transition: all 150ms;
  border: 1px solid #caccd7;
  background-color: ${(props) => props.theme.color.white};
  background-repeat: no-repeat;
  background-size: contain;
  cursor: pointer;

  &:checked {
    width: 16px;
    height: 16px;
    background-image: url(${CheckIcon});
    border: none;
  }

  &:checked:hover {
    opacity: 0.7;
  }

  &:checked:disabled {
    background-image: url(${DisabledIcon});
    border: none;
  }

  &:disabled {
    border: 1px solid #dbdde5;
    background-color: #f5f6fa;
  }
`;

const StyledRadioText = styled.span<RadioProps>`
  margin-left: 9px;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => (props.disabled ? '#CDCDCD' : '#434860')};
  line-height: 20px;
  font-weight: 400;
`;

export interface RadioProps {
  id?: string;
  name?: string;
  text?: string;
  htmlFor?: string;
  disabled?: boolean;
  checked?: boolean;
  defaultChecked?: boolean;
  className?: string;
}

const RadioBox: React.FC<RadioProps> = ({
  id,
  name,
  text,
  htmlFor,
  disabled,
  checked,
  defaultChecked,
  className,
}) => {
  return (
    <>
      <RadioWrapper>
        <StyledRadio
          type="radio"
          id={id}
          name={name}
          disabled={disabled}
          checked={checked}
          defaultChecked={defaultChecked}
          className={className}
        />
        <label htmlFor={htmlFor}>
          {text && (
            <StyledRadioText disabled={disabled}>{text}</StyledRadioText>
          )}
        </label>
      </RadioWrapper>
    </>
  );
};

export default RadioBox;

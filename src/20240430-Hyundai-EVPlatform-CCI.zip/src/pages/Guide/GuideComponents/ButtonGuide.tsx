import React from 'react';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import { BasicButton } from 'common/BasicButton/BasicButton';
import TextButton from 'common/TextButton';

const ProgressGuide: React.FC = () => {
  return (
    <GuideWrapper>
      <div style={{ padding: '50px' }}>
        <section>
          <GuideText>Button - Basic</GuideText>
          <GuideBox>
            <div style={{ display: 'flex' }}>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'medium'}>Button</BasicButton>
              </div>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton variant="outline">Button</BasicButton>
              </div>
            </div>
          </GuideBox>
          <GuideSubBox>
            &lt;BasicButton&gt;
            <br />
            &lt;BasicButton variant="outline&gt;
          </GuideSubBox>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>Button - Small</GuideText>
          <GuideBox>
            <div style={{ display: 'flex' }}>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'small'}>Button</BasicButton>
              </div>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'small'} variant="outline">
                  Button
                </BasicButton>
              </div>
            </div>
          </GuideBox>
          <GuideSubBox>
            &lt;BasicButton size={'small'}&gt;
            <br />
            &lt;BasicButton size={'small'} variant="outline"&gt;
          </GuideSubBox>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>Button - Large</GuideText>
          <GuideBox>
            <div style={{ display: 'flex' }}>
              <div>
                <BasicButton size={'large'}>Button</BasicButton>
              </div>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'large'} variant="outline">
                  Button
                </BasicButton>
              </div>
            </div>
          </GuideBox>
          <GuideSubBox>
            &lt;BasicButton size={'large'}&gt;
            <br />
            &lt;BasicButton size={'large'} variant="outline"&gt;
          </GuideSubBox>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>Button - Disabled</GuideText>
          <GuideBox>
            <div style={{ display: 'flex' }}>
              <div>
                <BasicButton size={'small'} disabled>
                  Button
                </BasicButton>
              </div>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'medium'} disabled>
                  Button
                </BasicButton>
              </div>
              <div style={{ marginLeft: '10px' }}>
                <BasicButton size={'large'} variant="positive" disabled>
                  Button
                </BasicButton>
              </div>
            </div>
          </GuideBox>
          <GuideSubBox>
            &lt;BasicButton size={'small'} disabled&gt;
            <br />
            &lt;BasicButton size={'medium'} disabled&gt;
            <br />
            &lt;BasicButton size={'large'} disabled&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>disabled</td>
                <td>disabled</td>
                <td>disabled prop 추가</td>
                <td>boolean</td>
              </tr>
              <tr>
                <td>variant</td>
                <td>primary(default)</td>
                <td>variant="primary"</td>
                <td>버튼 타입에 따라 설정</td>
              </tr>
              <tr>
                <td>size</td>
                <td>large</td>
                <td>size="large"</td>
                <td>사이즈 정의</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>

        <section style={{ marginTop: '50px' }}>
          <GuideText>Button - Text Button</GuideText>
          <GuideBox>
            <ul style={{ display: 'flex', alignItems: 'center' }}>
              <li>
                <TextButton color="blue">TextButton</TextButton>
              </li>
              <li style={{ marginLeft: '15px' }}>
                <TextButton icon="IconNotice" iconPosition="left">
                  TextButton
                </TextButton>
              </li>
              <li style={{ marginLeft: '15px' }}>
                <TextButton icon="IconArrowRight">TextButton</TextButton>
              </li>
            </ul>
          </GuideBox>

          <GuideSubBox>
            &lt;TextButton color="blue"&gt;
            <br />
            &lt;TextButton icon="IconNotice" iconPosition="left"&gt;
            <br />
            &lt;icon="IconArrowRight"&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>icon</td>
                <td>icon</td>
                <td>icon 입력</td>
                <td>컴포넌트 Icons에 추가</td>
              </tr>
              <tr>
                <td>iconPosition</td>
                <td>iconPosition</td>
                <td>iconPosition 설정</td>
                <td>iconPosition에 위치 기입</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>
      </div>
    </GuideWrapper>
  );
};

export default ProgressGuide;

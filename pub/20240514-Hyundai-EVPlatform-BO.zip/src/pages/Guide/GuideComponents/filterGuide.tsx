import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import TextField from 'common/TextField';
import FilterLabel from 'common/Filter/FilterLabel';
import Select from 'common/Select/Select';
import { useState } from 'react';
import { Option } from 'common/Select/Select';
// import Dropdown from 'common/Dropdown/Dropdown';

const options = [
  {
    value: 'option01',
    label: 'option01',
  },
  {
    value: 'option02',
    label: 'option02',
  },
  {
    value: 'option03',
    label: 'option03',
  },
  {
    value: '최근 1주일',
    label: '최근 1주일',
  },
];

const FilterGuide = () => {
  const [optionSelected, setSelected] = useState<Option[] | null>();
  const handleChange = (selected: Option[]) => {
    setSelected(selected);
  };
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Filter</GuideText>
        <GuideBox>
          <h3 style={{ margin: '0 0 10px 0' }}>[필터 5개 이하]</h3>
          <FilterList useDetailButtons>
            <FilterItem $search>
              <TextField
                id="TextField01"
                name="text"
                type="text"
                placeholder="충전소 이름을 입력 후 검색하세요"
                $search
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>사업자 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
                isMulti
                isSelectAll={true}
                onChange={handleChange}
                value={optionSelected}
                hideSelectedOptions={false}
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>권역 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>충전소 유형 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>시설 형태 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>시설 구분 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
              />
            </FilterItem>
            <FilterItem>
              <FilterLabel>개방 형태 :</FilterLabel>
              <Select
                placeholder="전체"
                options={options}
                classNamePrefix="react-select"
                $transparent
              />
            </FilterItem>
          </FilterList>
        </GuideBox>
        <GuideSubBox>&lt; /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default FilterGuide;

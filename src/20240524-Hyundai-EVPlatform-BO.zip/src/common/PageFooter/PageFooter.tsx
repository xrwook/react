import { PageFooterWrapper } from './StyledPageFooter';

export interface PageFooterProps {
  children?: any;
}

const PageFooter: React.FC<PageFooterProps> = ({ children }) => {
  return (
    <>
      <PageFooterWrapper>{children}</PageFooterWrapper>
    </>
  );
};

export default PageFooter;

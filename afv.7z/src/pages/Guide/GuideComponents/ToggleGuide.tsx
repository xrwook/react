import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Toggle from 'common/Toggle';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const ToggleGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Toggle-Switch</GuideText>
        <GuideBox>
          <Toggle />
          <Toggle disabled />
          <Toggle defaultChecked />
          <Toggle defaultChecked disabled />
          <Toggle label="Label" />
          <Toggle label="Label" disabled />
          <Toggle label="Label" defaultChecked />
          <Toggle label="Label" defaultChecked disabled />
        </GuideBox>
        <GuideSubBox>
          &lt;Toggle /&gt; <br />
          &lt;Toggle disabled /&gt; <br />
          &lt;Toggle defaultChecked /&gt; <br />
          &lt;Toggle defaultChecked disabled /&gt; <br />
          &lt;Toggle label="" /&gt; <br />
          &lt;Toggle label="" disabled /&gt; <br />
          &lt;Toggle label="" defaultChecked /&gt; <br />
          &lt;Toggle label="" defaultChecked disabled /&gt; <br />
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default ToggleGuide;

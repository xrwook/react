import styled, { css } from 'styled-components';

export const FileSearchWrap = styled.div<{ $position: any }>`
  display: flex;
  flex-direction: ${(props) =>
    props.$position === 'bottom' ? 'column-reverse' : 'column'};
  gap: 12px;
`;

export const FileSearchBox = styled.label`
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  font-weight: 400;
  color: ${(props) => props.theme.color.text5};

  > input {
    display: none;
  }

  > button {
    z-index: 0;
  }
`;

export const FileAttachArea = styled.div<{ $small: any }>`
  margin-top: 12px;
  display: flex;
  flex-wrap: wrap;
  gap: ${(props) => (props.$small ? '8px' : '16px')};

  &:empty {
    display: none;
  }

  .file-attach-area {
    position: relative;
    width: ${(props) => (props.$small ? '140px' : '160px;')};
    height: ${(props) => (props.$small ? '140px' : '160px;')};
    border: 1px dashed #caccd7;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    > img {
      object-fit: contain;
      width: 100%;
      height: 100%;
    }

    .file-attach-button {
      position: absolute;
      top: -8px;
      right: -8px;
    }
  }
`;

export const FileSearchDnd = styled.div`
  .dnd-title {
    font-size: ${(props) => props.theme.fontSize.fontSize2};
    font-weight: 400;
    color: ${(props) => props.theme.color.text5};

    & + .dnd-stage {
      margin-top: 16px;
    }
  }
`;

export const DndStage = styled.div<{ $drag: any; $active: any }>`
  height: 72px;
  border: 1px dashed ${(props) => props.theme.color.gray2};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  color: ${(props) => props.theme.color.gray4};

  ${(props) =>
    props.$drag &&
    css`
      border-color: ${(props) => props.theme.color.textSub};
      color: ${(props) => props.theme.color.textSub};
      .other-text {
        color: ${(props) => props.theme.color.gray4};
      }
    `}

  .other-text {
    font-size: ${(props) => props.theme.fontSize.fontSize1};
    font-weight: 400;
    margin: 0 24px 0 16px;
  }

  > input {
    display: none;
  }

  .uploaded-info {
    display: flex;
    align-items: center;
    font-size: ${(props) => props.theme.fontSize.fontSize4};
    font-weight: 500;
    color: ${(props) => props.theme.color.text1};
    gap: 8px;

    .file-attach-button {
      margin-left: 2px;
    }
  }
`;

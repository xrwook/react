import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Labels from 'common/Labels';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import { styled } from 'styled-components';

const Div = styled.div`
  display: block;
`;

const LabelsGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Label(디자인 확정전)</GuideText>
        <GuideBox>
          <Div>
            <Labels $color="purpleDark" $size="small">
              TAG
            </Labels>
            <Labels $color="blueDark" $size="small">
              TAG
            </Labels>
            <Labels $color="gray" $size="small">
              QR, NFC
            </Labels>
          </Div>

          <Div>
            <Labels $color="red" $size="medium">
              Labels
            </Labels>
            <Labels $color="blue" $size="medium">
              Labels
            </Labels>
            <Labels $color="yellow" $size="medium">
              Labels
            </Labels>
            <Labels $color="purple" $size="medium">
              Labels
            </Labels>
            <Labels $color="green" $size="medium">
              Labels
            </Labels>
            <Labels $color="gray" $size="medium">
              Labels
            </Labels>
          </Div>

          <Div>
            <Labels $color="redWhite" $size="default">
              Labels
            </Labels>
            <Labels $color="blueWhite" $size="default">
              Labels
            </Labels>
            <Labels $color="yellowWhite" $size="default">
              Labels
            </Labels>
            <Labels $color="purpleWhite" $size="default">
              Labels
            </Labels>
            <Labels $color="greenWhite" $size="default">
              Labels
            </Labels>
            <Labels $color="grayWhite" $size="default">
              Labels
            </Labels>
          </Div>
        </GuideBox>
        <GuideSubBox>
          &lt;Labels color="" size="" &gt;&lt;/Labels&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default LabelsGuide;

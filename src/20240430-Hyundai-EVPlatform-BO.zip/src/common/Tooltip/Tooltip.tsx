import { useState } from 'react';
import styled, { css } from 'styled-components';
import TopIcon from 'style/assets/images/icon-arrow-top.svg';
import BottomIcon from 'style/assets/images/icon-arrow-bottom.svg';
import LeftIcon from 'style/assets/images/icon-arrow-left.svg';
import RightIcon from 'style/assets/images//icon-arrow-right.svg';

const direction = {
  top: css`
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);

    &::before {
      bottom: -6px;
      background-image: url(${TopIcon});
    }
  `,
  left: css`
    top: 50%;
    right: calc(100% + 15px);
    transform: translateY(-50%);

    &::before {
      top: 50%;
      left: auto !important;
      right: -6px;
      transform: translateY(-50%) !important;
      width: 6px !important;
      height: 8px !important;
      background-image: url(${LeftIcon});
    }
  `,
  right: css`
    top: 50%;
    left: calc(100% + 15px);
    transform: translateY(-50%);

    &::before {
      top: 50%;
      left: -6px !important;
      right: auto !important;
      transform: translateY(-50%) !important;
      width: 6px !important;
      height: 8px !important;
      background-image: url(${RightIcon});
    }
  `,
  bottom: css`
    left: 50%;
    top: 30px;
    transform: translateX(-50%);

    &::before {
      top: -6px !important;
      left: 50%;
      background-image: url(${BottomIcon});
    }
  `,
};

const TooltipWrapper = styled.div`
  display: inline-block;
  position: relative;
`;

const TooltipTip = styled.div<TooltipProps>`
  position: absolute;
  border-radius: 6px;
  padding: 2px 8px;
  color: ${(props) => props.theme.color.white};
  background: #282e38e5;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  font-weight: 500;
  z-index: 100;
  width: ${(props) => (props.auto ? 'auto' : '240px')};
  height: auto;
  display: block;
  white-space: ${(props) => (props.auto ? 'nowrap' : '')};
  ${(props) => direction[props.direction]};

  &::before {
    content: '';
    display: block;
    left: 50%;
    transform: translateX(-50%);
    position: absolute;
    z-index: 100;
    width: 8px;
    height: 6px;
    background-repeat: no-repeat;
    background-size: cover;
  }
`;

export interface TooltipProps {
  children?: any;
  message?: any;
  direction: 'top' | 'left' | 'right' | 'bottom';
  auto?: any;
}

const Tooltip: React.FC<TooltipProps> = ({
  children,
  direction,
  message,
  auto,
}) => {
  const [active, setActive] = useState(false);

  const showTip = () => {
    setActive(true);
  };

  const hideTip = () => {
    setActive(false);
  };

  return (
    <TooltipWrapper onMouseEnter={showTip} onMouseLeave={hideTip}>
      {children}
      {active && (
        <TooltipTip direction={direction} auto={auto ? 'true' : undefined}>
          {message}
        </TooltipTip>
      )}
    </TooltipWrapper>
  );
};

export default Tooltip;

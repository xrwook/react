import { ButtonStyle } from './StyledButton';

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  className?: string;
  children?: React.ReactNode;
  disabled?: any;
  onClick: React.MouseEventHandler<HTMLButtonElement>;
  $icon?: any;
  download?: any;
  iconOnly?: any;
  isSelected?: any;
  $size: 'mini' | 'small' | 'large';
  $variant:
    | 'primary'
    | 'secondaryBlue'
    | 'secondaryGray'
    | 'tertiary'
    | 'transparent'
    | 'transparentPurple';
}

const Button: React.FC<ButtonProps> = ({
  children,
  disabled,
  className,
  onClick,
  $size,
  $variant,
  $icon,
  download,
  isSelected,
}) => {
  return (
    <ButtonStyle
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={className}
      $size={$size}
      $variant={$variant}
      $icon={$icon}
      download={download}
      isSelected={isSelected}
    >
      <span>{children}</span>
    </ButtonStyle>
  );
};

export default Button;

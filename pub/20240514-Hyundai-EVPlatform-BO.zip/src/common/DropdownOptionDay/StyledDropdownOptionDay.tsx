import styled from 'styled-components';

export const OptionWrapper = styled.div<{ $day: any }>`
  position: absolute;
  top: 38px;
  display: ${(props) => (props.$day ? 'block' : 'none')};
  padding: 8px 12px 10px 12px;
  width: 300px;
  height: auto;
  border: 1px solid #caccd7;
  border-radius: 4px;
  background-color: #fff;
  box-shadow: 0 6px 10px #0000000d;
  z-index: 20;
`;

export const OptionHeader = styled.div`
  position: relative;
  padding-bottom: 10px;
  margin-bottom: 8px;

  &::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    border-bottom: 1px solid #f0f1f4;
  }
`;

export const OptionHeaderTitle = styled.div`
  padding: 4px 10px;
  margin-bottom: 8px;
  font-size: 14px;
  line-height: 20px;
  color: #434860;
  font-weight: 500;
`;

export const OptionLayout = styled.div`
  margin-top: 8px;
  display: flex;
  align-items: center;
  gap: 10px;

  .divider {
    display: inline-block;
    width: 6px;
    height: 1px;
    background-color: #d9d9d9;
    flex: 1 0 auto;
  }
`;

export const OptionFooter = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 8px;
  padding: 8px 8px 0 8px;
  border-top: 1px solid #f0f1f4;

  > button {
    padding: 0;
    height: 20px;
  }
`;

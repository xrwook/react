import { useState, useEffect } from 'react';
import Icon from 'common/Icon/Icon';
import { StyledPagination, PaginationNavButton } from './styledPagination';

export interface PaginationProps {
  gridApi?: any;
  defaultNumberButtons?: number;
}

const Pagination: React.FC<PaginationProps> = ({ gridApi }) => {
  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => {
    if (gridApi) {
      const handlePageChanged = () => {
        setCurrentPage(gridApi.paginationGetCurrentPage());
      };
      gridApi.addEventListener('paginationChanged', handlePageChanged);
      return () => {
        gridApi.removeEventListener('paginationChanged', handlePageChanged);
      };
    }
  }, [gridApi]);
  if (gridApi) {
    const totalPages = gridApi.paginationGetTotalPages();
    const pageButtonsToShow = 11;
    const onBtFirst = () => {
      gridApi.paginationGoToFirstPage();
    };
    const onBtLast = () => {
      gridApi.paginationGoToLastPage();
    };
    const onBtNext = () => {
      gridApi.paginationGoToNextPage();
    };
    const onBtPrevious = () => {
      gridApi.paginationGoToPreviousPage();
    };
    const onPageButtonClick = (pageIndex: any) => {
      gridApi.paginationGoToPage(pageIndex);
      setCurrentPage(pageIndex);
    };
    const getPageButtons = () => {
      const pageButtons = [];
      const startPage = Math.max(
        0,
        currentPage - Math.floor(pageButtonsToShow / 2),
      );
      const endPage = Math.min(
        totalPages - 1,
        startPage + pageButtonsToShow - 1,
      );

      for (let i = 0; i <= endPage; i++) {
        pageButtons.push(
          <button
            type="button"
            key={i}
            onClick={() => onPageButtonClick(i)}
            className={i === currentPage ? 'paging active' : 'paging'}
          >
            {i + 1}
          </button>,
        );
      }
      return pageButtons;
    };

    return (
      <StyledPagination>
        <PaginationNavButton
          onClick={onBtFirst}
          disabled={currentPage === 0 ? true : false}
        >
          <Icon
            $widthSize={20}
            $heightSize={20}
            $name={`icon-paging-arrow-first${currentPage === 0 ? '-disabled' : ''}`}
          >
            처음으로
          </Icon>
        </PaginationNavButton>
        <PaginationNavButton
          onClick={onBtPrevious}
          disabled={currentPage === 0 ? true : false}
        >
          <Icon
            $widthSize={20}
            $heightSize={20}
            $name={`icon-paging-arrow-${currentPage === 0 ? 'left-disabled' : 'left'}`}
          >
            이전
          </Icon>
        </PaginationNavButton>
        {getPageButtons()}
        <PaginationNavButton
          onClick={onBtNext}
          disabled={currentPage + 1 === totalPages ? true : false}
        >
          <Icon
            $widthSize={20}
            $heightSize={20}
            $name={`icon-paging-arrow-${currentPage + 1 === totalPages ? 'right-disabled' : 'right'}`}
          >
            다음
          </Icon>
        </PaginationNavButton>
        <PaginationNavButton
          onClick={onBtLast}
          disabled={currentPage + 1 === totalPages}
        >
          <Icon
            $widthSize={20}
            $heightSize={20}
            $name={`icon-paging-arrow-last${currentPage + 1 === totalPages ? '-disabled' : ''}`}
          >
            마지막으로
          </Icon>
        </PaginationNavButton>
      </StyledPagination>
    );
  }
  return null;
};
export default Pagination;

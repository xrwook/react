import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Layout } from '../common/Tab/Layout';
import { Home_ } from '../common/Tab/Home';
import { AxiosQuery } from '../pages/Subpage/AxiosQuery';
import { ReactQuery } from '../pages/Subpage/ReactQuery';
// import Articles from '../pages/Articles';
import Home from '../pages/Home';
import PrivateRoute from './PrivateRoute';
import PublicRoute from './PublicRoute';
import React from 'react';
import { ServiceType } from '../types/serviceType';
import HyundaiRoute from './HyundaiRoute';
import KiaRoute from './KiaRoute';
import GenesisRoute from './GenesisRoute';

export interface RouterProps {
  serviceType: ServiceType;
}

const Router: React.FC<RouterProps> = (
  { serviceType },
) => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={
        <PublicRoute>
          <Home />
        </PublicRoute>
      }
      />
      <Route path="/tab" element={
        <PrivateRoute>
          {/* <Articles /> */}
          <Layout />
        </PrivateRoute>
      }>
        <Route index element={<Home_ />} />
        <Route path="axios-query" element={<AxiosQuery />} />
        <Route path="react-query" element={<ReactQuery />} />
      </Route>
    </Routes>
    {serviceType == ServiceType.Hyundai ?
      <HyundaiRoute />
      : serviceType == ServiceType.Kia ?
        <KiaRoute />
        : serviceType == ServiceType.Genesis ?
          <GenesisRoute />
          : <></>}

  </BrowserRouter>
);

export default Router;

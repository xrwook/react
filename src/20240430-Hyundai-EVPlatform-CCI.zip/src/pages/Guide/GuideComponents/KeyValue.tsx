import GuideWrapper from 'pages/Guide/GuideComponents/GuideBox/GuideWrapper';
import GuideBox from 'pages/Guide/GuideComponents/GuideBox/GuideBox';
import GuideText from 'pages/Guide/GuideComponents/GuideBox/GuideText';
import GuideSubBox from 'pages/Guide/GuideComponents/GuideBox/GuideSubBox';
import GuideTable from 'pages/Guide/GuideComponents/GuideTable';
import KeyValue from 'common/KeyValue/KeyValue';
import BasicBox from 'common/BasicBox/BasicBox';

const exampleItems01 = [
  { label: 'Date', value: '28 Dec 2022 11:14' },
  { label: 'kWh Usage', value: '245 kWh' },
  { label: 'Charging Duration', value: '01:35:41 hours' },
];

const exampleItems02 = [
  { label: 'Date02', value: '28 Dec 2022 11:14' },
  { label: 'kWh Usage02', value: '245 kWh' },
  { label: 'Charging Duration02', value: '01:35:41 hours' },
];

const ProgressGuide = () => {
  return (
    <GuideWrapper>
      <div style={{ padding: '50px' }}>
        <section>
          <GuideText>Key Value & Basic Box</GuideText>
          <GuideBox>
            <ul>
              <li>
                <BasicBox border="#eaeaea">
                  <KeyValue items={exampleItems01} />
                </BasicBox>
              </li>
              <li style={{ marginTop: '15px' }}>
                <BasicBox background="#eaeaea">
                  <KeyValue items={exampleItems02} />
                </BasicBox>
              </li>
            </ul>
          </GuideBox>
          <GuideSubBox>
            &lt;BasicBox border="#eaeaea"&gt; <br />
            &lt;KeyValue items='exampleItems'&gt; <br />
            &lt;BasicBox background="#eaeaea"&gt;
          </GuideSubBox>
          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>border</td>
                <td>border</td>
                <td>border 색상 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>background</td>
                <td>background</td>
                <td>background 색상 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </section>
      </div>
    </GuideWrapper>
  );
};

export default ProgressGuide;

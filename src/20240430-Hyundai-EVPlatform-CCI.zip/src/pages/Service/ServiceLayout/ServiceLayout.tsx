import React from 'react';
import {
  ServiceBlock,
  ServiceWrapper,
} from 'pages/Service/StyledService/ServiceLayout';

export interface ServiceLayoutProps {
  children?: React.ReactNode;
}

const ServiceLayout: React.FC<ServiceLayoutProps> = ({ children }) => {
  return (
    <ServiceBlock>
      <ServiceWrapper>{children}</ServiceWrapper>
    </ServiceBlock>
  );
};

export default ServiceLayout;

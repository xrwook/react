// import styled from 'styled-components';
import { useState } from 'react';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
// import DatePicker from 'common/Datepicker/Datepicker';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import DatepickerTest from 'common/DatepickerTest/DatepickerTest';
import Test from 'common/Datepicker/Test';
import DatepickerRange from 'common/DatepickerRange/DatepickerRange';
// import TimePicker from 'common/TimepickerTest/TimepickerTest';

// const Layout = styled.div`
//   width: 100%;
//   display: flex;
//   align-items: center;
// `;

const DatePickerGuide = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  // const [endDate, setEndDate] = useState<Date | null>(new Date());

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Datepicker(Sample Version)</GuideText>
        <GuideBox>
          {/* <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            dateFormat="yyyy-MM-dd"
            todayButton="오늘 날짜로 이동"
          /> */}
          <Test
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            dateFormat="yyyy-MM-dd"
            todayButton="오늘 날짜로 이동"
          />
          {/* <Layout>
            <DatePicker
              selected={startDate}
              onChange={(date) => setStartDate(date)}
              selectsStart
              startDate={startDate}
              endDate={endDate}
              dateFormat="yyyy/MM/dd"
            />
            <DatePicker
              selected={endDate}
              onChange={(date) => setEndDate(date)}
              selectsEnd
              startDate={startDate}
              endDate={endDate}
              minDate={startDate}
              dateFormat="yyyy/MM/dd"
            />
          </Layout> */}
          {/* <div className="time">
            <DatePicker
              selected={startDate}
              onChange={(date) => setStartDate(date)}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={15}
              timeCaption="Time"
              dateFormat="h:mm aa"
            />
          </div> */}

          <div style={{ marginTop: '30px' }}>
            {/* <h3>단일 날짜 선택</h3>
            <DatepickerTest mode="single" /> */}
            <h3>날짜 범위 선택</h3>
            <DatepickerTest mode="range" />
            {/* <h3>타임 선택</h3>
            <TimePicker /> */}
          </div>
        </GuideBox>

        <GuideBox>
          <DatepickerRange mode={'range'} />
        </GuideBox>

        <GuideSubBox>
          &lt;DatePicker dateFormat="yyyy/MM/dd" disabled /&gt; <br />
          &lt;DatePicker showTimeSelect showTimeSelectOnly timeCaption="Time"
          dateFormat="h:mm aa" disabled /&gt; <br />
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default DatePickerGuide;

import { useState } from 'react';
import Alert from 'common/Alert';
import AlertContent from 'common/Alert/AlertContent';
import AlertFooter from 'common/Alert/AlertFooter';
import Button from 'common/Button';

const ChargingRateRegistrationAlertContainer: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);
  return (
    <>
      <button name="" onClick={() => setShowAlert(true)}>
        등록
      </button>
      {showAlert && (
        <Alert width="400px" height="auto">
          <AlertContent>
            필수 입력항목이 비어있습니다. <br />
            확인해주세요.
          </AlertContent>
          <AlertFooter>
            <Button
              onClick={() => {}}
              $size="large"
              $variant="primary"
              $width={65}
            >
              확인
            </Button>
          </AlertFooter>
        </Alert>
      )}
    </>
  );
};

export default ChargingRateRegistrationAlertContainer;

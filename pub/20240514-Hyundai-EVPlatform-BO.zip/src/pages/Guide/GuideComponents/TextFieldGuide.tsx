import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import TextField from 'common/TextField';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TextFieldGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>TextField</GuideText>
        <GuideBox>
          <TextField
            id="TextField01"
            name="text"
            type="text"
            placeholder="Placeholder"
          />
          <TextField
            id="TextField02"
            name="readOnly"
            type="text"
            value="readOnly"
            readOnly
          />
          <TextField
            id="TextField03"
            name="disabled"
            type="text"
            value="disabled"
            disabled
          />
          <TextField
            id="TextField04"
            name="number"
            type="number"
            placeholder="숫자만 입력해주세요"
          />
          <TextField
            id="TextField05"
            name="error"
            type="text"
            placeholder="error"
            $error
          />
          <TextField
            id="TextField06"
            name="text"
            type="text"
            placeholder="Placeholder"
            $search
          />
          <TextField
            id="TextField08"
            name="text"
            type="text"
            value="readOnly"
            readOnly
            $search
          />
          <TextField
            id="TextField07"
            name="text"
            type="text"
            value="disabled"
            disabled
            $search
          />
        </GuideBox>
        <GuideSubBox>
          &lt;TextField id="" name="" type="" placeholder="" /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" readOnly
          /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" disabled
          /&gt; <br />
          &lt;TextField id="" name="" type="" placeholder="" value="" $error
          /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TextFieldGuide;

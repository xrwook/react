import { useState } from 'react';
import Icon from 'common/Icon/Icon';
import Tooltip from 'common/Tooltip/Tooltip';
import {
  LnbWrap,
  LnbHeader,
  LnbHeaderLogo,
  LnbBody,
  LnbList,
  LnbItem,
  LnbFooter,
  SidebarDivider,
  SidebarButton,
  SidebarDragButton,
} from 'layout/StyledLayout';

export interface LnbProps {
  collapse?: boolean;
}

const Lnb: React.FC<LnbProps> = () => {
  const [collapse, setCollapse] = useState(false);

  const handleClick = () => {
    setCollapse(!collapse);
  };

  const iconSize: number = collapse ? 24 : 20;

  return (
    <LnbWrap className={collapse ? 'collapse' : ''}>
      <LnbHeader>
        <LnbHeaderLogo className="lnb-logo" />
      </LnbHeader>
      <LnbBody>
        <LnbList className="lnb-list">
          <LnbItem>
            <div className="lnb-item-left">
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-dashboard'}
              />
              {collapse ? (
                <Tooltip
                  direction={'right'}
                  message={'Dashboard'}
                  auto={'auto'}
                ></Tooltip>
              ) : (
                'Dashboard'
              )}
            </div>
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-menu'}
              />
              {collapse ? (
                <Tooltip
                  direction={'right'}
                  message={'All Menu'}
                  auto={'auto'}
                ></Tooltip>
              ) : (
                'All Menu'
              )}
            </div>
            {!collapse && (
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-arrow-right-16'}
              />
            )}
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-bookmark-20'}
              />
              {collapse ? (
                <Tooltip
                  direction={'right'}
                  message={'Bookmarks'}
                  auto={'auto'}
                ></Tooltip>
              ) : (
                'Bookmarks'
              )}
            </div>
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-recently'}
              />
              {collapse ? (
                <Tooltip
                  direction={'right'}
                  message={'Recently Viewed'}
                  auto={'auto'}
                ></Tooltip>
              ) : (
                'Recently Viewed'
              )}
            </div>
          </LnbItem>
        </LnbList>
      </LnbBody>
      <LnbFooter className="lnb-footer">한국어</LnbFooter>
      <SidebarDivider>
        <SidebarButton onClick={handleClick} />
        <SidebarDragButton />
      </SidebarDivider>
    </LnbWrap>
  );
};

export default Lnb;

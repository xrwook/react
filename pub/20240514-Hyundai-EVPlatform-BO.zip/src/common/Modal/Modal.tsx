import { DimWrapper, ModalBox, ModalClose, ModalWrapper } from './StyledModal';

export interface ModalProps {
  width?: string;
  height?: string;
  children?: any;
  onClose(): void;
}

const Modal: React.FC<ModalProps> = ({ width, height, children, onClose }) => {
  const handleCloseClick = (e: any) => {
    e.preventDefault();
    onClose();
  };

  return (
    <>
      <DimWrapper>
        <ModalWrapper>
          <ModalBox width={width} height={height}>
            <ModalClose
              type="button"
              aria-label="close"
              onClick={handleCloseClick}
            />
            {children}
          </ModalBox>
        </ModalWrapper>
      </DimWrapper>
    </>
  );
};

export default Modal;

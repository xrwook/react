import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Formcontrol from 'common/FormControl';
import TextField from 'common/TextField';
import Select from 'common/Select';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Textarea from 'common/Textarea';
import FormcontrolItem from 'common/FormcontrolItem';
import GuideTable from './GuideTable';

import {
  StyledWrapper,
  StyledGuideWrapper,
  StyledDivide,
} from './GuideBox/GuideWrapper';

const FormControlGuide = () => {
  const options = [
    {
      value: 'Select01',
      label: 'Select01',
    },
    {
      value: 'Select02',
      label: 'Select02',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>
          Form Control Guide
          <h3>
            Layout 은 {`<Grid></Grid> 와 <GridItem></GridItem>`} 을 사용합니다.
          </h3>
        </GuideText>
        <GuideBox>
          <GuideText>
            <h4>column이 1개 인 경우</h4>
          </GuideText>
          <Grid $columns={1}>
            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
                <TextField
                  id="TextField02"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>
          </Grid>
          <StyledDivide />
          <GuideText>
            <h4>column이 2개 인 경우</h4>
          </GuideText>
          <Grid $columns={2} $gap="12px 128px">
            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="아울렛 유형" htmlFor="TextField01">
                <TextField
                  id="TextField01"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
                <TextField
                  id="TextField02"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol title="grid test01" required htmlFor="TextField03">
                <TextField
                  id="TextField03"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                  $error
                  $errorMessage="Invaild message content"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                $row
                htmlFor="Select01"
              >
                <Select
                  inputId="Select01"
                  name="Select01"
                  placeholder="Text"
                  options={options}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol title="grid test02" required $row htmlFor="Select02">
                <Select
                  inputId="Select02"
                  name="Select02"
                  placeholder="Text"
                  options={options}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol title="grid test03" required $row htmlFor="Select03">
                <Select
                  inputId="Select03"
                  name="Select03"
                  placeholder="Text"
                  options={options}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol
                title="grid test04"
                required
                $row
                htmlFor="TextField04"
              >
                <FormcontrolItem>
                  <TextField
                    id="TextField04"
                    name="text"
                    type="text"
                    placeholder="Placeholder"
                    $error
                    $errorMessage="Invaild message content"
                  />

                  <TextField
                    id="TextField05"
                    name="text"
                    type="text"
                    placeholder="Placeholder"
                  />

                  <TextField
                    id="TextField06"
                    name="text"
                    type="text"
                    placeholder="Placeholder"
                  />
                </FormcontrolItem>
              </Formcontrol>
            </GridItem>

            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="grid test03" required htmlFor="textarea01">
                <Textarea
                  id="textarea01"
                  name="textarea01"
                  height="100px"
                  defaultValue="Enter long form text here"
                  $guideText="Invaild message content"
                />
              </Formcontrol>
            </GridItem>

            <GridItem>
              <Formcontrol
                title="grid test07"
                required
                $row
                htmlFor="TextField07"
              >
                <TextField
                  id="TextField07"
                  name="text"
                  type="number"
                  placeholder="숫자로 입력하세요"
                  $innerRight="원"
                />
              </Formcontrol>
            </GridItem>
          </Grid>
          <StyledDivide />
          <GuideText>
            <h4>column이 3개 인 경우</h4>
          </GuideText>
          <Grid $columns={3} $gap="12px 60px">
            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
                <TextField
                  id="TextField02"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
                <TextField
                  id="TextField02"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
                <TextField
                  id="TextField02"
                  name="text"
                  type="text"
                  placeholder="Placeholder"
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </GuideBox>

        {/* Form Control */}

        <GuideText>
          <h3>Form Control</h3>
        </GuideText>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>title</td>
              <td>title="아울렛 유형"</td>
              <td>label에 표시될 타이틀 입력</td>
              <td></td>
            </tr>
            <tr>
              <td>htmlFor</td>
              <td>htmlFor="TextField01"</td>
              <td>해당 form 컴포넌트와 연결: 라벨 클릭 시 포커스 표시</td>
              <td>{`<Formcontrol> 에 children 으로 들어갈 컴포넌트의 id 값과 매치해줍니다. `}</td>
            </tr>
            <tr>
              <td>required</td>
              <td>required</td>
              <td>필수 입력 사항</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$row</td>
              <td>$row</td>
              <td>라벨과 form 컴포넌트를 가로로 표현</td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>
        <GuideSubBox>
          {` <Formcontrol title="아울렛 유형" htmlFor="TextField01">
              <TextField id="TextField01" />
             </Formcontrol>
          `}
          <br />
          {` <Formcontrol
                title="충전 제공 방식"
                required
                htmlFor="TextField02"
              >
          `}
          <br />
          {` <Formcontrol title="grid test01" required htmlFor="TextField03">
          `}
          <br />
          {` <Formcontrol
                title="충전 제공 방식"
                required
                $row
                htmlFor="Select01"
              >
          `}
          <br />
          {` <Formcontrol title="grid test02" required $row htmlFor="Select02">
          `}
        </GuideSubBox>

        {/* Grid / Grid Item */}
        <GuideText>
          <h3>Grid / Grid Item</h3>
        </GuideText>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>$columns</td>
              <td>{`$columns={2}`}</td>
              <td>가로로 나누어질 컬럼 수</td>
              <td></td>
            </tr>
            <tr>
              <td>$gap</td>
              <td>{`$gap="12px 128px"`}</td>
              <td>column과 column 사이의 간격</td>
              <td></td>
            </tr>
            <tr style={{ backgroundColor: '#eee' }}>
              <td colSpan={4} style={{ textAlign: 'left', fontWeight: 'bold' }}>
                Grid Item
              </td>
            </tr>
            <tr>
              <td>$colStart</td>
              <td>{`$colStart={1}`}</td>
              <td>
                Grid의 Column이 2개 이상으로 나뉘어 질때 GridItem size의 시작
                부분
              </td>
              <td></td>
            </tr>
            <tr>
              <td>$colEnd</td>
              <td>{`$colEnd={3}`}</td>
              <td>
                Grid의 Column이 2개 이상으로 나뉘어 질때 GridItem size의 끝나는
                부분
              </td>
              <td></td>
            </tr>
          </tbody>
        </GuideTable>
        <GuideSubBox>
          {` <Grid $columns={2} $gap="12px 128px"><GridItem $colStart={1} $colEnd={3}></GridItem></Grid>
          `}
          <br />
          {` <Grid $columns={2} $gap="12px 128px"><GridItem></GridItem><GridItem></GridItem></Grid>
          `}
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default FormControlGuide;

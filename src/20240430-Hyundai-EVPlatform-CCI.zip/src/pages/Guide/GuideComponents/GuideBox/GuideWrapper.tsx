import styled from 'styled-components';
import React from 'react';

export interface GuideWrapperProps {
  children?: React.ReactNode;
}

const StyledWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const GuideWrapper: React.FC<GuideWrapperProps> = ({ children }) => {
  return <StyledWrapper>{children}</StyledWrapper>;
};

export default GuideWrapper;

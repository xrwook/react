import { ReactDatePickerProps, registerLocale } from 'react-datepicker';
import { ko } from 'date-fns/locale/ko';
import 'react-datepicker/dist/react-datepicker.css';
import { useState } from 'react';
import {
  DatePickerContainer,
  DatePickerStyle,
  DatePickerToday,
  DatePickerWrapper,
  DropDownContainer,
  DropDownHeader,
  DropDownList,
  DropDownListContainer,
  ListItem,
  NextButton,
  PrevButton,
} from './StyledDatepicker';
import { getMonth, getYear } from 'date-fns';
import _ from 'lodash';

registerLocale('ko', ko);

const DatePicker = ({ ...props }: ReactDatePickerProps) => {
  const [isOpenMonths, setIsOpenMonths] = useState(false);
  const [isOpenYears, setIsOpenYears] = useState(false);
  const [selectedMonths, setSelectedMonths] = useState(null);
  const [selectedYears, setSelectedYears] = useState(null);

  const [startDate, setStartDate] = useState(new Date());

  const toggling = () => setIsOpenMonths(!isOpenMonths);
  const toggling2 = () => setIsOpenYears(!isOpenYears);

  const onMonthsClicked = (value: any) => () => {
    setSelectedMonths(value);
    setIsOpenMonths(false);
  };

  const onYearsClicked = (value: any) => () => {
    setSelectedYears(value);
    setIsOpenYears(false);
  };

  const years = _.range(1990, getYear(new Date()) + 1, 1);
  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const test = ({ className, children }: any) => {
    return (
      <DatePickerContainer>
        <div className={className}>{children}</div>
        <DatePickerToday>오늘 날짜로 이동</DatePickerToday>
      </DatePickerContainer>
    );
  };

  return (
    <DatePickerWrapper>
      <DatePickerStyle
        {...props}
        calendarContainer={test}
        disabledKeyboardNavigation
        dateFormatCalendar="yyyy년 MM월"
        locale="ko"
        selected={startDate}
        onChange={(date: any) => setStartDate(date)}
        peekNextMonth
        showMonthDropdown
        showYearDropdown
        dropdownMode="select"
        renderCustomHeader={({
          date,
          decreaseMonth,
          increaseMonth,
          prevMonthButtonDisabled,
          nextMonthButtonDisabled,
        }) => (
          <div
            style={{
              margin: 10,
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <PrevButton
              onClick={decreaseMonth}
              disabled={prevMonthButtonDisabled}
            />

            <DropDownContainer onClick={toggling}>
              <DropDownHeader>
                {selectedMonths || months[getMonth(date)]}
              </DropDownHeader>
              {isOpenMonths && (
                <DropDownListContainer style={{ right: '0' }}>
                  <DropDownList>
                    {months.map((option) => (
                      <ListItem
                        onClick={onMonthsClicked(option)}
                        key={Math.random()}
                      >
                        {option}
                      </ListItem>
                    ))}
                  </DropDownList>
                </DropDownListContainer>
              )}
            </DropDownContainer>

            <DropDownContainer onClick={toggling2}>
              <DropDownHeader>
                {selectedYears || [getYear(date)]}
              </DropDownHeader>
              {isOpenYears && (
                <DropDownListContainer style={{ left: '0' }}>
                  <DropDownList>
                    {years.map((option) => (
                      <ListItem
                        onClick={onYearsClicked(option)}
                        key={Math.random()}
                      >
                        {option}
                      </ListItem>
                    ))}
                  </DropDownList>
                </DropDownListContainer>
              )}
            </DropDownContainer>

            <NextButton
              onClick={increaseMonth}
              disabled={nextMonthButtonDisabled}
            />
          </div>
        )}
      >
        {/* <div style={{ color: 'red' }}>Don't forget to check the weather!</div> */}
      </DatePickerStyle>
    </DatePickerWrapper>
  );
};

export default DatePicker;

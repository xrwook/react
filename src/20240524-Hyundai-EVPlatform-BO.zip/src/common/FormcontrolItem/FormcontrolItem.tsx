import React from 'react';
import { FormItemWrap } from './StyledFormcontrolItem';

export interface FormcontrolItemProps {
  children?: React.ReactNode;
  $small?: any;
  $center?: any;
  $none?: any;
}

const FormcontrolItem: React.FC<FormcontrolItemProps> = ({
  children,
  $small,
  $center,
  $none,
}) => {
  return (
    <FormItemWrap $small={$small} $center={$center} $none={$none}>
      {children}
    </FormItemWrap>
  );
};

export default FormcontrolItem;

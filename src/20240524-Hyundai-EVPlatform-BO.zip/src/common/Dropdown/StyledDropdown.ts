import styled, { css } from 'styled-components';
import arrowIcon from '/images/icons/icon-select-arrow.svg';
import arrowActiveIcon from '/images/icons/icon-select-arrow-active.svg';

export const DropdownWrapper = styled.div`
  position: relative;
`;

export const DropdownInput = styled.button<{
  $dropdown: any;
  $readOnly: any;
  $transparent: any;
  $width: any;
}>`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 10px 6px 14px;
  width: ${(props) => props.$width}px;
  height: 32px;
  border: ${(props) =>
    props.disabled
      ? '1px solid #DADCE4'
      : props.$readOnly
        ? '1px solid #DADCE4'
        : props.$transparent
          ? '1px solid transparent'
          : '1px solid #c2c5d2;'};
  border-radius: 4px;
  position: relative;
  background-color: ${(props) =>
    props.disabled
      ? '#F9F9F9'
      : props.$readOnly
        ? '#F9F9F9'
        : props.$transparent
          ? 'transparent'
          : '#fff'};
  pointer-events: ${(props) => (props.$readOnly ? 'none' : '')};
`;

export const ArrowButton = styled.div<{ $dropdown: any }>`
  margin-left: 4px;
  width: 20px;
  height: 20px;
  background-image: url(${(props) =>
    props.$dropdown ? arrowActiveIcon : arrowIcon});

  &:focus {
    transform: ${(props) => (props.$dropdown ? 'rotate(-180deg)' : '')};
  }
`;

export const DropdownText = styled.div<{
  disabled: boolean;
  $dropdown: any;
  selected: any;
  $defaultText: any;
  $allText: any;
}>`
  font-size: 14px;
  line-height: 20px;
  font-weight: ${(props) => (props.$allText ? '500' : '400')};

  color: ${(props) =>
    props.$allText
      ? '#455DD7'
      : props.disabled
        ? '#CDCDCD'
        : props.$dropdown || props.$defaultText || props.selected
          ? '#434860'
          : '#A0A4B6'};
`;

export const DropdownList = styled.ul<{ $day: any; $position: 'up' | null }>`
  display: ${(props) => (props.$day ? 'none' : 'block')};
  position: absolute;
  top: 35px;
  ${(props) =>
    props.$position === 'up' &&
    css`
      top: auto;
      bottom: 40px;
    `}
  width: 100%;
  max-width: 300px;
  height: auto;
  box-shadow: 0 6px 10px #0000000d;
  border: 1px solid #caccd7;
  border-radius: 4px;
  padding: 8px;
  background-color: #fff;
  z-index: 10;
`;

export const DropdownOption = styled.li<{ selected: boolean }>`
  height: 36px;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 14px;
  font-weight: 400;
  color: ${(props) => (props.selected ? '#455DD7' : '#434860')};

  &:hover {
    background-color: #f8f9fb;
  }
`;

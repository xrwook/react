import { Route, Routes } from 'react-router-dom';
import Guide from 'pages/Guide/GuideList';
import CheckBoxGuide from 'pages/Guide/GuideComponents/CheckBoxGuide';
import SelectGuide from 'pages/Guide/GuideComponents/SelectGuide';
import RadioGuide from 'pages/Guide/GuideComponents/RadioGuide';
import ModalGuide from 'pages/Guide/GuideComponents/ModalGuide';
import DatePickerGuide from 'pages/Guide/GuideComponents/DatePickerGuide';
import BreadcrumbGuide from 'pages/Guide/GuideComponents/BreadcrumbGuide';
import EditorGuide from 'pages/Guide/GuideComponents/EditorGuide';
import TextFieldGuide from 'pages/Guide/GuideComponents/TextFieldGuide';
import TextareaGuide from 'pages/Guide/GuideComponents/TextareaGuide';
import ToggleGuide from 'pages/Guide/GuideComponents/ToggleGuide';
import TooltipGuide from 'pages/Guide/GuideComponents/TooltipGuide';
import ButtonGuide from 'pages/Guide/GuideComponents/ButtonGuide';
import TabGuide from 'pages/Guide/GuideComponents/TabGuide';
import LabelsGuide from 'pages/Guide/GuideComponents/LabelsGuide';
import TitleGuide from 'pages/Guide/GuideComponents/TitleGuide';

const GuideRoute = () => {
  return (
    <Routes>
      <Route path="guidelist" element={<Guide />}>
        <Route path="Breadcrumb" element={<BreadcrumbGuide />} />
        <Route path="Button" element={<ButtonGuide />} />
        <Route path="CheckBox" element={<CheckBoxGuide />} />
        <Route path="DatePicker" element={<DatePickerGuide />} />
        <Route path="Editor" element={<EditorGuide />} />
        <Route path="Labels" element={<LabelsGuide />} />
        <Route path="Modal" element={<ModalGuide />} />
        <Route path="Radio" element={<RadioGuide />} />
        <Route path="Select" element={<SelectGuide />} />
        <Route path="Tab" element={<TabGuide />} />
        <Route path="TextField" element={<TextFieldGuide />} />
        <Route path="Textarea" element={<TextareaGuide />} />
        <Route path="Title" element={<TitleGuide />} />
        <Route path="Toggle" element={<ToggleGuide />} />
        <Route path="Tooltip" element={<TooltipGuide />} />
      </Route>
    </Routes>
  );
};

export default GuideRoute;

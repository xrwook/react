import {
  RadioboxWrapper,
  StyledRadio,
  StyledRadioBoxText,
} from './StyledRadio';

export interface RadioBoxProps {
  id?: string;
  name?: any;
  text?: any;
  htmlFor?: any;
  disabled?: any;
  checked?: any;
  className?: any;
  defaultChecked?: any;
  $large?: any;
}

const Radio: React.FC<RadioBoxProps> = ({
  id,
  name,
  text,
  htmlFor,
  disabled,
  checked,
  className,
  defaultChecked,
  $large = false,
}) => {
  return (
    <>
      <RadioboxWrapper>
        <StyledRadio
          type="radio"
          id={id}
          name={name}
          disabled={disabled}
          checked={checked}
          defaultChecked={defaultChecked}
          className={className}
          $large={$large}
        />
        <label htmlFor={htmlFor}>
          {text && (
            <StyledRadioBoxText disabled={disabled}>{text}</StyledRadioBoxText>
          )}
        </label>
      </RadioboxWrapper>
    </>
  );
};

export default Radio;

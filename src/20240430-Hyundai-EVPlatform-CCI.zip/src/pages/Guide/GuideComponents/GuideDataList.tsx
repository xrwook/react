const GuideDataList = [
  {
    depth1: 'Hyindai-EVPlatform-FO',
    below: [
      {
        id: 'Service',
        depth2: '',
        depth3: '',
        depth4: '',
        path: '/service',
        status: '진행',
        create: '2023.04.22',
        update: '2023.04.22',
        log: [{ date: '2024.04.22', text: 'service layout' }],
      },
    ],
  },
];

export default GuideDataList;

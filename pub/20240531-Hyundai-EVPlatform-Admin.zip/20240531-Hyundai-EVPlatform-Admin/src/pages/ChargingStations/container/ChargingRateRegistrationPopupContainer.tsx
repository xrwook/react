import { useState } from 'react';
import Modal from 'common/Modal';
import ModalContent from 'common/Modal/ModalContent';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import AgGrid from 'common/AgGrid/AgGrid';
import { ButtonGroup } from 'common/Button/StyledButton';
import FilterChargingRateRegistrationPopup from '../components/FilterChargingRateRegistrationPopup';
import {
  ChargingRateRegistrationPopupRowData,
  ChargingRateRegistrationPopupcolumnDefs,
} from '../components/detailData';

const ChargingRateRegistrationPopupContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  return (
    <>
      {showModal && (
        <Modal
          width="1200px"
          height="auto"
          oversize
          onClose={() => setShowModal(false)}
        >
          <ModalHeader>충전소 검색</ModalHeader>
          <ModalContent $marginBottom="30px">
            <FilterChargingRateRegistrationPopup />

            <div style={{ marginTop: '24px' }}>
              <AgGrid
                hasCheckbox={true}
                hasGridTop={true}
                noneButton
                nonePerPageSelect
                rowData={ChargingRateRegistrationPopupRowData}
                columnDefs={ChargingRateRegistrationPopupcolumnDefs}
              />
            </div>
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="secondaryGray"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                확인
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingRateRegistrationPopupContainer;

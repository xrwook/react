import { ModalHeaderWrapper } from './StyledModal';

export interface ModalHeaderProps {
  children?: any;
}

const ModalHeader: React.FC<ModalHeaderProps> = ({ children }) => {
  return (
    <>
      <ModalHeaderWrapper>{children}</ModalHeaderWrapper>
    </>
  );
};

export default ModalHeader;

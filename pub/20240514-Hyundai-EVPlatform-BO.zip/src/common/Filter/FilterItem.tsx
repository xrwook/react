import { FilterItemStyle } from './StyledFilter';
export interface FilterItemProps {
  children?: any;
  $search?: any;
  $button?: any;
  className?: any;
}

const FilterItem: React.FC<FilterItemProps> = ({
  children,
  $search,
  $button,
}) => {
  return (
    <FilterItemStyle
      $search={$search}
      $button={$button}
      className={'filter-item'}
    >
      {children}
    </FilterItemStyle>
  );
};

export default FilterItem;

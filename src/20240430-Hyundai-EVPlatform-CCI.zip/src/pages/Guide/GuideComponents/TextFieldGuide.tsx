import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import TextField from 'common/TextField';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const TextFieldGuide = () => {
  return (
    <StyledGuideWrapper>
      <div style={{ padding: '50px' }}>
        <GuideWrapper>
          <GuideText>TextField</GuideText>
          <GuideBox>
            <ul>
              <li>
                <TextField
                  id="TextField01"
                  name="text"
                  type="text"
                  placeholder="입력해주세요"
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <TextField
                  id="TextField02"
                  name="readOnly"
                  type="text"
                  placeholder="입력해주세요"
                  value="readOnly"
                  readOnly
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <TextField
                  id="TextField03"
                  name="disabled"
                  type="text"
                  placeholder="입력해주세요"
                  value="disabled"
                  disabled
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <TextField
                  id="TextField04"
                  name="number"
                  type="number"
                  placeholder="숫자만 입력해주세요"
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <TextField
                  id="TextField05"
                  name="error"
                  type="text"
                  placeholder="Error"
                  $isError
                  errorMessage="errorMessage."
                />
              </li>
              <li style={{ marginTop: '15px' }}>
                <TextField
                  id="TextField06"
                  name="error"
                  type="text"
                  placeholder="Search"
                  $isSearch
                />
              </li>
            </ul>
          </GuideBox>
          <GuideSubBox>
            &lt;TextField id="" name="" type="" placeholder=""&gt; <br />
            &lt;TextField id="" name="" type="" placeholder="" value="" readOnly
            &gt; <br />
            &lt;TextField id="" name="" type="" placeholder="" value="" disabled
            &gt; <br />
            &lt;TextField id="" name="" type="" placeholder="" value="" $isError
            &gt; <br />
            &lt;TextField id="TextField06" name="error" type="text"
            placeholder="Search" $isSearch&gt;
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>id</td>
                <td>id</td>
                <td>id 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>name</td>
                <td>name</td>
                <td>name 입력</td>
                <td>id 값과 일치</td>
              </tr>
              <tr>
                <td>type</td>
                <td>type</td>
                <td>type 타입 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>placeholder</td>
                <td>placeholder</td>
                <td>placeholder 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>disabled</td>
                <td>disabled</td>
                <td>disabled 상태 지정</td>
                <td>-</td>
              </tr>
              <tr>
                <td>$isError</td>
                <td>$isError</td>
                <td>$isError 상태 지정</td>
                <td>errorMessage 입력</td>
              </tr>
              <tr>
                <td>$isSearch</td>
                <td>$isSearch</td>
                <td>$isSearch 형태 지정</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </GuideWrapper>
      </div>
    </StyledGuideWrapper>
  );
};

export default TextFieldGuide;

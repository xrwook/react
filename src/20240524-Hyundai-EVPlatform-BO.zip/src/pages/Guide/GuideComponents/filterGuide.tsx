import styled from 'styled-components';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideText from './GuideBox/GuideText';
import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import TextField from 'common/TextField';
import FilterLabel from 'common/Filter/FilterLabel';
import Select from 'common/Select/Select';
import { useState } from 'react';
import { Option } from 'common/Select/Select';
import SelectSearch from 'common/SelectSearch';
import Dropdown from 'common/Dropdown/Dropdown';

const filterOption = [
  {
    value: 'option01',
    label: 'option01',
  },
  {
    value: 'option02',
    label: 'option02',
  },
  {
    value: 'option03',
    label: 'option03',
  },
  {
    value: '최근 1주일',
    label: '최근 1주일',
  },
];

const DropdownWrap = styled.div`
  button {
    padding-right: 0;
  }
`;

const FilterGuide = () => {
  const [optionSelected, setSelected] = useState<Option[] | null>();
  const handleChange = (selected: Option[]) => {
    setSelected(selected);
  };
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Filter</GuideText>

        <GuideText>
          <h3>필터 5개 이하</h3>
        </GuideText>
        <FilterList useDetailButtons>
          <FilterItem $search>
            <TextField
              id="TextField01"
              name="text"
              type="text"
              placeholder="충전소 이름을 입력 후 검색하세요"
              $search
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>사업자 :</FilterLabel>
            <SelectSearch
              $menuTitle="사업자"
              placeholder="사업자 이름"
              isMulti
              options={filterOption}
              classNamePrefix="react-select"
              $button
              $all={true}
              $transparent
              $checkbox
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>권역 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>충전소 유형 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>시설 형태 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>시설 구분 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>개방 형태 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
        </FilterList>

        <GuideText>
          <h3>필터 6개 이상</h3>
        </GuideText>
        <FilterList useDetailButtons>
          <FilterItem $search>
            <TextField
              id="TextField01"
              name="text"
              type="text"
              placeholder="충전소 이름을 입력 후 검색하세요"
              $search
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>사업자 :</FilterLabel>
            <SelectSearch
              $menuTitle="사업자"
              placeholder="사업자 이름"
              isMulti
              options={filterOption}
              classNamePrefix="react-select"
              $button
              $all={true}
              $transparent
              $checkbox
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>권역 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>충전소 유형 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>시설 형태 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>시설 구분 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>개방 형태 :</FilterLabel>
            <Select
              placeholder="전체"
              options={filterOption}
              classNamePrefix="react-select"
              $transparent
            />
          </FilterItem>
          <FilterItem>
            <FilterLabel>등록 기간 :</FilterLabel>
            <DropdownWrap>
              <Dropdown
                options={filterOption}
                $allText="전체"
                placeholder="전체"
                $day
                $transparent
              />
            </DropdownWrap>
          </FilterItem>
        </FilterList>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default FilterGuide;

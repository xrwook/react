import { LabelStyle, LabelsWrapper } from './StyledLabels';

export interface LabelsProps {
  children?: any;
  $color:
    | 'red'
    | 'blue'
    | 'yellow'
    | 'purple'
    | 'green'
    | 'gray'
    | 'redWhite'
    | 'blueWhite'
    | 'yellowWhite'
    | 'purpleWhite'
    | 'greenWhite'
    | 'grayWhite'
    | 'purpleDark'
    | 'blueDark';
  $size: 'small' | 'medium';
}

const Labels: React.FC<LabelsProps> = ({ children, $color, $size }) => {
  return (
    <LabelsWrapper>
      <LabelStyle $color={$color} $size={$size}>
        {children}
      </LabelStyle>
    </LabelsWrapper>
  );
};

export default Labels;

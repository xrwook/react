import { FilterLabeltyle } from './StyledFilter';

export interface FilterLabelProps {
  children?: any;
}

const FilterLabel: React.FC<FilterLabelProps> = ({ children }) => {
  return <FilterLabeltyle>{children}</FilterLabeltyle>;
};

export default FilterLabel;

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Autocomplete from 'common/Autocomplete/Autocomplete';
// import TestDate from 'common/text';

const AutocompleteGuide = () => {
  const option = [
    {
      value: 'option01option01',
      label: 'option01option01',
    },
    {
      value: 'option02option02',
      label: 'option02option02',
    },
    {
      value: 'option03option03',
      label: 'option03option03',
    },
    {
      value: 'option04option04',
      label: 'option04option04',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>
          Dropdown(datepicker 완료 시 수정 : sample version)
        </GuideText>
        <GuideBox>
          <Autocomplete />
        </GuideBox>
        <GuideSubBox>&lt;Autocomplete /&gt;</GuideSubBox>
        {/* <TestDate /> */}
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default AutocompleteGuide;

import styled, { css } from 'styled-components';
import { AgGridProps } from './AgGrid';
import { AgGridTopProps } from './AgGridTop';

export const AgGridWrap = styled.div<AgGridProps>`
  width: 100%;
`;

export const AgGridContainer = styled.div`
  z-index: 10;
`;

export const AgGridTopStyle = styled.div<AgGridTopProps>`
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 32px;
  ${(props) =>
    props.$marginTop &&
    css`
      margin-top: ${props.$marginTop}px;
    `}
  margin-bottom: 12px;
`;

export const AgGridTopRight = styled.div`
  margin-left: auto;
  display: flex;
  gap: 6px;
`;

export const Total = styled.div`
  font-size: 14px;
  font-weight: 400;
  color: ${(props) => props.theme.color.color8};

  strong {
    color: ${(props) => props.theme.color.primary};
    font-weight: 500;
    margin-left: 4px;
  }
`;

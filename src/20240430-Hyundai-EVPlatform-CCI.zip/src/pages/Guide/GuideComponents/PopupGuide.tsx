import { useState } from 'react';
import GuideWrapper from 'pages/Guide/GuideComponents/GuideBox/GuideWrapper';
import GuideSubBox from 'pages/Guide/GuideComponents/GuideBox/GuideSubBox';
import ModalPopup from 'common/ModalPopup/ModalPopup';
import ModalContent from 'common/ModalPopup/ModalContents/ModalContents';
import ModalFooter from 'common/ModalPopup//ModalFooter/ModalFooter';
import ModalHeader from 'common/ModalPopup/ModalHeader/ModalHeader';
import FullPopup from 'common/FullPopup/FullPopup';
import FullContent from 'common/FullPopup/FullContents';
import FullFooter from 'common/FullPopup/FullFooter';
import FullHeader from 'common/FullPopup/FullHeader';
import ToastPopup from 'common/ToastPopup/ToastPopup';
import ToastContent from 'common/ToastPopup/ToastContents';
import ToastFooter from 'common/ToastPopup/ToastFooter';
import ToastHeader from 'common/ToastPopup/ToastHeader';
import { BasicButton } from 'common/BasicButton/BasicButton';
import ButtonList from 'common/ButtonList';
import useModalScrollLock from 'hooks/usePopuplScrollLock';
import GuideTable from './GuideTable';

const PopupGuide = () => {
  const [modals, setModals] = useState({
    modal01: false,
    modal02: false,
    modal03: false,
  });
  const [isOpen, setIsOpen] = useState(false);
  const [isDisplayed, setIsDisplayed] = useState(true);

  const toggleModal = (modalId: 'modal01' | 'modal02' | 'modal03') => {
    setIsOpen(!modals[modalId]);
    setTimeout(() => {
      setModals((prev) => ({
        ...prev,
        [modalId]: !prev[modalId],
      }));
    }, 150);
    setIsDisplayed(!modals[modalId]);
  };

  // scroll rock
  useModalScrollLock(!Object.values(modals).some((status) => status));

  return (
    <GuideWrapper>
      <div style={{ padding: '50px' }}>
        <div>
          <BasicButton onClick={() => toggleModal('modal01')}>
            Modal Popup
          </BasicButton>
          {modals.modal01 && (
            <ModalPopup
              onClose={() => toggleModal('modal01')}
              isDisplayed={isDisplayed}
              isOpen={isOpen}
            >
              <ModalHeader
                onClose={() => toggleModal('modal01')}
                rightIcon={{
                  icon: 'close',
                  onClick: () => toggleModal('modal01'),
                }}
              >
                Title
              </ModalHeader>
              <ModalContent>
                <div style={{ height: '800px' }}>contents 영역 길어질 경우</div>
              </ModalContent>
              <ModalFooter>
                <ButtonList>
                  <BasicButton>Confirm</BasicButton>
                  <BasicButton
                    variant="tertiary"
                    onClick={() => toggleModal('modal01')}
                  >
                    Cancel
                  </BasicButton>
                </ButtonList>
              </ModalFooter>
            </ModalPopup>
          )}

          <GuideSubBox>
            header에 rightIcon icon 변경 가능 (BasicButton에서 case 추가)
            <br /> ex) icon: 'more', icon: 'back' 등
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>onClose</td>
                <td>onClose</td>
                <td>onClose 해당 팝업 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>isDisplayed</td>
                <td>isDisplayed</td>
                <td>isDisplayed 상태 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>rightIcon</td>
                <td>rightIcon</td>
                <td>오른쪽 상단 아이콘 지정</td>
                <td>icon: 'more', icon: 'back' 등</td>
              </tr>
              <tr>
                <td>onClick</td>
                <td>onClick</td>
                <td>onClick 해당 팝업 입력</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </div>

        <div style={{ marginTop: '30px' }}>
          <BasicButton onClick={() => toggleModal('modal02')}>
            Full Popup
          </BasicButton>
          {modals.modal02 && (
            <FullPopup
              onClose={() => toggleModal('modal02')}
              isDisplayed={isDisplayed}
            >
              <FullHeader
                onClose={() => toggleModal('modal02')}
                leftIcon={{
                  icon: 'back',
                  onClick: () => toggleModal('modal02'),
                }}
                rightIcon={{
                  icon: 'close',
                  onClick: () => toggleModal('modal02'),
                }}
              >
                Title
              </FullHeader>
              <FullContent>
                <div style={{ height: '800px' }}>contents 영역 길어질 경우</div>
              </FullContent>
              <FullFooter>
                <ButtonList>
                  <BasicButton>Confirm</BasicButton>
                  <BasicButton
                    variant="tertiary"
                    onClick={() => toggleModal('modal02')}
                  >
                    Cancel
                  </BasicButton>
                </ButtonList>
              </FullFooter>
            </FullPopup>
          )}

          <GuideSubBox>
            header에 rightIcon, leftIcon icon 변경 가능 (BasicButton에서 case
            추가)
            <br /> ex) icon: 'more', icon: 'back' 등
          </GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>onClose</td>
                <td>onClose</td>
                <td>onClose 해당 팝업 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>isDisplayed</td>
                <td>isDisplayed</td>
                <td>isDisplayed 상태 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>leftIcon</td>
                <td>leftIcon</td>
                <td>왼쪽 상단 아이콘 지정</td>
                <td>icon: 'more', icon: 'back' 등</td>
              </tr>
              <tr>
                <td>rightIcon</td>
                <td>rightIcon</td>
                <td>오른쪽 상단 아이콘 지정</td>
                <td>icon: 'more', icon: 'back' 등</td>
              </tr>
              <tr>
                <td>onClick</td>
                <td>onClick</td>
                <td>onClick 해당 팝업 입력</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </div>

        <div style={{ marginTop: '30px' }}>
          <BasicButton onClick={() => toggleModal('modal03')}>
            Toast Popup
          </BasicButton>
          {modals.modal03 && (
            <ToastPopup
              onClick={() => toggleModal('modal03')}
              isDisplayed={isDisplayed}
            >
              <ToastHeader>Title</ToastHeader>
              <ToastContent>
                <div style={{ height: '800px' }}>Contents 영역 길어질 경우</div>
              </ToastContent>
              <ToastFooter>
                <ButtonList>
                  <BasicButton>Confirm</BasicButton>
                  <BasicButton
                    variant="tertiary"
                    onClick={() => toggleModal('modal03')}
                  >
                    Cancel
                  </BasicButton>
                </ButtonList>
              </ToastFooter>
            </ToastPopup>
          )}

          <GuideSubBox>dim 배경 클릭 시 닫힘</GuideSubBox>

          <GuideTable>
            <colgroup>
              <col width="20%" />
              <col width="30%" />
              <col width="30%" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th>props</th>
                <th>형식</th>
                <th>설명</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>onClose</td>
                <td>onClose</td>
                <td>onClose 해당 팝업 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>isDisplayed</td>
                <td>isDisplayed</td>
                <td>isDisplayed 상태 입력</td>
                <td>-</td>
              </tr>
              <tr>
                <td>onClick</td>
                <td>onClick</td>
                <td>onClick 해당 팝업 입력</td>
                <td>-</td>
              </tr>
            </tbody>
          </GuideTable>
        </div>
      </div>
    </GuideWrapper>
  );
};

export default PopupGuide;

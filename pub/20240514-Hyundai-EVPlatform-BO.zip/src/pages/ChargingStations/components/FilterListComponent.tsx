import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import FilterLabel from 'common/Filter/FilterLabel';
import TextField from 'common/TextField';
import Select from 'common/Select/Select';
import Dropdown from 'common/Dropdown/Dropdown';
import SelectSearch from 'common/SelectSearch/';
import { filterOption } from './data';

const FilterListComponent: React.FC = () => {
  return (
    <FilterList useDetailButtons>
      <FilterItem $search>
        <TextField
          id="TextField01"
          name="text"
          type="text"
          placeholder="충전소 이름을 입력 후 검색하세요"
          $search
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>사업자 :</FilterLabel>
        <SelectSearch
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $button
          $checkbox
          $menuTitle="사업자"
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>권역 :</FilterLabel>
        <Select
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>충전소 유형 :</FilterLabel>
        <Select
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>시설 형태 :</FilterLabel>
        <Select
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>시설 구분 :</FilterLabel>
        <Select
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>개방 형태 :</FilterLabel>
        <Select
          placeholder="전체"
          options={filterOption}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>등록 기간 :</FilterLabel>
        <Dropdown
          options={filterOption}
          defaultText="전체"
          placeholder="전체"
          $day
          $transparent
        />
      </FilterItem>
    </FilterList>
  );
};

export default FilterListComponent;

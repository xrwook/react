import styled from 'styled-components';
import arrowIcon from '/images/icons/icon-select-arrow.svg';

export const DropdownWrapper = styled.div`
  position: relative;
`;

export const DropdownInput = styled.button<{
  $dropdown: any;
  $readOnly: any;
  $transparent: any;
}>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px 6px 14px;
  width: auto;
  /* min-width: 120px; */
  height: 32px;
  border: ${(props) =>
    props.disabled
      ? '1px solid #DADCE4'
      : props.$readOnly
        ? '1px solid #DADCE4'
        : props.$transparent
          ? '1px solid transparent'
          : '1px solid #c2c5d2;'};
  border-radius: 4px;
  position: relative;
  background-color: ${(props) =>
    props.disabled
      ? '#F9F9F9'
      : props.$readOnly
        ? '#F9F9F9'
        : props.$transparent
          ? 'transparent'
          : '#fff'};
  pointer-events: ${(props) => (props.$readOnly ? 'none' : '')};
`;

export const ArrowButton = styled.div<{ $dropdown: any }>`
  margin-left: 4px;
  width: 20px;
  height: 20px;
  transform: ${(props) => (props.$dropdown ? 'rotate(-180deg)' : '')};
  background: url(${arrowIcon}) no-repeat;
`;

export const DropdownText = styled.div<{
  disabled: boolean;
  $dropdown: any;
  selected: any;
  $defaultText: any;
}>`
  font-size: 14px;
  line-height: 20px;
  color: ${(props) =>
    props.disabled
      ? '#CDCDCD'
      : props.$dropdown || props.$defaultText
        ? '#434860'
        : props.selected
          ? '#455DD7'
          : '#A0A4B6'};
`;

export const DropdownList = styled.ul<{ $day: any }>`
  display: ${(props) => (props.$day ? 'none' : 'block')};
  position: absolute;
  top: 35px;
  width: 100%;
  max-width: 300px;
  height: auto;
  box-shadow: 0 6px 10px #0000000d;
  border: 1px solid #caccd7;
  border-radius: 4px;
  padding: 8px;
  background-color: #fff;
  z-index: 10;
`;

export const DropdownOption = styled.li`
  height: 36px;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 14px;
  font-weight: 400;
  color: #434860;

  &:hover {
    background-color: #f8f9fb;
  }
`;

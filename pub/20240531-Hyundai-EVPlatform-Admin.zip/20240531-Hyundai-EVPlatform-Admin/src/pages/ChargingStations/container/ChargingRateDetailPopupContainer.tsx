import { useState } from 'react';
import Modal from 'common/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';
import Button from 'common/Button';
import AgGrid from 'common/AgGrid/AgGrid';
import { ButtonGroup } from 'common/Button/StyledButton';
import { FareGuide, FareGuideText } from '../styled/StyledChargingStations';
import {
  ChargingRateDetailFarePopupRowData,
  ChargingRateDetailFarePopupcolumnDefs,
} from '../components/detailData';

const ChargingRateDetailPopupContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  return (
    <>
      {showModal && (
        <Modal
          width="600px"
          height="auto"
          oversize
          onClose={() => setShowModal(false)}
        >
          <ModalHeader>요금제 복사</ModalHeader>
          <ModalContent $marginBottom="30px">
            <FareGuideText>
              아래 요금제 정보 중, 복사가 필요한 항목을 선택하세요.
            </FareGuideText>
            <FareGuide>
              요금제명은 복사할 수 없으며, 등록 시 신규 요금제명을 입력하셔야
              합니다.
              <br />
              <div style={{ marginTop: '4px' }}>
                등록 시 선택한 항목의 상세 내용을 수정할 수 없습니다.
              </div>
            </FareGuide>
            <AgGrid
              rowData={ChargingRateDetailFarePopupRowData}
              columnDefs={ChargingRateDetailFarePopupcolumnDefs}
            />
          </ModalContent>
          <ModalFooter>
            <ButtonGroup $gap={8} $direction={'row'}>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="secondaryGray"
                $width={65}
              >
                취소
              </Button>
              <Button
                onClick={() => {}}
                $size="large"
                $variant="primary"
                $width={65}
              >
                복사
              </Button>
            </ButtonGroup>
          </ModalFooter>
        </Modal>
      )}
    </>
  );
};

export default ChargingRateDetailPopupContainer;

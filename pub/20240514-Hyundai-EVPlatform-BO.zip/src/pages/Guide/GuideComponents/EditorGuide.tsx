import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Editor from 'common/Editor';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const EditorGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Editor</GuideText>
        <GuideBox>
          <Editor height="auto" />
        </GuideBox>
        <GuideSubBox>&lt;Editor height="auto"" /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default EditorGuide;

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Home_ } from 'common/Tab/Home';
import { AxiosQuery } from 'pages/Subpage/AxiosQuery';
import { ReactQuery } from 'pages/Subpage/ReactQuery';
import Home from 'pages/Home';
import PrivateRoute from 'routes/PrivateRoute';
import PublicRoute from 'routes/PublicRoute';
import React from 'react';
import { ServiceType } from 'types/serviceType';
import GuideRoute from './GuideRoute';
import Test from '../pages/Subpage/test';
import Chart from '../pages/Subpage/chart';
import Grid from '../pages/Grid';
import Editor from '../pages/Editor';
import SassBuy from '../pages/Saas/SassBuy';
import { Layout } from '../common/Tab/Layout';
import Articles from '../pages/Articles';

export interface RouterProps {
  serviceType: ServiceType;
}

const Router: React.FC<RouterProps> = () => (
  <BrowserRouter>
    <Routes>
      <Route
        path="/"
        element={
          <PublicRoute>
            <Home />
          </PublicRoute>
        }
      />

      <Route
        path="/buy"
        element={
          <PublicRoute>
            <SassBuy />
          </PublicRoute>
        }
      />

      <Route
        path="/tab"
        element={
          <>
            <Articles />
            <Layout />
          </>
        }
      >
        {/*<Route*/}
        {/*  path="/tab"*/}
        {/*  element={*/}
        {/*    <PrivateRoute>*/}
        {/*/!* <Articles /> *!/*/}
        {/*      /!*<Layout />*!/*/}
        {/*    </PrivateRoute>*/}
        {/*  }*/}
        {/*>*/}
        <Route index element={<Home_ />} />
        <Route path="axios-query" element={<AxiosQuery />} />
        <Route path="react-query" element={<ReactQuery />} />
      </Route>
      <Route
        path="/test"
        element={
          <>
            <Test />
            <Chart />
          </>
        }
      />
      <Route path="/grid" element={<Grid />} />
      <Route path="/editor" element={<Editor />} />
    </Routes>
    {/* GuideRoute 추가 */}
    <GuideRoute />
  </BrowserRouter>
);

export default Router;

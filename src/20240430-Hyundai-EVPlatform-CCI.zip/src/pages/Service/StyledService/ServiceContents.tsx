import styled from 'styled-components';

export const ServiceContentsWrap = styled.div`
  position: relative;
  padding: 30px;
  box-sizing: border-box;
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  align-items: stretch;
`;

export const ServiceContentsBox = styled.div`
  height: 100%;
`;

import { Route, Routes, Navigate } from 'react-router-dom';
import Guide from 'pages/Guide/GuideList';
import Button from 'pages/Guide/GuideComponents/ButtonGuide';
import Progress from 'pages/Guide/GuideComponents/ProgressGuide';
import DatePicker from 'pages/Guide/GuideComponents/DatePickerGuide';
import CheckBox from 'pages/Guide/GuideComponents/CheckBoxGuide';
import RadioBox from 'pages/Guide/GuideComponents/RadioBoxGuide';
import Switch from 'pages/Guide/GuideComponents/SwitchGuide';
import TextField from 'pages/Guide/GuideComponents/TextFieldGuide';
import SelectBox from 'pages/Guide/GuideComponents/SelectBoxGuide';
import KeyValue from 'pages/Guide/GuideComponents/KeyValue';
import Popup from 'pages/Guide/GuideComponents/PopupGuide';
import Layout from 'pages/Service/Service';
import PublishingList from 'pages/Guide/PublishingList';
import GuideDataList from 'pages/Guide/GuideComponents/GuideDataList';

const GuideRoute = () => {
  return (
    <Routes>
      <Route path="guidelist" element={<Guide />}>
        <Route index element={<Navigate replace to="progress" />} />
        <Route path="progress" element={<Progress />} />
        <Route path="button" element={<Button />} />
        <Route path="DatePicker" element={<DatePicker />} />
        <Route path="CheckBox" element={<CheckBox />} />
        <Route path="RadioBox" element={<RadioBox />} />
        <Route path="Switch" element={<Switch />} />
        <Route path="TextField" element={<TextField />} />
        <Route path="SelectBox" element={<SelectBox />} />
        <Route path="KeyValue" element={<KeyValue />} />
        <Route path="layout" element={<Layout />} />
        <Route path="popup" element={<Popup />} />
      </Route>
      <Route
        path="publishinglist"
        element={<PublishingList data={GuideDataList} />}
      />
    </Routes>
  );
};

export default GuideRoute;

import styled from 'styled-components';

export const StyledPagination = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  margin-top: 32px;
  .paging {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 32px;
    height: 32px;
    font-size: 14px;
    font-weight: 500;
    color: #575e7d;
    border-radius: 50%;
    &.active {
      color: #5755ff;
      background-color: rgba(98, 31, 255, 0.05);
    }
    &:hover:not(.active) {
      background-color: #f0f1f4;
    }
    &:active:not(.active) {
      background-color: #eaebed;
    }
  }
`;

export const PaginationNavButton = styled.button`
  width: 32px;
  height: 32px;
  border-radius: 4px;

  &:disabled {
    pointer-events: none;
  }

  &:hover {
    background-color: #f0f1f4;
  }

  &:active {
    background-color: #eaebed;
  }
`;

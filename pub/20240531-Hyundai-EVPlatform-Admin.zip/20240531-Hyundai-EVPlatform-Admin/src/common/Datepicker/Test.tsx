import { useState } from 'react';
import { ko } from 'date-fns/locale/ko';
import 'react-datepicker/dist/react-datepicker.css';
import { ReactDatePickerProps, registerLocale } from 'react-datepicker';
import {
  DatePickerStyle,
  DatePickerWrapper,
  DropDownContainer,
  DropDownHeader,
  DropDownList,
  DropDownListContainer,
  ListItem,
  PrevButton,
} from './StyledDatepicker';
import _ from 'lodash';
import { getYear } from 'date-fns';

registerLocale('ko', ko);

const Test = ({ todayButton, ...props }: ReactDatePickerProps) => {
  const [isOpenYears, setIsOpenYears] = useState(false);

  const [selectedYears, setSelectedYears] = useState(null);

  const toggling2 = () => setIsOpenYears(!isOpenYears);

  const onYearsClicked = (value: any) => () => {
    setSelectedYears(value);
    setIsOpenYears(false);
  };

  const years = _.range(1990, getYear(new Date()) + 1, 1);

  return (
    <>
      <DatePickerWrapper>
        <DatePickerStyle
          {...props}
          disabledKeyboardNavigation
          dateFormatCalendar="YYYY-MM-DD"
          locale="ko"
          showMonthDropdown
          showYearDropdown
          dropdownMode="select"
          todayButton={todayButton}
          renderCustomHeader={({ date, decreaseMonth, changeYear }) => (
            <div
              style={{
                margin: 10,
                display: 'flex',
                justifyContent: 'center',
              }}
            >
              <PrevButton onClick={decreaseMonth} />

              {/* <select
                value={getYear(date)}
                onChange={({ target: { value } }: any) =>
                  changeYear(Number(value))
                }
              >
                {years.map((option: any) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select> */}

              <DropDownContainer onClick={toggling2}>
                <DropDownHeader className={` ${isOpenYears ? 'open' : ''}`}>
                  {selectedYears || [date.getFullYear()]}년
                </DropDownHeader>
                {isOpenYears && (
                  <DropDownListContainer>
                    <DropDownList
                      value={getYear(date)}
                      onChange={({ target: { value } }: any) =>
                        changeYear(Number(value))
                      }
                    >
                      {years.map((option: any) => (
                        <ListItem
                          onClick={onYearsClicked(option)}
                          value={option}
                          key={option}
                        >
                          {option}
                        </ListItem>
                      ))}
                    </DropDownList>
                  </DropDownListContainer>
                )}
              </DropDownContainer>
            </div>
          )}
        />
      </DatePickerWrapper>
    </>
  );
};

export default Test;

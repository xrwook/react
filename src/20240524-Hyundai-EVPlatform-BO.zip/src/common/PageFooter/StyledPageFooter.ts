import styled from 'styled-components';

export const PageFooterWrapper = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  width: 100%;
  padding: 40px 0 0;
  margin: 24px 0 auto;
  border-top: 1px solid #d9d9d9;
`;

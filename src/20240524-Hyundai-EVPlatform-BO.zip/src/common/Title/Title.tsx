import {
  TitleGuide,
  TitleLayout,
  TitleMain,
  TitleRight,
  TitleSub,
  TitleTop,
} from './StyledTitle';

export interface TitleProps {
  titlemain?: string;
  $titlesub?: string;
  $titleguide?: boolean;
  $titleGuideText?: string;
  children?: React.ReactNode;
  $pagetitle?: boolean;
}

const Title: React.FC<TitleProps> = ({
  titlemain,
  $titlesub,
  $titleguide,
  children,
  $pagetitle,
  $titleGuideText = '표시는 필수 입력항목입니다.',
}) => {
  return (
    <TitleLayout>
      <TitleTop $pagetitle={$pagetitle}>
        <TitleMain $pagetitle={$pagetitle}>{titlemain}</TitleMain>
        <TitleRight>
          {children}
          <TitleGuide $titleguide={$titleguide}>{$titleGuideText}</TitleGuide>
        </TitleRight>
      </TitleTop>
      <TitleSub $titlesub={$titlesub}>{$titlesub}</TitleSub>
    </TitleLayout>
  );
};

export default Title;

import Router from './routes';
import Header from './common/Header';
import { findServiceTypeByUserAgent } from './utils/validation';


export default function App() {
  console.log('userAgent:', navigator.userAgent);
  console.log('test:',
    findServiceTypeByUserAgent(),
  );
  return (
    <>
      <div className="App font-mono h-screen">
        <Header />
        <Router serviceType={findServiceTypeByUserAgent()} />
      </div>
    </>
  );
}

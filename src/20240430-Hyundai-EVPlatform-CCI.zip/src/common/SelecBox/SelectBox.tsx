import React, { useState } from 'react';
import styled from 'styled-components';
import ToastPopup from 'common/ToastPopup/ToastPopup';
import ToastHeader from 'common/ToastPopup/ToastHeader/ToastHeader';
import ToastContent from 'common/ToastPopup/ToastContents/ToastContents';
import ArrowDown from 'style/assets/images/common/btn_arrow_down.svg';
import useModalScrollLock from 'hooks/usePopuplScrollLock';

const SelectWrapper = styled.div`
  position: relative;
  display: inline-block;
  width: 200px;
`;

const SelectInput = styled.div`
  padding: 8px 30px 8px 10px;
  width: 100%;
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
  color: #000;
  border: 1px solid #e3e3e3;
  border-radius: 4px;
  background-color: #fff;
  cursor: pointer;
`;

const ArrowButton = styled.div`
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  background: url(${ArrowDown}) no-repeat center;
  pointer-events: none;
`;

const SelectText = styled.div`
  font-size: 15px;
`;

interface Option {
  value: string;
  label: string;
}

interface SelectBoxProps {
  options: Option[];
  placeholder?: string;
  header?: React.ReactNode;
  content?: React.ReactNode;
}

const SelectBox: React.FC<SelectBoxProps> = ({
  options,
  placeholder,
  header,
  content,
}) => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState('');

  useModalScrollLock(!isPopupOpen);

  const handleSelect = (option: Option) => {
    setSelectedValue(option.label);
    setIsPopupOpen(false);
  };

  return (
    <SelectWrapper>
      <SelectInput onClick={() => setIsPopupOpen(true)}>
        <ArrowButton aria-hidden="true" />
        <SelectText>{selectedValue || placeholder}</SelectText>
      </SelectInput>
      {isPopupOpen && (
        <ToastPopup
          onClick={() => setIsPopupOpen(false)}
          isDisplayed={isPopupOpen}
        >
          <ToastHeader>{header}</ToastHeader>
          <ToastContent>
            {content}
            <ul>
              {options.map((option) => (
                <li key={option.value} onClick={() => handleSelect(option)}>
                  <button
                    type="button"
                    style={{
                      padding: '30px 0',
                      width: '100%',
                      textAlign: 'left',
                    }}
                  >
                    {option.label}
                  </button>
                </li>
              ))}
            </ul>
          </ToastContent>
        </ToastPopup>
      )}
    </SelectWrapper>
  );
};

export default SelectBox;

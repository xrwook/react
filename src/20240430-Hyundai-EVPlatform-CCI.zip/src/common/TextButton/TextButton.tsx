import React from 'react';
import styled from 'styled-components';
import IconArrowRight from 'style/assets/images/common/icon-arrow_right.svg';
import IconNotice from 'style/assets/images/common/icon-notice.svg';

const StyledTextButton = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 500;
  border: 1px solid transparent;
  box-sizing: border-box;
  font-size: 15px;
  line-height: 1.25rem;
  color: ${(props) => props.color || 'none'};
  padding: 0;
  text-decoration: underline;
  text-underline-offset: 5px;
`;

const Icon = styled.img<{ $iconPosition: string }>`
  margin-left: ${(props) => (props.$iconPosition === 'right' ? '5px' : '0')};
  margin-right: ${(props) => (props.$iconPosition === 'left' ? '5px' : '0')};
`;

interface TextButtonProps {
  children: React.ReactNode;
  disabled?: boolean;
  color?: string;
  onClick?: () => void;
  icon?: string;
  iconPosition?: 'left' | 'right';
}

const Icons: Record<string, string> = {
  IconArrowRight,
  IconNotice,
};

const TextButton: React.FC<TextButtonProps> = ({
  children,
  disabled,
  onClick,
  color,
  icon,
  iconPosition = 'right',
}) => {
  const iconSrc = icon ? Icons[icon] : undefined;

  const content = (
    <>
      {iconSrc && iconPosition === 'left' && (
        <Icon src={iconSrc} alt={`${icon} Icon`} $iconPosition="left" />
      )}
      {children}
      {iconSrc && iconPosition === 'right' && (
        <Icon src={iconSrc} alt={`${icon} Icon`} $iconPosition="right" />
      )}
    </>
  );

  return (
    <StyledTextButton disabled={disabled} color={color} onClick={onClick}>
      {content}
    </StyledTextButton>
  );
};

export default TextButton;

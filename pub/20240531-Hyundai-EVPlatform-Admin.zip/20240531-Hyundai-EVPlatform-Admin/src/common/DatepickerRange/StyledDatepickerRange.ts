import styled, { createGlobalStyle } from 'styled-components';
import calenderIcon from '/images/icons/icon-datepicker.svg';

export const GlobalStyles = createGlobalStyle` 
input {
  cursor: pointer;
}
`;

export const DatePickerWrap = styled.div`
  display: flex;
  align-items: center;
`;

export const DatepickerInputWrapper = styled.div`
  position: relative;
  width: 100%;

  &::after {
    content: '';
    position: absolute;
    display: inline-block;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: url(${calenderIcon}) no-repeat;
  }
`;

export const DatepickerInput = styled.input<{ options?: any }>`
  flex: 1;
  display: block;
  width: 100%;
  height: 32px;
  padding: 5px 9px;
  font-size: 14px;
  line-height: 20px;
  color: #333;
  font-weight: 500;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;

  &::placeholder {
    font-size: 14px;
    line-height: 20px;
    color: #8d96a1;
    font-weight: 500;
  }

  &:focus {
    border: 1px solid blue;
    outline: none;
  }

  &:disabled {
    pointer-events: none;
  }
`;

export const DatepickerBottom = styled.div`
  height: 74px;
  padding: 18px 0 24px 0;
  margin-top: 25px;
  border-top: 1px solid #d9d9d9;
`;

export const ButtonWrap = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;

  > button:first-child {
    padding: 0;
  }
`;

export const DatepickerLine = styled.div`
  width: 6px;
  height: 1px;
  margin: 0 5px;
  background-color: #d9d9d9;
`;

import { Status, StatusColor, StatusText } from './StyledCard';

export interface CardStatusProps {
  status?: any;
  $color: 'purple' | 'blue' | 'green' | 'gray' | 'yellow' | 'red';
}

const CardStatus: React.FC<CardStatusProps> = ({ status, $color }) => {
  return (
    <Status>
      <StatusColor $color={$color} />
      <StatusText>{status}</StatusText>
    </Status>
  );
};

export default CardStatus;

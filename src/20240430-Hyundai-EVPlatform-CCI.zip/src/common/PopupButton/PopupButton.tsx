import React from 'react';
import styled from 'styled-components';
import backIcon from 'style/assets/images/common/keyboard_arrow_left.svg';
import closeIcon from 'style/assets/images/common/icon-close.svg';
import moreIcon from 'style/assets/images/common/icon-more.svg';

const ButtonIcon = styled.button<{ $icon: string }>`
  width: 24px;
  height: 24px;
  background: url(${(props) => props.$icon}) center/contain no-repeat;
`;

export interface ButtonIconProps {
  icon: 'back' | 'close' | 'more';
  onClick: () => void;
}

const PopupButton: React.FC<ButtonIconProps> = ({ icon, onClick }) => {
  let iconImage;
  switch (icon) {
    case 'back':
      iconImage = backIcon;
      break;
    case 'close':
      iconImage = closeIcon;
      break;
    case 'more':
      iconImage = moreIcon;
      break;
    default:
      iconImage = backIcon;
  }

  const handleClick = () => {
    if (icon === 'close') {
      onClick();
    }
    if (icon === 'back') {
      window.history.back();
    }
  };

  return <ButtonIcon $icon={iconImage} onClick={handleClick} type="button" />;
};

export default PopupButton;

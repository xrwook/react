import Button from 'common/Button/Button';
import { RenderCommonWrap } from '../styled/StyledChargingStations';

export interface ChargingStationsButtonRenderProps {
  buttonName?: any;
  buttonType?: any;
}

const ChargingStationsButtonRender: React.FC<
  ChargingStationsButtonRenderProps
> = ({ buttonName, buttonType }) => {
  return (
    <RenderCommonWrap>
      {buttonName && (
        <Button $size="mini" $variant={buttonType} onClick={() => {}}>
          {buttonName}
        </Button>
      )}
    </RenderCommonWrap>
  );
};

export default ChargingStationsButtonRender;

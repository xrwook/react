import React from 'react';
import styled from 'styled-components';

const ModalContentWrapper = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 20px 30px 24px 30px;
`;

export interface ModalContentProps {
  children?: React.ReactNode;
}

const ModalContent: React.FC<ModalContentProps> = ({ children }) => {
  return <ModalContentWrapper>{children}</ModalContentWrapper>;
};

export default ModalContent;

import { ModalGuide, ModalHeaderFlex, ModalHeaderWrapper } from './StyledModal';

export interface ModalHeaderProps {
  children?: any;
  $modalguide?: any;
  $ModalGuideText?: any;
}

const ModalHeader: React.FC<ModalHeaderProps> = ({
  children,
  $modalguide,
  $ModalGuideText,
}) => {
  return (
    <>
      <ModalHeaderWrapper>
        <ModalHeaderFlex>
          {children}
          {$modalguide && (
            <ModalGuide $modalguide={$modalguide}>{$ModalGuideText}</ModalGuide>
          )}
        </ModalHeaderFlex>
      </ModalHeaderWrapper>
    </>
  );
};

export default ModalHeader;

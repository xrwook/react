import styled from 'styled-components';

const ToggleWrapper = styled.label`
  display: flex;
  align-items: center;
`;

const Switch = styled.div`
  position: relative;
  width: 26px;
  height: 17px;
  background-color: ${(props) => props.theme.color.gray4};
  border-radius: 8.5px;
  transition: 300ms all;

  &:before {
    transition: 300ms all;
    content: '';
    position: absolute;
    width: 13px;
    height: 13px;
    border-radius: 50%;
    top: 2px;
    left: 2px;
    background: ${(props) => props.theme.color.white};
    transform: translateX(0);
  }
`;

const Input = styled.input`
  opacity: 0;
  position: absolute;

  &:checked + ${Switch} {
    background: ${(props) => props.theme.color.primary};

    &:before {
      transform: translateX(9px);
    }
  }
  &:checked:disabled + ${Switch} {
    background: ${(props) => props.theme.color.gray2};
  }

  &:disabled + ${Switch} {
    background-color: ${(props) => props.theme.color.gray2};
  }
`;

const Label = styled.span<ToggleProps>`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) => (props.disabled ? '#CDCDCD' : '#434860')};
  padding-left: 8px;
`;

export interface ToggleProps {
  disabled?: any;
  label?: any;
  checked?: any;
  defaultChecked?: any;
  onChange?: any;
}

const Toggle: React.FC<ToggleProps> = ({
  disabled,
  label,
  defaultChecked,
  checked,
  onChange,
}) => {
  return (
    <ToggleWrapper>
      <Input
        checked={checked}
        type="checkbox"
        onChange={onChange}
        disabled={disabled}
        defaultChecked={defaultChecked}
      />
      <Switch />
      {label && <Label disabled={disabled}>{label}</Label>}
    </ToggleWrapper>
  );
};

export default Toggle;

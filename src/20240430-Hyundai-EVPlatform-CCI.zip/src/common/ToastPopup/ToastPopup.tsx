import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes`
  0% { opacity: 0; }
  100% { opacity: 1; }
`;

const fadeOut = keyframes`
  0% { opacity: 1; }
  100% { opacity: 0; }
`;

const slideUp = keyframes`
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
`;

const slideDown = keyframes`
  from { transform: translateY(0); }
  to { transform: translateY(100%); }
`;

const ToastDimWrap = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const DimWrapper = styled.div<{ $isDisplayed: boolean }>`
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  background-color: #00000099;
  z-index: 999;
  display: ${(props) => (props.$isDisplayed ? 'flex' : 'none')} 0.3s ease
    forwards;
  animation: ${(props) => (props.$isDisplayed ? fadeIn : fadeOut)} 0.4s ease
    forwards;
`;

const ToastBox = styled.div<{ $isOpen: boolean; $isDisplayed: boolean }>`
  display: flex;
  flex-direction: column;
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  max-height: 60vh;
  border-radius: 10px 10px 0 0;
  background-color: #ffffff;
  animation: ${(props) => (props.$isDisplayed ? slideUp : slideDown)} 0.3s ease
    forwards;
  z-index: 1000;
`;

interface ToastPopupProps {
  children?: React.ReactNode;
  onClick: () => void;
  isDisplayed: boolean;
  isFadingOut?: boolean;
}

const ToastPopup: React.FC<ToastPopupProps> = ({
  children,
  onClick,
  isDisplayed,
}) => {
  const [$isOpen, setIsOpen] = useState(true);
  const handleClose = () => {
    setIsOpen(false);
    setTimeout(() => onClick(), 100);
  };

  return (
    <ToastDimWrap onClick={handleClose}>
      <DimWrapper $isDisplayed={isDisplayed}>
        <ToastBox
          $isOpen={$isOpen}
          $isDisplayed={isDisplayed}
          onClick={(e) => e.stopPropagation()}
        >
          {children}
        </ToastBox>
      </DimWrapper>
    </ToastDimWrap>
  );
};
export default ToastPopup;

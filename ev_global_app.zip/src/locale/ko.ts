export default {
    common: {
        home: '홈으로',
    },
};
  
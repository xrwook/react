const SassBuy = () => {
  return (
    <>
      <div className="m-auto w-[90%] md:w-[30%]">
        <p className="text-center text-sm mb-2">SAAS</p>
        <p className="text-center text-sm mb-3">구매</p>
      </div>
    </>
  );
};

export default SassBuy;

import styled, { css } from 'styled-components';
import { AgGridProps } from './AgGrid';
import { AgGridTopProps } from './AgGridTop';

export const AgGridWrap = styled.div<AgGridProps>`
  width: 100%;
`;

export const AgGridContainer = styled.div`
  z-index: 10;
`;

export const AgGridTopStyle = styled.div<AgGridTopProps>`
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 32px;
  ${(props) =>
    props.$marginTop &&
    css`
      margin-top: ${props.$marginTop}px;
    `}
  margin-bottom: 12px;
`;

export const AgGridTopRight = styled.div`
  margin-left: auto;
  display: flex;
  gap: 6px;
`;

export const Total = styled.div`
  font-size: 14px;
  font-weight: 400;
  color: ${(props) => props.theme.color.color8};

  strong {
    color: ${(props) => props.theme.color.primary};
    font-weight: 500;
    margin-left: 4px;
  }

  & + & {
    margin-left: 12px;
  }
`;

export const AgGridTooltipWrap = styled.div`
  position: relative;
  bottom: -10px;
  right: 50%;
  width: max-content;
  border-radius: 6px;
  padding: 2px 8px;
  background-color: rgba(40, 46, 56, 0.9);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: #fff;

  &::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 50%;
    transform: translateX(-50%);
    width: 8px;
    height: 6px;
    background: url('/images/icons/icon-arrow-bottom.svg') no-repeat center /
      cover;
  }
`;

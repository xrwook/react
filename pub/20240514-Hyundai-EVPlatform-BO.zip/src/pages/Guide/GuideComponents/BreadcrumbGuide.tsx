import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Breadcrumb from 'common/Breadcrumb/Breadcrumb';
import BreadcrumbHome from 'common/Breadcrumb/BreadcrumbHome';
import BreadcrumbLink from 'common/Breadcrumb/BreadcrumbLink';

const BreadcrumbGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Breadcrumb</GuideText>
        <GuideBox>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">2 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">2 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">3 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">...</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">...</BreadcrumbLink>
            <BreadcrumbLink to="/">4 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
        </GuideBox>
        <GuideSubBox>
          &lt;Breadcrumb&gt;
          <br />
          &nbsp;&nbsp;&nbsp;&lt;BreadcrumbHome to="" /&gt;
          <br />
          &nbsp;&nbsp;&nbsp;&lt;BreadcrumbLink to=""&gt;&lt;/BreadcrumbLink&gt;
          <br />
          &lt;/Breadcrumb&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default BreadcrumbGuide;

import { BreadcrumbItem, BreadcrumbItemLink } from './StyledBreadcrumb';

export interface BreadcrumbProps {
  children?: any;
  to?: any;
  className?: any;
}

const BreadcrumbLink: React.FC<BreadcrumbProps> = ({
  children,
  to,
  className,
  ...props
}) => {
  return (
    <BreadcrumbItem {...props}>
      <BreadcrumbItemLink to={to} className={className}>
        {children}
      </BreadcrumbItemLink>
    </BreadcrumbItem>
  );
};

export default BreadcrumbLink;

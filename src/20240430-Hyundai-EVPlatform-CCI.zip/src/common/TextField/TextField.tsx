import React, { useState } from 'react';
import styled from 'styled-components';
import closeIcon from 'style/assets/images/common/icon-close.svg';
import searchIcon from 'style/assets/images/common/icon-head-search.svg';

const InputWrapper = styled.div`
  width: auto;
`;

const InputBox = styled.div`
  position: relative;
  display: flex;
  align-items: center;
`;

const Icon = styled.button`
  position: absolute;
  border: none;
  width: 16px;
  height: 16px;
  cursor: pointer;
  outline: none;
  background-color: transparent;
`;

const SearchButton = styled.span`
  position: absolute;
  left: 10px;
  width: 16px;
  height: 16px;
  background: url(${searchIcon}) no-repeat center;
  background-size: contain;
`;

const ClearButton = styled(Icon)`
  right: 10px;
  background: url(${closeIcon}) no-repeat center;
`;

const InputText = styled.input<TextFieldProps>`
  display: block;
  padding: ${(props) => (props.$isSearch ? '8px 30px' : '8px 10px')};
  width: 100%;
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
  color: ${(props) => (props.disabled ? '#c7c7c7' : '#000')};
  border: ${(props) =>
    props.disabled
      ? '1px solid #f7f7f7'
      : props.readOnly
        ? '1px solid #ebebeb'
        : props.$isError
          ? '1px solid #F15454'
          : '1px solid #e3e3e3'};
  border-radius: 4px;
  background-color: ${(props) =>
    props.readOnly ? '#ebebeb' : props.disabled ? '#f7f7f7' : '#fff'};

  &::placeholder {
    color: #aaaaaa;
  }

  &:hover {
    border: 1px solid ${(props) => (props.$isError ? '#F15454' : ' #c0bfbf')};
  }

  &:focus {
    outline: none;
    border: 1px solid ${(props) => (props.$isError ? '#F15454' : '#0057ff')};
  }
`;

const ErrorMessage = styled.span`
  flex: none;
  color: #f15454;
  font-size: 12px;
  margin-top: 5px;
  padding-left: 5px;
`;

export interface TextFieldProps {
  type?: string;
  id?: string;
  name: string;
  value?: string;
  placeholder?: string;
  disabled?: boolean;
  readOnly?: boolean;
  $isError?: boolean;
  $isSearch?: boolean;
  errorMessage?: string;
}

const TextField: React.FC<TextFieldProps> = ({
  type,
  id,
  name,
  value = '',
  placeholder,
  disabled,
  readOnly,
  $isError,
  $isSearch,
  errorMessage,
}) => {
  const [inputValue, setInputValue] = useState(value);

  const handleClear = () => {
    setInputValue('');
  };

  return (
    <InputWrapper>
      <InputBox>
        {$isSearch && <SearchButton aria-hidden="true" />}
        <InputText
          id={id}
          name={name}
          type={type}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          disabled={disabled}
          readOnly={readOnly}
          placeholder={placeholder}
          $isError={$isError}
          $isSearch={$isSearch}
        />
        {inputValue && !disabled && !readOnly && (
          <ClearButton onClick={handleClear} />
        )}
      </InputBox>
      {$isError && errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
    </InputWrapper>
  );
};

export default TextField;

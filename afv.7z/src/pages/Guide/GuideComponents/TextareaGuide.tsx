import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Textarea from 'common/Textarea/Textarea';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const TextareaGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Textarea</GuideText>
        <GuideBox>
          <Textarea
            id="textarea01"
            name="text"
            height="100px"
            placeholder="Enter long form text here"
          />
          <Textarea
            id="textarea02"
            name="readOnly"
            height="100px"
            placeholder="Enter long form text here"
            value="readOnly"
            readOnly
          />
          <Textarea
            id="textarea03"
            name="disabled"
            height="100px"
            placeholder="Enter long form text here"
            value="disabled"
            disabled
          />
          <Textarea
            id="textarea04"
            name="error"
            height="100px"
            defaultValue="Enter long form text here"
            error
          />
        </GuideBox>
        <GuideSubBox>
          &lt;Textarea id="" name="" placeholder="" /&gt; <br />
          &lt;Textarea id="" name="" placeholder="" value="" readOnly /&gt;
          <br />
          &lt;Textarea id="" name="" placeholder="" value="" disabled /&gt;
          <br />
          &lt;Textarea id="" name="" placeholder="" value="" error /&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default TextareaGuide;

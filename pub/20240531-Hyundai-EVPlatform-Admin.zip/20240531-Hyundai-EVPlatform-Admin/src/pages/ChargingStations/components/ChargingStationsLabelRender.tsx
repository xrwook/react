import Labels from 'common/Labels/Labels';
import { RenderCommonWrap } from '../styled/StyledChargingStations';

export interface ChargingStationsLabelRenderProps {
  status?: string | undefined;
}

const ChargingStationsLabelRender: React.FC<
  ChargingStationsLabelRenderProps
> = ({ status = '' }) => {
  const statusMap: any = [
    {
      name: ['등록대기'],
      color: 'yellow',
    },
    {
      name: ['등록완료', '조치완료'],
      color: 'blue',
    },
    {
      name: ['등록불가', '조치필요'],
      color: 'red',
    },
    {
      name: ['적용중'],
      color: 'green',
    },
    {
      name: ['적용종료'],
      color: 'gray',
    },
  ];

  const findColor = (target: any) => {
    for (let i = 0; i < statusMap.length; i++) {
      const obj = statusMap[i];
      const targetWord = target.replace(/(\s*)/g, '');

      if (obj.name.includes(targetWord)) {
        return obj.color;
      }
    }
    return 'blue';
  };

  const result = findColor(status);

  return (
    <RenderCommonWrap>
      <Labels $color={result} $size="medium">
        {status}
      </Labels>
    </RenderCommonWrap>
  );
};

export default ChargingStationsLabelRender;

import { useState, useRef, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { ColDef } from 'ag-grid-community';
import { AgGridWrap, AgGridContainer } from './StyledAgGrid';
import Pagination from 'common/Pagination/Pagination';
import Button from 'common/Button/Button';
import Dropdown from 'common/Dropdown/Dropdown';
import Icon from 'common/Icon/Icon';
import AgGridTop from 'common/AgGrid/AgGridTop';
import AgGridTooltip from 'common/AgGrid/AgGridTooltip';

export interface AgGridProps {
  rowData?: any[];
  columnDefs?: any;
  hasPaging?: boolean;
  hasGridTop?: boolean;
  noneButton?: boolean;
  hasDate?: boolean;
  itemsPerPage?: number;
  defaultNumberButtons?: number;
  dateSelectOption?: any;
  dateSelectDefaultOption?: any;
  listPerPageSelectOption?: any;
  listPerPageDefaultOption?: any;
  hasCheckbox?: boolean;
  nonePerPageSelect?: boolean;
  addButton?: boolean;
}

const AgGrid: React.FC<AgGridProps> = ({
  rowData,
  columnDefs,
  hasPaging,
  hasGridTop,
  noneButton,
  hasDate,
  dateSelectOption,
  dateSelectDefaultOption,
  listPerPageSelectOption,
  listPerPageDefaultOption,
  hasCheckbox,
  nonePerPageSelect,
  addButton,
}) => {
  const [gridApi, setGridApi] = useState(null);
  const [rowCount, setRowCount] = useState(null);
  const [selectedOption, setSelectedOption] = useState(20);
  const [selectedCount, setSelectedCount] = useState(null);

  const gridRef = useRef<AgGridReact>(null);

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      sortable: false,
      resizable: true,
      flex: 1,
      tooltipComponent: (p: any) => {
        return <AgGridTooltip message={p.value} />;
      },
    };
  }, []);

  const checkboxColumn = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
      maxWidth: 52,
      flex: 1,
    },
  ];

  const onGridReady = (params: any) => {
    setGridApi(params.api);
    setRowCount(params.api.getDisplayedRowCount());
    params.api.sizeColumnsToFit();

    if (hasCheckbox) {
      setSelectedCount(params.api.getSelectedRows().length);
      gridRef.current?.api.setGridOption('columnDefs', [
        ...checkboxColumn,
        ...columnDefs,
      ]);
    }

    // 툴팁 적용
    const currentColumnDefs = params.api.getGridOption('columnDefs');
    const newColumnDefs = 'field';
    const updatedColumnDefs = currentColumnDefs.map(
      (columnDef: any, index: any) => {
        index = index + 1;
        return {
          ...columnDef,
          tooltipField: newColumnDefs + index,
        };
      },
    );

    params.api.setGridOption('columnDefs', updatedColumnDefs);
  };

  const checkTextOverflow = (e: any) => {
    if (e.target.clientWidth >= e.target.scrollWidth) {
      return false;
    }

    return true;
  };

  const onSelectionChanged = (params: any) => {
    setSelectedCount(params.api.getSelectedRows().length);
  };

  const onCellMouseOver = (params: any) => {
    if (checkTextOverflow(params.event)) {
      setTimeout(() => {
        const targetElement = document.querySelector('.ag-tooltip-custom');
        targetElement?.classList.add('active');
      }, 1010);
    }
  };

  const handleClick = (prop: any) => {
    const stringValue: string = prop;
    const changeNumberValue: number = parseInt(stringValue, 10);
    setSelectedOption(changeNumberValue);
  };

  return (
    <AgGridContainer>
      {hasGridTop && (
        <AgGridTop totalCount={rowCount} selectedCount={selectedCount}>
          {!noneButton && (
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryGray"
              $icon={'icon-download'}
            >
              <Icon $widthSize={20} $heightSize={20} />
              엑셀 다운로드
            </Button>
          )}
          {hasDate && (
            <Dropdown
              $width="168"
              options={dateSelectOption}
              defaultOption={dateSelectDefaultOption}
              onClick={handleClick}
            />
          )}
          {!nonePerPageSelect && (
            <Dropdown
              options={listPerPageSelectOption}
              defaultOption={listPerPageDefaultOption}
              onClick={handleClick}
            />
          )}
          {addButton && (
            <Button
              onClick={() => {}}
              $size="small"
              $variant="secondaryGray"
              $width="96"
            >
              담당자 추가
            </Button>
          )}
        </AgGridTop>
      )}
      <AgGridWrap className="ag-theme-alpine">
        <AgGridReact
          ref={gridRef}
          columnDefs={columnDefs}
          rowData={rowData}
          rowSelection="multiple"
          reactiveCustomComponents
          onGridReady={onGridReady}
          onSelectionChanged={hasCheckbox ? onSelectionChanged : undefined}
          onCellMouseOver={onCellMouseOver}
          defaultColDef={defaultColDef}
          pagination={true}
          paginationPageSize={selectedOption}
          suppressPaginationPanel={true}
          tooltipShowDelay={1000}
          tooltipHideDelay={60000}
          components={{ customTooltip: AgGridTooltip }}
          sortingOrder={['desc', 'asc']}
        />
      </AgGridWrap>
      {hasPaging && <Pagination gridApi={gridApi} />}
    </AgGridContainer>
  );
};

export default AgGrid;

import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const fadeOut = keyframes`
  from { opacity: 1; }
  to { opacity: 0; }
`;

const DimWrapper = styled.div<{ $isDisplayed: boolean }>`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: transparent;
  z-index: 999;
  display: ${(props) => (props.$isDisplayed ? 'flex' : 'none')};
  animation: ${(props) => (props.$isDisplayed ? fadeIn : fadeOut)} 0.4s ease
    forwards;
`;

const FullWrapper = styled.div<{ $isOpen: boolean }>`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  animation: ${(props) => (props.$isOpen ? fadeIn : fadeOut)} 0.4s ease;
`;

const FullBox = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  height: 100%;
  background-color: #ffffff;
`;

interface FullPopupProps {
  children?: React.ReactNode;
  onClose: () => void;
  isDisplayed: boolean;
}

const FullPopup: React.FC<FullPopupProps> = ({ children, isDisplayed }) => {
  const [$isOpen] = useState(true);

  return (
    <DimWrapper $isDisplayed={isDisplayed}>
      <FullWrapper $isOpen={$isOpen}>
        <FullBox>{children}</FullBox>
      </FullWrapper>
    </DimWrapper>
  );
};

export default FullPopup;

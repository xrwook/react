import styled from 'styled-components';

const TitleLayout = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  border: 1px solid;
`;

const TitleTop = styled.div`
  display: flex;
  justify-content: space-between;
  border: 1px solid blue;
`;

const TitleMain = styled.div`
  font-size: 24px;
  line-height: 36px;
  font-weight: 500;
  color: #212430;
`;

const TitleSub = styled.div<TitleProps>`
  font-size: 12px;
  line-height: 20px;
  color: #a0a4b6;
  margin-top: 4px;
`;

export interface TitleProps {
  titlemain?: any;
  titlesub?: any;
  children?: any;
}

const Title: React.FC<TitleProps> = ({
  titlemain,
  titlesub = false,
  children,
}) => {
  return (
    <TitleLayout>
      <TitleTop>
        <TitleMain>{titlemain}</TitleMain>
        {children}
      </TitleTop>
      <TitleSub titlesub={titlesub ? 'true' : undefined}>{titlesub}</TitleSub>
    </TitleLayout>
  );
};

export default Title;

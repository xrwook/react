import { Link } from 'react-router-dom';

export const Home_ = () => {
  return (
    <div>
      <h2 className="text-4xl">React Query Tutorial</h2>
      <Link to="/brand">Move to Brand page</Link>
    </div>
  );
};

import styled from 'styled-components';
import { createGlobalStyle } from 'styled-components';

export const GlobalStyles = createGlobalStyle` 
input {
  cursor: pointer;
}

`;

export const DatePickerWrap = styled.div`
  display: flex;
`;

export const DatepickerTestInput = styled.input<{ options?: any }>`
  flex: 1;
  display: block;
  width: 100%;
  height: 32px;
  padding: 5px 9px;
  font-size: 14px;
  line-height: 20px;
  color: #333;
  font-weight: 500;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;
  margin-bottom: 10px;

  &::placeholder {
    color: #aaa;
  }

  &:focus {
    border: 1px solid blue;
    outline: none;
  }

  &:disabled {
    pointer-events: none;
  }
`;

export const DatepickerBottom = styled.div<{ $button?: any }>`
  height: ${(props) => (props.$button ? '74px' : '58px')};
  padding: ${(props) => (props.$button ? '18px 0 24px 0' : '14px 0 20px 0')};
  margin-top: 25px;
  border-top: 1px solid #d9d9d9;
`;

export const Today = styled.div<{ $today?: any }>`
  display: ${(props) => (props.$today ? 'flex' : 'none')};
  justify-content: center;

  button {
    height: 24px;
  }
`;

export const ButtonWrap = styled.div<{ $button?: any }>`
  display: ${(props) => (props.$button ? 'flex' : 'none')};
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;

  > button:first-child {
    padding: 0;
  }
`;

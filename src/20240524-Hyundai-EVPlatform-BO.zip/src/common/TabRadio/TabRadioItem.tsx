import { TabRadio, TabRadioButton, TabRadioLabel } from './StyledTabRadio';

export interface TabRadioItemProps {
  id?: string;
  name?: any;
  text?: any;
  htmlFor?: any;
  disabled?: any;
  checked?: any;
  className?: any;
  defaultChecked?: any;
  children?: any;
  $borderlast?: any;
  $borderfirst?: any;
}

const TabRadioItem: React.FC<TabRadioItemProps> = ({
  id,
  name,
  disabled,
  checked,
  className,
  defaultChecked,
  text,
  htmlFor,
  $borderlast,
  $borderfirst,
}) => {
  return (
    <TabRadio>
      <TabRadioButton
        type="radio"
        id={id}
        name={name}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        className={className}
        $borderlast={$borderlast}
        $borderfirst={$borderfirst}
      />
      <TabRadioLabel htmlFor={htmlFor}>{text}</TabRadioLabel>
    </TabRadio>
  );
};

export default TabRadioItem;

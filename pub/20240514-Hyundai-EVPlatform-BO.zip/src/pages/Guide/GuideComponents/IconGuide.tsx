import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Icon from 'common/Icon/Icon';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const Layout = styled.div`
  display: flex;
`;

const IconGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Icon</GuideText>
        <GuideBox>
          <Layout>
            <Icon $widthSize={16} $heightSize={16} $name={'icon-minus'}>
              축소하기
            </Icon>
            <Icon $widthSize={20} $heightSize={20} $name={'icon-home'}>
              홈
            </Icon>
            <Icon $widthSize={24} $heightSize={24} $name={'icon-lnb-bookmark'}>
              즐겨찾기
            </Icon>
            <Icon $widthSize={32} $heightSize={32} $name={'icon-pin'}>
              위치
            </Icon>
            <Icon $widthSize={48} $heightSize={48} $name={'icon-pin'}>
              위치
            </Icon>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Icon $widthSize="16" $widthSize="16" $name="icon-minus" /&gt;
          <br />
          &lt;Icon $widthSize="20" $widthSize="20" $name="icon-home" /&gt;
          <br />
          &lt;Icon $widthSize="24" $widthSize="24" $name="icon-bookmark" /&gt;
          <br />
          &lt;Icon $widthSize="32" $widthSize="32" $name="icon-pin" /&gt;
          <br />
          &lt;Icon $widthSize="48" $widthSize="48" $name="icon-pin " /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default IconGuide;

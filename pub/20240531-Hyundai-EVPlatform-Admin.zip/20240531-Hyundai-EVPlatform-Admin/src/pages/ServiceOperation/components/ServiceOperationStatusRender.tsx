import Icon from 'common/Icon/Icon';
import { ServiceOperationStatusRenderData } from './data';
import {
  RenderWrap,
  RenderBox,
  RenderCurrent,
  RenderTotal,
} from '../styled/StyledServiceOperation';

export interface ChargingStationStatusRenderProps {
  id?: number;
  iconWidthSize?: number;
  iconName?: string;
  current?: number;
  total?: number;
}

const ServiceOperationStatusRender: React.FC<
  ChargingStationStatusRenderProps
> = () => {
  return (
    <RenderWrap>
      {ServiceOperationStatusRenderData &&
        ServiceOperationStatusRenderData.map((item) => (
          <RenderBox key={item.id}>
            <Icon
              $widthSize={item.iconWidthSize}
              $heightSize={16}
              $name={`icon-lightning-${item.iconName}`}
            />
            <div className="group">
              <RenderCurrent>{item.current}</RenderCurrent>
              <RenderTotal>{item.total}</RenderTotal>
            </div>
          </RenderBox>
        ))}
    </RenderWrap>
  );
};

export default ServiceOperationStatusRender;

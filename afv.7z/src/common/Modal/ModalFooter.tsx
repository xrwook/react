import styled from 'styled-components';

const ModalFooterWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 24px 30px;
`;

export interface ModalFooterProps {
  children?: any;
}

const ModalFooter: React.FC<ModalFooterProps> = ({ children }) => {
  return (
    <>
      <ModalFooterWrapper>{children}</ModalFooterWrapper>
    </>
  );
};

export default ModalFooter;

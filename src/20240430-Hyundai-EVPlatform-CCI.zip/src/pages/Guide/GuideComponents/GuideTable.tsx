import React from 'react';
import styled from 'styled-components';

const StyledTable = styled.table`
  width: 100%;
  thead th {
    font-weight: 500;
    border-top: 2px solid #ddd;
    background-color: #eee;
    padding: 10px 15px;
  }
  tr {
    &:has(a):hover {
      background-color: #fff;
    }
  }
  th,
  td {
    border: 1px solid #ddd;
    font-size: 16px;
    color: #000;
    text-align: center;
    box-sizing: border-box;
    white-space: nowrap;
  }
  td {
    font-size: 16px;
    padding: 13px;
    word-break: break-all;
    a {
      display: block;
      color: #3a5ee5;
    }
  }
  .badge {
    display: inline-block;
    padding: 0.5rem;
    color: #fff;
    border-radius: 0.5rem;
    &.complete {
      background-color: blue;
    }
    &.ing {
      background-color: red;
    }
    &.modify {
      background-color: orange;
    }
  }
  li {
    text-align: center;
    + li {
      margin-top: 0.5rem;
    }
    &.highlight {
      color: red;
    }
  }
`;

interface GuideTableProps {
  children: React.ReactNode;
}

const GuideTable: React.FC<GuideTableProps> = ({ children }) => {
  return <StyledTable>{children}</StyledTable>;
};

export default GuideTable;

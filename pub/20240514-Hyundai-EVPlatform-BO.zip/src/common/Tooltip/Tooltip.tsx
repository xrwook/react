import { useState } from 'react';
import { TooltipTip, TooltipWrapper } from './StyledTooltip';

export interface TooltipProps {
  children?: any;
  message?: any;
  $direction: 'top' | 'left' | 'right' | 'bottom';
  $auto?: any;
}

const Tooltip: React.FC<TooltipProps> = ({
  children,
  $direction,
  message,
  $auto,
}) => {
  const [active, setActive] = useState(false);

  const showTip = () => {
    setActive(true);
  };

  const hideTip = () => {
    setActive(false);
  };

  return (
    <TooltipWrapper onMouseEnter={showTip} onMouseLeave={hideTip}>
      {children}
      {active && (
        <TooltipTip $direction={$direction} $auto={$auto}>
          {message}
        </TooltipTip>
      )}
    </TooltipWrapper>
  );
};

export default Tooltip;

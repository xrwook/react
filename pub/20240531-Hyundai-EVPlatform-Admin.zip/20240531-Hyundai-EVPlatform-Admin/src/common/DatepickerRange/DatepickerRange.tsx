import { useEffect, useRef, useState } from 'react';
import flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.min.css';
import { Instance as FlatpickrInstance } from 'flatpickr/dist/types/instance';
import ReactDOM from 'react-dom';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';
import {
  ButtonWrap,
  DatePickerWrap,
  DatepickerBottom,
  DatepickerLine,
  DatepickerInput,
  GlobalStyles,
  DatepickerInputWrapper,
} from './StyledDatepickerRange';

export interface ButtonsPortalProps {
  close: () => void;
  select: () => void;
}

export interface DatepickerRangeProps {
  mode: 'range';
}

const ButtonsPortal = ({ close, select }: ButtonsPortalProps) => (
  <DatepickerBottom>
    <ButtonWrap>
      <Button
        $size="large"
        $variant="transparent"
        onClick={() => {}}
        data-clear
      >
        초기화
      </Button>
      <ButtonGroup $gap={8}>
        <Button onClick={close} $size="large" $variant="secondaryGray">
          취소
        </Button>
        <Button onClick={select} $size="large" $variant="primary">
          적용
        </Button>
      </ButtonGroup>
    </ButtonWrap>
  </DatepickerBottom>
);

const DatepickerRange = ({ mode }: DatepickerRangeProps) => {
  const startInputRef = useRef<HTMLInputElement>(null);
  const endInputRef = useRef<HTMLInputElement>(null);
  const [instance, setInstance] = useState<FlatpickrInstance | null>(null);
  const fpRef = useRef<FlatpickrInstance | null>(null);

  useEffect(() => {
    if (startInputRef.current) {
      const fpOptions = {
        mode: mode,
        enableTime: false,
        dateFormat: 'Y-m-d',
        showMonths: mode === 'range' ? 2 : 1,
        closeOnSelect: false,
        onChange: (selectedDates: Date[]) => {
          if (mode === 'range' && selectedDates.length === 2) {
            startInputRef.current!.value = flatpickr.formatDate(
              selectedDates[0],
              'Y-m-d',
            );
            endInputRef.current!.value = flatpickr.formatDate(
              selectedDates[1],
              'Y-m-d',
            );
          }
        },
        onReady: (_: any, __: any, fpInstance: FlatpickrInstance) => {
          setInstance(fpInstance);
          fpRef.current = fpInstance;
        },
      };

      flatpickr(startInputRef.current, fpOptions);

      if (endInputRef.current) {
        endInputRef.current.addEventListener('click', () => {
          if (fpRef.current) {
            fpRef.current.open();
          }
        });
      }
    }

    return () => {
      instance?.destroy();
    };
  }, [mode]);

  return (
    <>
      <GlobalStyles />
      <DatePickerWrap>
        <DatepickerInputWrapper>
          <DatepickerInput
            ref={startInputRef}
            type="text"
            placeholder="YYYY.MM.DD"
          />
        </DatepickerInputWrapper>
        <DatepickerLine />
        <DatepickerInputWrapper>
          <DatepickerInput
            ref={endInputRef}
            type="text"
            placeholder="YYYY.MM.DD"
          />
        </DatepickerInputWrapper>
        {instance &&
          ReactDOM.createPortal(
            <ButtonsPortal
              close={() => instance.close()}
              select={() => instance.close()}
            />,
            instance.calendarContainer,
          )}
      </DatePickerWrap>
    </>
  );
};

export default DatepickerRange;

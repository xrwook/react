import { AlertContentWrapper } from './StyledAlert';

export interface AlertContentProps {
  children?: any;
}

const AlertContent: React.FC<AlertContentProps> = ({ children }) => {
  return (
    <>
      <AlertContentWrapper>{children}</AlertContentWrapper>
    </>
  );
};

export default AlertContent;

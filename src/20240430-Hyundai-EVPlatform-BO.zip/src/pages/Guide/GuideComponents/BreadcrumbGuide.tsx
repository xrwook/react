import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Breadcrumb from 'common/Breadcrumb/Breadcrumb';
import BreadcrumbHome from 'common/Breadcrumb/BreadcrumbHome';
import BreadcrumbLink from 'common/Breadcrumb/BreadcrumbLink';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;
const BreadcrumbGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Breadcrumb</GuideText>
        <GuideBox>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">2 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">1 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">2 depth</BreadcrumbLink>
            <BreadcrumbLink to="/">3 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">...</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
          <Breadcrumb>
            <BreadcrumbHome to="/" />
            <BreadcrumbLink to="/">...</BreadcrumbLink>
            <BreadcrumbLink to="/">4 depth</BreadcrumbLink>
            <BreadcrumbLink to="/" className="active">
              Current Page
            </BreadcrumbLink>
          </Breadcrumb>
        </GuideBox>
        <GuideSubBox>
          &lt;Breadcrumb&gt;
          <br />
          &nbsp;&nbsp;&nbsp;&lt;BreadcrumbHome to="" /&gt;
          <br />
          &nbsp;&nbsp;&nbsp;&lt;BreadcrumbLink to=""&gt;&lt;/BreadcrumbLink&gt;
          <br />
          &lt;/Breadcrumb&gt;
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default BreadcrumbGuide;

import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const datasLayoutView = [
  {
    title: 'Layout',
    url: '/guidelist/layout',
  },
];

const datasOverView = [
  {
    title: 'Popup',
    url: '/guidelist/Popup',
  },
];

const datasComponents = [
  {
    title: 'Progress',
    url: '/guidelist/progress',
  },
  {
    title: 'Button',
    url: '/guidelist/Button',
  },
  {
    title: 'DatePicker',
    url: '/guidelist/DatePicker',
  },
  {
    title: 'CheckBox',
    url: '/guidelist/CheckBox',
  },
  {
    title: 'RadioBox',
    url: '/guidelist/RadioBox',
  },
  {
    title: 'Switch',
    url: '/guidelist/Switch',
  },
  {
    title: 'TextField',
    url: '/guidelist/TextField',
  },
  {
    title: 'SelectBox',
    url: '/guidelist/SelectBox',
  },
  {
    title: 'KeyValue & BasicBox',
    url: '/guidelist/KeyValue',
  },
];

const LnbWrap = styled.div`
  width: 220px;
  min-height: 100vh;
  padding: 20px 10px 0;
  background-color: white;
  border-right: 1px solid #ccc;
`;

const LnbMenuItem = styled.div`
  font-size: 1.25rem;
  font-weight: bold;
  color: inherit;
  text-decoration: none;
  margin-bottom: 20px;

  a {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
  }
`;

const LnbTitle = styled.h2`
  padding: 10px 0;
  font-size: 1.25rem;
  font-weight: bold;
  cursor: pointer;
`;

const LnbItem = styled.li`
  padding: 5px 0;
  margin: 5px 0;
  color: #000;

  &:hover {
    background-color: rgb(3, 105, 161);
    color: #fff;
  }

  a {
    display: block;
    width: 100%;
  }
`;

const LnbList = styled.div`
  display: flex;
  align-items: center
  cursor: pointer;
`;

const LnbMapList = styled.div`
  cursor: pointer;
`;

const GuideLnb: React.FC = () => {
  return (
    <LnbWrap>
      <ul>
        <li>
          <LnbList>
            <LnbMenuItem>
              <Link
                to="/publishinglist"
                style={{ textDecoration: 'none', color: 'inherit' }}
              >
                <span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth="1.5"
                    stroke="currentColor"
                    className="mr-2 h-6 w-6"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
                    />
                  </svg>
                </span>
                <span>Home</span>
              </Link>
            </LnbMenuItem>
          </LnbList>
        </li>
        <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Components</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasComponents.map((datasComponents, index) => (
                <LnbItem key={index}>
                  <Link to={datasComponents.url}>{datasComponents.title}</Link>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li>
        <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Layout</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasLayoutView.map((datasLayoutView, index) => (
                <LnbItem key={index}>
                  <Link to={datasLayoutView.url}>{datasLayoutView.title}</Link>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li>
        <li style={{ borderTop: '1px solid #ccc' }}>
          <LnbList>
            <LnbTitle>Popup</LnbTitle>
          </LnbList>
          <ul>
            <LnbMapList>
              {datasOverView.map((datasOverView, index) => (
                <LnbItem key={index}>
                  <Link to={datasOverView.url}>{datasOverView.title}</Link>
                </LnbItem>
              ))}
            </LnbMapList>
          </ul>
        </li>
      </ul>
    </LnbWrap>
  );
};

export default GuideLnb;

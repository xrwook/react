import AgGrid from 'common/AgGrid';
import {
  rowData,
  columnDefs,
  listPerPageSelectOption,
} from '../components/data';
import Title from 'common/Title';
import Button from 'common/Button';
import { ButtonGroup } from 'common/Button/StyledButton';
import FilterList from '../components/FilterListComponent';
import Header from 'layout/Header';

const ChargingStationsListContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전소 관리', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title titlemain="충전소관리" $titlesub="Last Updated 2024-00-00 00:00">
        <ButtonGroup $gap={8}>
          <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
            일괄 등록
          </Button>
          <Button onClick={() => {}} $size="large" $variant="primary">
            충전소 등록
          </Button>
        </ButtonGroup>
      </Title>
      <FilterList />
      <AgGrid
        rowData={rowData}
        columnDefs={columnDefs}
        hasPaging={true}
        hasGridTop={true}
        listPerPageSelectOption={listPerPageSelectOption}
        listPerPageDefaultOption={{
          value: '20',
          label: '20개씩보기',
        }}
      />
    </>
  );
};

export default ChargingStationsListContainer;

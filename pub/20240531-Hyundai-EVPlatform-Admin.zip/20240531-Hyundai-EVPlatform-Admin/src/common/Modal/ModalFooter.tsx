import { ModalFooterWrapper } from './StyledModal';

export interface ModalFooterProps {
  children?: any;
  $borderNone?: any;
}

const ModalFooter: React.FC<ModalFooterProps> = ({ children, $borderNone }) => {
  return (
    <>
      <ModalFooterWrapper $borderNone={$borderNone}>
        {children}
      </ModalFooterWrapper>
    </>
  );
};

export default ModalFooter;

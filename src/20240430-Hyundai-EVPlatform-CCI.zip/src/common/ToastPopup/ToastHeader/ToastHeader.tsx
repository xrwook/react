import React from 'react';
import styled from 'styled-components';

const ToastHeaderWrapper = styled.h2`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px 66px 4px 30px;
  font-size: ${(props) => props.theme.fontSize.fontSize7};
`;

export interface ToastHeaderProps {
  children?: React.ReactNode;
}

const ToastHeader: React.FC<ToastHeaderProps> = ({ children }) => {
  return <ToastHeaderWrapper>{children}</ToastHeaderWrapper>;
};

export default ToastHeader;

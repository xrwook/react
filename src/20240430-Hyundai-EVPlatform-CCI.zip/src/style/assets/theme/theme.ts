import { DefaultTheme } from 'styled-components';

const pxToRem = (size: any) => `${size / 16}rem`;

const color = {
  primary: '#5755FF',
  purpleprimary: '#4C4B9D',
  secondary: '#E6E4F9',
  tertiary: '#CDCDCD',
  disabled: '#CCCCCC',
  orange: '#FF8F6B',
  yellow: '#FEB63D',
  blue: '#5B93FF',
  green: '#7CC038',
  black: '#000000',
  white: '#FFFFFF',
};

const fontSize = {
  fontSize1: pxToRem(12), // 0.75rem
  fontSize2: pxToRem(13), // 0.8125rem
  fontSize3: pxToRem(14), // 0.875rem
  fontSize4: pxToRem(15), // 0.9375rem
  fontSize5: pxToRem(16), // 1rem
  fontSize6: pxToRem(18), // 1.125rem
  fontSize7: pxToRem(20), // 1.25rem
  fontSize8: pxToRem(24), // 1.5rem
};

const theme: DefaultTheme = {
  fontSize,
  color,
};

export default theme;

import { TabItem, TabList } from './StyledTab';

export interface TabProps {
  tabs?: any;
  selected?: any;
  $active?: any;
  onClick?: any;
}

const Tab: React.FC<TabProps> = ({ tabs = [], selected = 0, onClick }) => {
  const Panel = tabs && tabs[selected];

  return (
    <>
      <TabList>
        <ul>
          {tabs.map((item: any, index: any) => {
            return (
              <TabItem
                key={`${index}`}
                onClick={() => onClick(index)}
                $active={selected === index}
              >
                <button type="button">{item.name}</button>
              </TabItem>
            );
          })}
        </ul>
      </TabList>
      {Panel && <Panel.Component index={selected} />}
    </>
  );
};

export default Tab;

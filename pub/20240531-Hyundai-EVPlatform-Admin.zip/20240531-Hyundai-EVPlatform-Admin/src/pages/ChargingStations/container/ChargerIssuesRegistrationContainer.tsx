import { useState } from 'react';
import Title from 'common/Title';
import Header from 'layout/Header';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import TextField from 'common/TextField';
import Button from 'common/Button';
import Icon from 'common/Icon';
import FormFlex from 'common/FormFlex';
import Select from 'common/Select';
import DatePicker from 'common/Datepicker/Datepicker';
import Textarea from 'common/Textarea';
import FileSearch from 'common/FileSearch';
import PageFooter from 'common/PageFooter';
import AgGrid from 'common/AgGrid';
import { ContentContainer } from 'layout/StyledLayout';
import {
  ChargerIssuesRegistrationcolumnDefs,
  ChargerIssuesRegistrationrowData,
} from '../components/detailData';
import {
  ChargerIssuesEditOption2,
  ChargerIssuesEditOption3,
} from '../components/data';

const ChargerIssuesRegistrationContainer: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date());

  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전기 고장 관리' },
    { to: '/', text: '고장 등록', className: 'active' },
  ];

  const options11 = [{ value: 'Select plan', label: 'Select plan' }];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="충전소 고장 등록"
        $titleguide
        $titleGuideText="표시는 필수 입력항목입니다"
      />

      <ContentContainer $gap="48px">
        <section>
          <Title titlemain="기본 정보" $pagetitle />

          <Grid $columns={6} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem $colStart={1} $colEnd={4}>
              <Formcontrol title="충전소 이름" $row required>
                <FormFlex>
                  <TextField
                    id="TextField01"
                    name="TextField01"
                    type="text"
                    placeholder="충전소를 선택하세요."
                    disabled
                  />
                  <Button
                    onClick={() => {}}
                    $size="small"
                    $variant="secondaryGray"
                    $icon="icon-search-secondaryGray"
                  >
                    <Icon $widthSize={20} $heightSize={20}>
                      검색
                    </Icon>
                    충전소 검색
                  </Button>
                </FormFlex>
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={4}>
              <Formcontrol title="충전기 이름" $row required>
                <Select
                  inputId="Select01"
                  name="Select01"
                  placeholder="충전기 선택"
                  options={options11}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={4}>
              <Formcontrol title="EVSE ID" $row required>
                <Select
                  inputId="Select02"
                  name="Select02"
                  placeholder="EVSE ID 선택"
                  options={options11}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title titlemain="고장 정보" $pagetitle />

          <Grid $columns={2} $gap="12px 128px" margin="24px 0 0 0">
            <GridItem>
              <Formcontrol title="고장 유형" $row required>
                <Select
                  inputId="Select03"
                  name="Select03"
                  placeholder="고장 유형 선택"
                  options={ChargerIssuesEditOption2}
                  defaultValue={ChargerIssuesEditOption2[0]}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
            <GridItem>
              <Formcontrol title="고장 발생 일시" $row required>
                <FormFlex>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    selectsStart
                    startDate={startDate}
                    dateFormat="yyyy/MM/dd"
                  />
                  <div className="time">
                    <DatePicker
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      showTimeSelect
                      showTimeSelectOnly
                      timeIntervals={15}
                      timeCaption="Time"
                      dateFormat="h:mm aa"
                    />
                  </div>
                </FormFlex>
              </Formcontrol>
            </GridItem>

            {/* Case: ‘하드웨어' 선택시 [LCD보드] / [메인보드] / [차단기 고장(트림포함)] / [전력량계] / [M/C] / [파워 모듈]/ [충전 케이블/PLC 모 델] /[M2M모뎀 / 카드 리더기] /기타  */}
            {/* Case: ‘소프트웨어’ 선택시 LCD(프로토콜 펌웨어)/ 메인보드 펌웨어 / 설정값 착오 / 기타  */}
            {/* Case: ‘부대시설' 선택시 캐노피/볼라드/스토퍼/분전함/분전함 차단기/접지저항/과전류/절연저항/기타 */}
            <GridItem>
              <Formcontrol title="고장 구분" $row required>
                <Select
                  inputId="Select04"
                  name="Select04"
                  placeholder="고장 구분 선택"
                  options={ChargerIssuesEditOption3}
                  defaultValue={ChargerIssuesEditOption3[1]}
                  classNamePrefix="react-select"
                />
              </Formcontrol>
            </GridItem>
            {/* // */}

            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="고장 접수 내용" $row required>
                <Textarea
                  height="120px"
                  maxLength={500}
                  total={500}
                  placeholder="내용을 입력하세요."
                />
              </Formcontrol>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <Formcontrol title="첨부파일" $row>
                <FileSearch
                  text="* 이미지 최적의 해상도 450 x 300, 10MB 이하 (jpg,png)"
                  dnd
                />
              </Formcontrol>
            </GridItem>
          </Grid>
        </section>

        <section>
          <Title titlemain="담당자 정보" $pagetitle />

          <div style={{ marginTop: '24px' }}>
            <AgGrid
              rowData={ChargerIssuesRegistrationrowData}
              columnDefs={ChargerIssuesRegistrationcolumnDefs}
              hasGridTop={true}
              noneButton
              nonePerPageSelect
              addButton
            />
          </div>
        </section>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          취소
        </Button>
        <Button onClick={() => {}} $size="large" $variant="primary" disabled>
          등록
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargerIssuesRegistrationContainer;

import Layout from './Layout';
import Lnb from './Lnb';

const MainLayout: React.FC = () => {
  return (
    <Layout>
      <Lnb />
      <div>메인</div>
    </Layout>
  );
};

export default MainLayout;

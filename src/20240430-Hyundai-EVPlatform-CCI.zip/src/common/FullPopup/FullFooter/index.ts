export { default } from './FullFooter';

import { useState } from 'react';
import {
  AccordionArrow,
  AccordionItem,
  AccordionLayer,
  AccordionLayout,
  AccordionTitle,
} from './StyledAccordion';

export interface AccordionProps {
  children?: any;
  title?: any;
  $marginTop?: any;
  open?: boolean;
}

const Accordion: React.FC<AccordionProps> = ({
  children,
  title,
  $marginTop,
  open,
}) => {
  const [isopen, setOpen] = useState<boolean | null>(open ? true : null);

  const handleOpen = () => {
    setOpen(!isopen);
  };

  return (
    <AccordionItem $marginTop={$marginTop}>
      <AccordionLayout onClick={() => handleOpen()}>
        <AccordionTitle>{title}</AccordionTitle>
        <AccordionArrow className={isopen ? 'open' : ''} />
      </AccordionLayout>
      {isopen && <AccordionLayer>{children}</AccordionLayer>}
    </AccordionItem>
  );
};

export default Accordion;

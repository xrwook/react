import {
  TitleGuide,
  TitleLayout,
  TitleMain,
  TitleRight,
  TitleSub,
  TitleTop,
  TtileFlex,
} from './StyledTitle';

export interface TitleProps {
  titlemain?: string;
  $titlesub?: string;
  $titleguide?: boolean;
  $titleGuideText?: string;
  children?: React.ReactNode;
  $pagetitle?: boolean;
  $titleguideBlack?: any;
  label?: any;
}

const Title: React.FC<TitleProps> = ({
  titlemain,
  $titlesub,
  $titleguide,
  children,
  $pagetitle,
  $titleGuideText,
  $titleguideBlack,
  label,
}) => {
  return (
    <TitleLayout>
      <TitleTop $pagetitle={$pagetitle}>
        <TtileFlex>
          <TitleMain $pagetitle={$pagetitle}>{titlemain}</TitleMain>
          {label}
        </TtileFlex>
        <TitleRight>
          {children}
          {$titleguide && (
            <TitleGuide
              $titleguide={$titleguide}
              $titleguideBlack={$titleguideBlack}
            >
              {$titleGuideText}
            </TitleGuide>
          )}
        </TitleRight>
      </TitleTop>
      <TitleSub $titlesub={$titlesub}>{$titlesub}</TitleSub>
    </TitleLayout>
  );
};

export default Title;

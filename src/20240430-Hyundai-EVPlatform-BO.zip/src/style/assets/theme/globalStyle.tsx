import { createGlobalStyle } from 'styled-components';
import '../fonts/pretendard/style.css';
import timeIcon from 'style/assets/images/icon-time.svg';

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after {
    box-sizing: border-box;
  }

  html, body {
    font-size: 16px;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
    font-weight: 400;
    -webkit-text-size-adjust: none;
    text-size-adjust: none;
    word-break: break-all;
    -webkit-overflow-scrolling: touch
  }
  html, body, div, span, applet, object, iframe,
  h1, h2, h3, h4, h5, h6, p, blockquote, pre,
  a, abbr, acronym, address, big, cite, code,
  del, dfn, em, img, ins, kbd, q, s, samp,
  small, strike, strong, sub, sup, tt, var,
  b, u, i, center,
  dl, dt, dd, ol, ul, li,
  fieldset, form, label, legend,
  table, caption, tbody, tfoot, thead, tr, th, td,
  article, aside, canvas, details, embed, 
  figure, figcaption, footer, header, hgroup, 
  menu, nav, output, ruby, section, summary,
  time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font: inherit;
    vertical-align: baseline;
    font-family: 'Pretendard', '-apple-system', 'BlinkMacSystemFont', system-ui, 'Roboto', 'Helvetica Neue', 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', sans-serif;
  }
  ol, ul {
    list-style: none;
  }
  blockquote, q {
    quotes: none;
  }
  blockquote:before, blockquote:after,
  q:before, q:after {
    content: '';
    content: none;
  }
  table {
    border-collapse: collapse;
    border-spacing: 0;
  }
  a {
    color: inherit;
    text-decoration: none
  }
  button, input, select, table, textarea {
    font-size: inherit;
    color: inherit;
    font-family: inherit;
    font-weight: inherit
  }
  h1, h2, h3, h4, h5, h6, strong {
    font-size: inherit;
    line-height: inherit;
    font-weight: inherit
  }
  textarea {
    border: 0;
    word-break: keep-all;
    word-wrap: break-word
  }
  button, label, a {
    cursor: pointer;
    &:disabled {
      cursor: default;
    }
  }
  button, input {
    border-radius: 0;
    border: 0;
    background-color: unset
  }
  input, select, textarea, button {
    outline: none;
  }
  
  .time .react-datepicker__input-container::after {
    background-image: url(${timeIcon}) !important;
  }
`;
export default GlobalStyle;

import styled, { css } from 'styled-components';
import PrimaryIcon from 'style/assets/images/icon-search-primary.svg';
import PrimaryDisabledIcon from 'style/assets/images/icon-search-disabled.svg';
import SecondaryGrayIcon from 'style/assets/images/icon-search-secondaryGray.svg';
import SecondaryGrayDisabledIcon from 'style/assets/images/icon-search-secondaryGray-disabled.svg';
import SecondaryBlueIcon from 'style/assets/images/icon-search-secondaryBlue.svg';
import SecondaryBlueDisabledIcon from 'style/assets/images/icon-search-secondaryBlue-disabled.svg';
import TertiaryIcon from 'style/assets/images/icon-search-tertiary.svg';
import TertiaryDisabledIcon from 'style/assets/images/icon-search-tertiary-disabled.svg';
import DownloadIcon from 'style/assets/images/icon-download.svg';

const size = {
  mini: css`
    height: 24px;
    padding: 1px 7px;
    font-size: 12px;
  `,
  small: css`
    height: 32px;
    padding: 5px 15px;
    font-size: 13px;
  `,
  large: css`
    height: 36px;
    padding: 5px 19px;
    font-size: 14px;
    line-height: 24px;
  `,
};

const variant = {
  primary: css`
    background-color: #5755ff;
    border: 1px solid #5755ff;
    &::before {
      background-image: url(${PrimaryIcon});
    }

    &:active {
      background-color: #4c4b9d;
      border: 1px solid #4c4b9d;
    }
    &:disabled {
      background-color: #a0a4b6;
      border: 1px solid #a0a4b6;
      color: #f0f1f4;
      &::before {
        background-image: url(${PrimaryDisabledIcon});
      }
    }
    &:hover {
      background-color: #7a78ff;
      border: 1px solid #7a78ff;
    }
  `,
  secondaryBlue: css`
    background-color: #fff;
    border: 1px solid #4341ff;
    color: #3a38ff;
    &::before {
      background-image: url(${SecondaryBlueIcon});
    }

    &:active {
      background-color: #e6e4f9;
      color: #4c4b9d;
      border: 1px solid #4c4b9d;
    }
    &:disabled {
      background-color: #ffff;
      border: 1px solid #7e8791;
      color: #7e8791;
      &::before {
        background-image: url(${SecondaryBlueDisabledIcon});
      }
    }
    &:hover {
      background-color: #f4f3ff;
      border: 1px solid #5958ff;
    }
  `,
  secondaryGray: css`
    background-color: #fff;
    border: 1px solid #c2c5d2;
    color: #434860;
    &::before {
      background-image: url(${SecondaryGrayIcon});
    }

    &:active {
      background-color: #ebedf3;
      color: #434860;
      border: 1px solid #a0a4b6;
    }
    &:disabled {
      background-color: #fbfbfb;
      border: 1px solid #dadce4;
      color: #cdcdcd;
      &::before {
        background-image: url(${SecondaryGrayDisabledIcon});
      }
    }
    &:hover {
      background-color: #f0f1f4;
      border: 1px solid #dadce4;
    }
  `,
  tertiary: css`
    background-color: #fff;
    border: 1px solid #c2c5d2;
    color: #212430;
    &::before {
      background-image: url(${TertiaryIcon});
    }

    &:active {
      background-color: #ebedf3;
      border: 1px solid #a0a4b6;
    }
    &:disabled {
      background-color: #fbfbfb;
      border: 1px solid #dadce4;
      color: #cdcdcd;
      &::before {
        background-image: url(${TertiaryDisabledIcon});
      }
    }
    &:hover {
      background-color: #e8eaf0;
      border: 1px solid #e8eaf0;
    }
  `,
};

const ButtonStyle = styled.button<ButtonProps>`
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0;
  cursor: pointer;
  border-radius: 4px;
  width: auto;
  color: #fff;
  font-weight: 500;
  line-height: 20px;
  transition: all 150ms;
  ${(props) => size[props.size]};
  ${(props) => variant[props.variant]};

  > span {
    padding-left: ${(props) =>
      props.icon ? '6px' : props.iconOnly ? '0' : ''};
  }

  &:disabled {
    pointer-events: none;
  }

  &::before {
    content: '';
    display: ${(props) => (props.icon ? 'inline-block' : 'none')};
    width: 20px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: cover;
    background-image: ${(props) =>
      props.download ? `url(${DownloadIcon})` : ''};
  }
`;

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  className?: string;
  children?: React.ReactNode;
  disabled?: any;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  icon?: any;
  download?: any;
  iconOnly?: any;
  size: 'mini' | 'small' | 'large';
  variant: 'primary' | 'secondaryBlue' | 'secondaryGray' | 'tertiary';
}

const Button: React.FC<ButtonProps> = ({
  children,
  disabled,
  className,
  onClick,
  size,
  variant,
  icon = false,
  download,
}) => {
  return (
    <ButtonStyle
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={className}
      size={size}
      variant={variant}
      icon={icon ? 'true' : undefined}
      download={download}
    >
      <span>{children}</span>
    </ButtonStyle>
  );
};

export default Button;

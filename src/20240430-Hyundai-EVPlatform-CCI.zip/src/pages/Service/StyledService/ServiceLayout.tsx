import styled from 'styled-components';

export const ServiceBlock = styled.div`
  display: block;
  height: 100vh;
`;

export const ServiceWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background-color: #fff;
`;

import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import FileSearch from 'common/FileSearch';
import { FileAttachArea } from 'common/FileSearch/StyledFileSearch';
import Button from 'common/Button/Button';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TooltipGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>FileSearch(Sample Version)</GuideText>
        <GuideBox>
          <FileSearch text="450x300 px (10 MB 이하) 권장" />
          <FileAttachArea $small="small">
            <div className="file-attach-area">
              <img src="/images/dummy/img-attach01.jfif" />
              <Button
                className="file-attach-button"
                $iconOnly
                $icon="icon-attach-delete"
                $size="none"
                $variant="none"
                onClick={() => {}}
              />
            </div>
            <div className="file-attach-area">
              <img src="/images/dummy/img-attach02.jfif" />
              <Button
                className="file-attach-button"
                $iconOnly
                $icon="icon-attach-delete"
                $size="none"
                $variant="none"
                onClick={() => {}}
              />
            </div>
            <div className="file-attach-area">
              <img src="/images/dummy/img-attach.png" />
              <Button
                className="file-attach-button"
                $iconOnly
                $icon="icon-attach-delete"
                $size="none"
                $variant="none"
                onClick={() => {}}
              />
            </div>
          </FileAttachArea>
        </GuideBox>
        <GuideSubBox>
          &lt;FileSearch text="450x300 px (10 MB 이하) 권장" /&gt;
        </GuideSubBox>
        <GuideBox>
          <FileSearch text="450x300 px (10 MB 이하) 권장" $position="bottom" />
        </GuideBox>
        <GuideSubBox>
          &lt;FileSearch text="450x300 px (10 MB 이하) 권장" $position="bottom"
          /&gt;
        </GuideSubBox>
        <GuideBox>
          <FileSearch text="* jpg, png 파일만 가능" dnd />
        </GuideBox>
        <GuideSubBox>
          &lt;FileSearch text="* jpg, png 파일만 가능" dnd /&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TooltipGuide;

import React from 'react';
import styled from 'styled-components';

interface StepProps {
  $active: boolean;
  $borderBottom: string;
  $border: string;
}

interface StepTextProps {
  $active: boolean;
  $textColor: string;
}

interface TextProgressProps {
  steps: string[];
  current: number;
  borderBottom: string;
  textColor: string;
  border: string;
}

const StepProgressContainer = styled.div`
  display: flex;
  width: 100%;
  height: 5px;
  border-radius: 10px;
`;

const Step = styled.div<StepProps>`
  position: relative;
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  &::before {
    content: '';
    position: absolute;
    left: 50%;
    bottom: 0;
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    box-sizing: border-box;
    background: #fff;
    border-width: 2px;
    border-style: solid;
    border-color: ${(props) =>
      props.$active ? props.$border || '#05b0a8' : '#ddd'};
  }
  &:last-child::before {
    left: auto;
    right: 50%;
  }
  &::after {
    content: '';
    height: 2px;
    width: 100%;
    border-bottom-width: 2px;
    border-bottom-color: ${(props) =>
      props.$active ? props.$borderBottom : '#ddd'};
    border-bottom-style: ${(props) => (props.$active ? 'solid' : 'dotted')};
    position: absolute;
    bottom: 2px;
    left: 50%;
    z-index: -1;
  }
  &:last-child::after {
    display: none;
  }
`;

const StepText = styled.span<StepTextProps>`
  position: relative;
  top: -10px;
  left: 0;
  flex: 1;
  min-width: 0;
  padding-bottom: 20px;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 1.5;
  color: ${(props) => (props.$active ? props.$textColor : '#bbb')};
  font-weight: 500;
  text-align: center;
`;

const TextProgress: React.FC<TextProgressProps> = ({
  steps,
  current,
  borderBottom,
  border,
  textColor,
}) => {
  const renderSteps = () => {
    return steps.map((step, index) => (
      <Step
        key={index}
        $active={index < current}
        $borderBottom={borderBottom}
        $border={border}
      >
        <StepText $active={index < current} $textColor={textColor}>
          {step}
        </StepText>
      </Step>
    ));
  };

  return <StepProgressContainer>{renderSteps()}</StepProgressContainer>;
};

export default TextProgress;

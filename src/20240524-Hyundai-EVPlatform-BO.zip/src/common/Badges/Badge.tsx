import { BadgeStyle, BadgeText } from './StyledBadges';

export interface BadgeProps {
  children?: any;
  $blue?: any;
  $red?: any;
  $small?: any;
}

const Badge: React.FC<BadgeProps> = ({ children, $blue, $red, $small }) => {
  return (
    <BadgeStyle $blue={$blue} $red={$red} $small={$small}>
      <BadgeText $small={$small}>{children}</BadgeText>
    </BadgeStyle>
  );
};

export default Badge;

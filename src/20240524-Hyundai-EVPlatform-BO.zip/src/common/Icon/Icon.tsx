import { IconStyle } from './StyledIcon';

export interface IconProps {
  $name?: string;
  $widthSize?: number;
  $heightSize?: number;
  children?: any;
  onClick?: any;
}

const Icon: React.FC<IconProps> = ({
  $name,
  $widthSize,
  $heightSize,
  children,
  onClick,
}) => {
  return (
    <IconStyle
      className="icon"
      $name={$name && $name}
      $widthSize={$widthSize}
      $heightSize={$heightSize}
      onClick={onClick}
    >
      {children && <span className="blind-text">{children}</span>}
    </IconStyle>
  );
};

export default Icon;

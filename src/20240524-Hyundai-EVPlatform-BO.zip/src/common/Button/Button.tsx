import { ButtonStyle, ButtonIcon } from './StyledButton';

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  className?: string;
  children?: React.ReactNode;
  disabled?: any;
  onClick: React.MouseEventHandler<HTMLButtonElement>;
  $icon?: any;
  download?: any;
  $iconOnly?: boolean;
  isSelected?: any;
  $width?: any;
  $size: 'mini' | 'small' | 'large' | 'none';
  $variant:
    | 'primary'
    | 'secondaryBlue'
    | 'secondaryGray'
    | 'tertiary'
    | 'transparent'
    | 'transparentPurple'
    | 'none';
}

const Button: React.FC<ButtonProps> = ({
  id,
  children,
  disabled,
  className,
  onClick,
  $size,
  $variant,
  $icon,
  isSelected,
  $iconOnly,
  $width,
}) => {
  return (
    <>
      {$iconOnly ? (
        <ButtonIcon className={className} onClick={onClick}>
          <img src={`/images/icons/${$icon}.svg`} />
        </ButtonIcon>
      ) : (
        <ButtonStyle
          id={id}
          type="button"
          disabled={disabled}
          onClick={onClick}
          className={className}
          $size={$size}
          $variant={$variant}
          $icon={$icon}
          $width={$width}
          // $center={center}
          isSelected={isSelected}
        >
          {children}
        </ButtonStyle>
      )}
    </>
  );
};

export default Button;

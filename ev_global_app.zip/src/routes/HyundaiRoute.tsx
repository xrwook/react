import { Route, Routes } from 'react-router-dom';
import HyundaiBrandTest from '../pages/brand/HyundaiBrandTest';

const HyundaiRoute = () => {
  return (
    <Routes>
      <Route path="brand" element={<HyundaiBrandTest />} />
    </Routes>
  );
};

export default HyundaiRoute;
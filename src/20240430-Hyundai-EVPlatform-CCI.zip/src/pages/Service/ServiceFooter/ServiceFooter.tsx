import React from 'react';
import {
  FooterContainer,
  MenuIList,
  Menu,
  MenuItem,
  MenuLink,
  MenuText,
} from 'pages/Service/StyledService/ServiceFooter';

interface FooterProps {
  navOptions: {
    title: string;
    url: string;
    imageUrl: string;
    color?: string;
  }[];
}

const ServiceFooter: React.FC<FooterProps> = ({ navOptions }) => {
  return (
    <FooterContainer>
      <Menu>
        <MenuIList>
          {navOptions.map((option, index) => (
            <MenuItem key={index}>
              <MenuLink href={option.url}>
                <img src={option.imageUrl} alt={option.title} />
                <MenuText style={{ color: option.color }}>
                  {option.title}
                </MenuText>
              </MenuLink>
            </MenuItem>
          ))}
        </MenuIList>
      </Menu>
    </FooterContainer>
  );
};

export default ServiceFooter;

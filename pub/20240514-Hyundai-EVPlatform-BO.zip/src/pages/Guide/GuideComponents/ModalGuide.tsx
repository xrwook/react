import { useState } from 'react';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Modal from 'common/Modal/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import ModalFooter from 'common/Modal/ModalFooter';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const ModalGuide = () => {
  const [showModal, setShowModal] = useState(false);
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Modal</GuideText>
        <GuideBox>
          <button name="" onClick={() => setShowModal(true)}>
            Open Modal
          </button>
          {showModal && (
            <Modal
              width="500px"
              height="auto"
              onClose={() => setShowModal(false)}
            >
              <ModalHeader>Title</ModalHeader>
              <ModalContent>
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
                content
                <br />
              </ModalContent>
              <ModalFooter>footer</ModalFooter>
            </Modal>
          )}
        </GuideBox>
        <GuideSubBox>
          &lt;Modal width="" height="" onClose&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalHeader&gt;&lt;/ModalHeader&gt; <br />
          &nbsp;&nbsp;&nbsp;&lt;ModalContent&gt;&lt;/ModalContent&gt; <br />
          &lt;/Modal&gt;
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default ModalGuide;

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from 'common/Icon/Icon';
import Tooltip from 'common/Tooltip/Tooltip';
import {
  LnbWrap,
  LnbHeader,
  LnbHeaderLogo,
  LnbBody,
  LnbList,
  LnbItem,
  LnbFooter,
  SidebarDivider,
  SidebarButton,
  SidebarDragButton,
} from 'layout/StyledLayout';
import Dropdown from 'common/Dropdown/Dropdown';

export interface LnbProps {
  collapse?: boolean;
}

const Lnb: React.FC<LnbProps> = () => {
  const [collapse, setCollapse] = useState(false);
  const [language, setLanguage] = useState<any>('');
  const [selectText, setSelectText] = useState<any>('');

  useEffect(() => {
    const ariaLabel = document
      .querySelector<HTMLElement>('.lnb-footer button')
      ?.getAttribute('aria-label');
    const languageFirst = ariaLabel?.split(' : ')[0];
    const languageLast = ariaLabel?.split(' : ')[1];
    const result = languageFirst?.trim() === 'KO' ? '한국어' : languageFirst;
    const selectView = document?.querySelector<HTMLElement>('.dropdown-view');
    const languageText = `${languageFirst} ${languageLast}`;

    if (selectView) {
      selectView.innerText = selectText;
    }

    setSelectText(languageText);
    setLanguage(result);
  }, [selectText, language]);

  const handleSelect = () => {
    const ariaLabel = document
      .querySelector<HTMLElement>('.dropbox-view')
      ?.getAttribute('aria-label');

    const languageFirst = ariaLabel?.split(' : ')[0];
    const languageLast = ariaLabel?.split(' : ')[1];

    const languageText = `${languageFirst} ${languageLast}`;
    setSelectText(languageText);

    const selectView = document?.querySelector<HTMLElement>('.dropdown-view');
    if (selectView) {
      selectView.innerText = selectText;
    }

    const result = languageFirst?.trim() === 'KO' ? '한국어' : languageFirst;
    setLanguage(result);
  };

  const handleClick = () => {
    setCollapse(!collapse);
  };

  const iconSize: number = collapse ? 24 : 20;

  const languageOption = [
    {
      value: 'KO',
      label: 'KO : 한국어',
    },
    {
      value: 'EN',
      label: 'EN : English (United States)',
    },
    {
      value: 'FR',
      label: 'FR : French',
    },
    {
      value: 'ID',
      label: 'ID : Indonesian',
    },
  ];

  return (
    <LnbWrap className={collapse ? 'collapse' : ''}>
      <LnbHeader>
        <LnbHeaderLogo className="lnb-logo" />
      </LnbHeader>
      <LnbBody className="lnb-wrap">
        <LnbList className="lnb-list">
          <LnbItem>
            <div className="lnb-item-left">
              <Link to="#dashboard">
                {collapse ? (
                  <Tooltip
                    $direction={'right'}
                    message={'Dashboard'}
                    $auto={'auto'}
                  >
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-dashboard'}
                    />
                  </Tooltip>
                ) : (
                  <>
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-dashboard'}
                    />
                    Dashboard
                  </>
                )}
              </Link>
            </div>
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Link to="#All Menu">
                {collapse ? (
                  <Tooltip
                    $direction={'right'}
                    message={'All Menu'}
                    $auto={'auto'}
                  >
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-menu'}
                    />
                  </Tooltip>
                ) : (
                  <>
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-menu'}
                    />
                    All Menu
                  </>
                )}
              </Link>
            </div>

            {!collapse && (
              <Icon
                $widthSize={iconSize}
                $heightSize={iconSize}
                $name={'icon-arrow-right-16'}
              />
            )}
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Link to="#Bookmarks">
                {collapse ? (
                  <Tooltip
                    $direction={'right'}
                    message={'Bookmarks'}
                    $auto={'auto'}
                  >
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-bookmark-20'}
                    />
                  </Tooltip>
                ) : (
                  <>
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-bookmark-20'}
                    />
                    Bookmarks
                  </>
                )}
              </Link>
            </div>
          </LnbItem>
          <LnbItem>
            <div className="lnb-item-left">
              <Link to="#Bookmarks">
                {collapse ? (
                  <Tooltip
                    $direction={'right'}
                    message={'Recently Viewed'}
                    $auto={'auto'}
                  >
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-recently'}
                    />
                  </Tooltip>
                ) : (
                  <>
                    <Icon
                      $widthSize={iconSize}
                      $heightSize={iconSize}
                      $name={'icon-recently'}
                    />
                    Recently Viewed
                  </>
                )}
              </Link>
            </div>
          </LnbItem>
        </LnbList>
      </LnbBody>
      <LnbFooter className={collapse ? 'lnb-footer collapse' : 'lnb-footer'}>
        <div className="dropdown-group">
          <Icon
            $name="icon-translate-language"
            $widthSize={20}
            $heightSize={20}
          />
          <Dropdown
            $position="up"
            $transparent
            options={languageOption}
            defaultOption={{
              value: 'KO',
              label: 'KO : 한국어',
            }}
            onClick={handleSelect}
          />
        </div>
        <span className="normal-text">{language}</span>
      </LnbFooter>
      <SidebarDivider>
        <SidebarButton onClick={handleClick} />
        <SidebarDragButton />
      </SidebarDivider>
    </LnbWrap>
  );
};

export default Lnb;

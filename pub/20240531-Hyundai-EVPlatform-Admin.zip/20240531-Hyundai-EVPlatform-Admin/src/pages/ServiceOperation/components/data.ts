import ServiceOperationStatusRender from './ServiceOperationStatusRender';

export const ChargingStationStatusListcolumnDefs = [
  {
    headerName: '사업자',
    field: 'field1',
    minWidth: 150,
  },
  { headerName: '이름', field: 'field2', sortable: true, minWidth: 240 },
  { headerName: '주소 (권역)', field: 'field3', sortable: true, minWidth: 300 },
  {
    headerName: '충전기 갯수',
    field: 'field4',
    cellStyle: { textAlign: 'center' },
    headerClass: 'custom-align-center',
    minWidth: 94,
  },
  {
    headerName: '충전기 현황',
    field: 'field5',
    minWidth: 240,
    cellRenderer: ServiceOperationStatusRender,
  },
  {
    headerName: '태그',
    field: 'field6',
    minWidth: 200,
  },
  {
    headerName: '결제방식',
    field: 'field7',
    minWidth: 200,
  },
  {
    headerName: '인증방식',
    field: 'field8',
    minWidth: 120,
  },
];

export const ChargingStationStatusListrowData = [
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
  {
    field1: 'Hyundai Engineering',
    field2: 'Samsung Station HD Charging Station',
    field3: '6101 W Manchester Ave, Los Angeles, CA 90000',
    field4: '1',
    field5: '81',
    field6: 'tag',
    field7: 'E-pit, HMG PAY, NFC',
    field8: 'QR, NFC',
  },
];

export const ServiceOperationStatusRenderData = [
  {
    id: 3,
    current: 8,
    total: 10,
    iconWidthSize: 16,
    iconName: 'three',
  },
  {
    id: 2,
    current: 8,
    total: 10,
    iconWidthSize: 12,
    iconName: 'two',
  },
  {
    id: 1,
    current: 8,
    total: 10,
    iconWidthSize: 8,
    iconName: 'one',
  },
];

export const listPerPageSelectOption = [
  {
    value: '10',
    label: '10개씩보기',
  },
  {
    value: '15',
    label: '15개씩보기',
  },
  {
    value: '20',
    label: '20개씩보기',
  },
  {
    value: '30',
    label: '30개씩보기',
  },
];

export const dateSelectOption = [
  {
    value: '3',
    label: '기간 : 3개월',
  },
  {
    value: '6',
    label: '기간 : 6개월',
  },
  {
    value: '9',
    label: '기간 : 9개월',
  },
  {
    value: '12',
    label: '기간 : 12개월',
  },
];

export const selectSearchFilterOption = [
  {
    value: 'option01',
    label: 'option01',
  },
  {
    value: 'option02',
    label: 'option02',
  },
  {
    value: 'option03',
    label: 'option03',
  },
  {
    value: 'option04',
    label: 'option04',
  },
  {
    value: 'option05',
    label: 'option05',
  },
  {
    value: 'option06',
    label: 'option06',
  },
  {
    value: '최근 1주일',
    label: '최근 1주일',
  },
];

export const filterOption = [
  {
    value: '전체',
    label: '전체',
  },
  {
    value: 'option01',
    label: 'option01',
  },
  {
    value: 'option02',
    label: 'option02',
  },
  {
    value: 'option03',
    label: 'option03',
  },
  {
    value: 'option04',
    label: 'option04',
  },
  {
    value: 'option05',
    label: 'option05',
  },
  {
    value: 'option06',
    label: 'option06',
  },
  {
    value: '최근 1주일',
    label: '최근 1주일',
  },
];

export const ChargingStationStatusListOption = [
  {
    value: '현대글로비스',
    label: '현대글로비스',
  },
  {
    value: '현대엔지니어링',
    label: '현대엔지니어링',
  },
  {
    value: '현대자동차',
    label: '현대자동차',
  },
  {
    value: '차지비',
    label: '차지비',
  },
  {
    value: 'EV Service 1',
    label: 'EV Service 1',
  },
  {
    value: 'EV Service 2',
    label: 'EV Service 2',
  },
  {
    value: 'EV Service 3',
    label: 'EV Service 3',
  },
  {
    value: 'EV Service 4',
    label: 'EV Service 4',
  },
  {
    value: 'EV Service 5',
    label: 'EV Service 5',
  },
  {
    value: 'EV Service 6',
    label: 'EV Service 6',
  },
  {
    value: 'EV Service 7',
    label: 'EV Service 7',
  },
  {
    value: 'EV Service 8',
    label: 'EV Service 8',
  },
];

export const ChargingStationStatusListOption2 = [
  {
    value: '전체',
    label: '전체',
  },
  {
    value: '서울특별시',
    label: '서울특별시',
  },
  {
    value: '부산광역시',
    label: '부산광역시',
  },
  {
    value: '대구광역시',
    label: '대구광역시',
  },
  {
    value: '인천광역시',
    label: '인천광역시',
  },
  {
    value: '광주광역시',
    label: '광주광역시',
  },
  {
    value: '인천광역시',
    label: '인천광역시',
  },
  {
    value: '대전광역시',
    label: '대전광역시',
  },
  {
    value: '울산광역시',
    label: '울산광역시',
  },
  {
    value: '세종특별자치시',
    label: '세종특별자치시',
  },
];

export const ChargingStationStatusListOption3 = [
  {
    value: '전체',
    label: '전체',
  },
  {
    value: 'Plug & Charge',
    label: 'Plug & Charge',
  },
  {
    value: 'Public',
    label: 'Public',
  },
  {
    value: 'Employee-only',
    label: 'Employee-only',
  },
  {
    value: 'Residents-only',
    label: 'Residents-only',
  },
  {
    value: 'Customers-only',
    label: 'Customers-only',
  },
  {
    value: 'Free-Parking',
    label: 'Free-Parking',
  },
];

export const ChargingStationStatusListOption4 = [
  {
    value: '전체',
    label: '전체',
  },
  {
    value: 'HMG Pay',
    label: 'HMG Pay',
  },
  {
    value: 'NFC',
    label: 'NFC',
  },
  {
    value: 'IC카드',
    label: 'IC카드',
  },
];

export const ChargingStationStatusListOption5 = [
  {
    value: '전체',
    label: '전체',
  },
  {
    value: 'QR',
    label: 'QR',
  },
  {
    value: 'NFC',
    label: 'NFC',
  },
];

export const newsApiKey = 'pub_97975dc870625c92568f10bdbf1cb8a0f9a9';

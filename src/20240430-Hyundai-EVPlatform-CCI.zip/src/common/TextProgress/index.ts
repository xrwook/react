export { default } from './TextProgress';

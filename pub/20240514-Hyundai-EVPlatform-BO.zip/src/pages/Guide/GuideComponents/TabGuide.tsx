import { useState } from 'react';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Tab from 'common/Tab/Tab';
import CheckBoxGuide from './CheckBoxGuide';
import ButtonGuide from './ButtonGuide';
import BreadcrumbGuide from './BreadcrumbGuide';
import ModalGuide from './ModalGuide';
import TabRadio from 'common/TabRadio/TabRadio';
import TabRadioItem from 'common/TabRadio/TabRadioItem';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const TabGuide = () => {
  const BasetabData = [
    {
      name: 'Item 1',
      Component: CheckBoxGuide,
    },
    {
      name: 'Selected Item',
      Component: ButtonGuide,
    },
    {
      name: 'Item 3',
      Component: BreadcrumbGuide,
    },
    {
      name: 'Item 4',
      Component: ModalGuide,
    },
    {
      name: 'Item 5',
      Component: ButtonGuide,
    },
    {
      name: 'Item 6',
      Component: CheckBoxGuide,
    },
    {
      name: 'Item 7',
      Component: ModalGuide,
    },
  ];

  const [isSelected, setSelected] = useState(0);

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Tab</GuideText>
        <GuideBox>
          <Tab tabs={BasetabData} selected={isSelected} onClick={setSelected} />
        </GuideBox>
      </StyledWrapper>
      <StyledWrapper>
        <GuideText>Tab Radio</GuideText>
        <GuideBox>
          <TabRadio>
            <TabRadioItem
              id="radio01"
              name="radio01"
              htmlFor="radio01"
              text="1주일"
              $borderfirst
              defaultChecked
            />
            <TabRadioItem
              id="radio02"
              name="radio01"
              htmlFor="radio02"
              text="1개월"
            />
            <TabRadioItem
              id="radio03"
              name="radio01"
              htmlFor="radio03"
              text="3개월"
            />
            <TabRadioItem
              id="radio04"
              name="radio01"
              htmlFor="radio04"
              text="직접입력"
              $borderlast
            />
          </TabRadio>
        </GuideBox>
        <GuideSubBox>
          &lt;Tab tabs="" selected="" onClick="" /&gt; <br />
        </GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default TabGuide;

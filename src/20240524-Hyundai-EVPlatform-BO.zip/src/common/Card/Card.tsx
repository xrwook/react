import { CardBox, CardFooter } from './StyledCard';

export interface CardProps {
  children?: any;
  $widthSize?: number;
}

const Card: React.FC<CardProps> = ({ children, $widthSize }) => {
  return (
    <CardBox $widthSize={$widthSize} className="card-box">
      {children}
      <CardFooter>Last Updated 2024-00-00 00:00</CardFooter>
    </CardBox>
  );
};

export default Card;

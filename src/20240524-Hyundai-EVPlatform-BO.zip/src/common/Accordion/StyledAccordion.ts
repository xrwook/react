import styled from 'styled-components';
import ArrowIcon from '/images/icons/icon-accordion-arrow.svg';
import { AccordionProps } from './Accordion';

export const AccordionItem = styled.div<AccordionProps>`
  display: block;
  margin-top: ${(props) => props.$marginTop};
`;

export const AccordionLayout = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 10px;
  border-bottom: 1px solid #d9d9d9;
`;

export const AccordionTitle = styled.div`
  padding: 4px 0;
  font-size: 20px;
  line-height: 24px;
  color: ${(props) => props.theme.color.gray10};
  font-weight: 500;
`;

export const AccordionArrow = styled.div`
  width: 20px;
  height: 20px;
  background: url(${ArrowIcon}) no-repeat;
  transition: all 0.3s;

  &.open {
    transform: rotate(-180deg);
  }
`;

export const AccordionLayer = styled.div`
  height: auto;
  padding-top: 24px;
`;

import styled, { css } from 'styled-components';
import React, { FC } from 'react';

interface SizeStyles {
  [key: string]: ReturnType<typeof css>;
}

interface VariantStyles {
  [key: string]: ReturnType<typeof css>;
}

interface BasicButtonProps {
  children: React.ReactNode;
  disabled?: boolean;
  variant?: 'primary' | 'outline' | 'positive' | 'tertiary';
  size?: 'small' | 'medium' | 'large';
  onClick?: () => void;
  key?: React.Key;
}

const sizeStyles: SizeStyles = {
  small: css`
    padding: 0.5rem 1.6rem;
    min-height: 2.125rem;
  `,
  medium: css`
    padding: 0.75rem 0.4rem;
    min-height: 2.625rem;
  `,
  large: css`
    padding: 1rem 3.2rem;
    min-height: 3.125rem;
  `,
};

const variantStyles: VariantStyles = {
  primary: css`
    background-color: ${({ theme }) => theme.color.primary};
    &:active {
      background-color: ${({ theme }) => theme.color.purpleprimary};
    }
  `,
  tertiary: css`
    background-color: ${({ theme }) => theme.color.white};
    color: ${({ theme }) => theme.color.tertiary};
    border-color: #dadce4;
  `,
  outline: css`
    border-color: ${({ theme }) => theme.color.primary};
    color: ${({ theme }) => theme.color.primary};
    background-color: transparent;
    &:active {
      background-color: ${({ theme }) => theme.color.secandary};
    }
    &:hover {
      color: ${({ theme }) => theme.color.white};
      background-color: ${({ theme }) => theme.color.primary};
    }
  `,
  positive: css`
    background-color: ${({ theme }) => theme.color.positive};
  `,
};

export const BaseButton = styled.button<{
  $size: 'small' | 'medium' | 'large';
  $variant: 'primary' | 'outline' | 'positive' | 'tertiary';
}>`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: 1;
  width: 100%;
  border-radius: 4px;
  font-weight: 700;
  color: ${({ theme }) => theme.color.white};
  border: 1px solid transparent;
  box-sizing: border-box;
  ${({ $size }) => sizeStyles[$size]}
  ${({ $variant }) => variantStyles[$variant]}
  ${(props) =>
    props.disabled &&
    css`
      cursor: default;
      color: ${({ theme }) => theme.color.white};
      background-color: ${({ theme }) => theme.color.disabled};
      border-color: ${({ theme }) => theme.color.disabled};
      &:hover,
      &:focus,
      &:active {
        background-color: ${({ theme }) => theme.color.disabled};
        border-color: ${({ theme }) => theme.color.disabled};
      }
      span {
        &::before,
        &::after {
          background-color: ${({ theme }) => theme.color.white};
        }
      }
    `}
`;

export const BasicButton: FC<BasicButtonProps> = ({
  children,
  disabled,
  variant = 'primary',
  size = 'medium',
  onClick,
  key,
}) => {
  return (
    <BaseButton
      type="button"
      $variant={variant}
      $size={size}
      disabled={disabled}
      onClick={onClick}
      key={key}
    >
      {children}
    </BaseButton>
  );
};

BaseButton.defaultProps = {
  $variant: 'primary',
  $size: 'medium',
};

export default BasicButton;

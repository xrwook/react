import styled from 'styled-components';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Icon from 'common/Icon/Icon';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const Layout = styled.div`
  display: flex;
`;

const IconGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Icon</GuideText>
        <GuideBox>
          <Layout>
            <Icon $widthSize={16} $heightSize={16} $name={'icon-minus'}>
              축소하기
            </Icon>
            <Icon $widthSize={20} $heightSize={20} $name={'icon-home'}>
              홈
            </Icon>
            <Icon $widthSize={24} $heightSize={24} $name={'icon-lnb-bookmark'}>
              즐겨찾기
            </Icon>
            <Icon $widthSize={32} $heightSize={32} $name={'icon-pin'}>
              위치
            </Icon>
            <Icon $widthSize={48} $heightSize={48} $name={'icon-pin'}>
              위치
            </Icon>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Icon {`$widthSize={16} $heightSize={16} $name={'icon-minus'}`}{' '}
          /&gt;
          <br />
          &lt;Icon {`$widthSize={20} $heightSize={20} $name={'icon-home'}`}{' '}
          /&gt;
          <br />
          &lt;Icon{' '}
          {`$widthSize={24} $heightSize={24} $name={'icon-lnb-bookmark'}`} /&gt;
        </GuideSubBox>
        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>$widthSize</td>
              <td>{`$widthSize={16}`}</td>
              <td>icon width size</td>
              <td></td>
            </tr>
            <tr>
              <td>$heightSize</td>
              <td>{`$heightSize={16}`}</td>
              <td>icon height size</td>
              <td></td>
            </tr>
            <tr>
              <td>$name</td>
              <td>{`$name={'icon-lnb-bookmark'}`}</td>
              <td>icon 이미지 파일명</td>
              <td>{`$name.svg`} 로 표현됨</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default IconGuide;

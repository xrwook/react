import { useState } from 'react';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
// import GuideSubBox from './GuideBox/GuideSubBox';
import Select from 'common/Select/Select';
import SelectAllCheck, { Option } from 'common/SelectAllCheck/SelectAllCheck';
import SelectSearch from 'common/SelectSearch/SelectSearch';

const SelectGuide = () => {
  const [optionSelected, setSelected] = useState<Option[] | null>();
  const [optionSelected2, setSelected2] = useState<Option[] | null>();
  const handleChange = (selected: Option[]) => {
    setSelected(selected);
  };
  const handleChange2 = (selected: Option[]) => {
    setSelected2(selected);
  };

  const options = [
    {
      value: 'option01option01option01',
      label: 'option01option01option01',
    },
    {
      value: 'option02option02',
      label: 'option02option02',
    },
    {
      value: 'option03option03',
      label: 'option03option03',
    },
    {
      value: 'option04option04',
      label: 'option04option04',
    },
    {
      value: 'option06option06',
      label: 'option06option06',
    },
    {
      value: 'option07option07',
      label: 'option07option07',
    },
    {
      value: 'option08option08',
      label: 'option08option08',
    },
  ];
  const option = [
    {
      value: '옵션1',
      label: '옵션1',
    },
    {
      value: '옵션2',
      label: '옵션2',
    },
    {
      value: '옵션3',
      label: '옵션3',
    },
    {
      value: '옵션4',
      label: '옵션4',
    },
  ];
  const optionscolor = [
    {
      value: 'option01',
      label: '빨강',
    },
    {
      value: 'option02',
      label: '노랑',
    },
    {
      value: 'option03',
      label: '초록',
    },
    {
      value: 'option04',
      label: '파랑',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Select</GuideText>
        <GuideBox>
          <Select
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
          />
          <Select
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            isMulti
            hideSelectedOptions={false}
          />
          <Select
            options={options}
            classNamePrefix="react-select"
            defaultValue={options[0]}
            disabled
          />
          <Select
            options={options}
            classNamePrefix="react-select"
            defaultValue={options[0]}
            readonly
          />
          <Select
            options={options}
            classNamePrefix="react-select"
            defaultValue={options[0]}
            $transparent
          />
          <Select
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            $checkbox
            isMulti
            hideSelectedOptions={false}
          />
          <Select
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            $checkbox
            $button
            isMulti
            hideSelectedOptions={false}
          />
        </GuideBox>
        {/* <GuideSubBox>
          &lt;Select placeholder="" options="" defaultValue="" error disabled
          /&gt;
          <br />
          &lt;Select placeholder="" options="" isMulti="" hideSelectedOptions=""
          /&gt;
        </GuideSubBox> */}
      </StyledWrapper>

      <StyledWrapper>
        <GuideText>Select Search</GuideText>
        <GuideBox>
          <SelectSearch
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            $button
            $checkbox
          />
          <SelectSearch
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            $button
            $checkbox
            $menuTitle="Content Title"
          />
        </GuideBox>
      </StyledWrapper>

      <StyledWrapper>
        <GuideText>Select All Check</GuideText>
        <GuideBox>
          <SelectAllCheck
            placeholder="선택해주세요"
            options={optionscolor}
            isMulti
            hideSelectedOptions={false}
            classNamePrefix="react-select"
            isSelectAll={true}
            onChange={handleChange}
            value={optionSelected}
            $button
          />
          <SelectAllCheck
            options={option}
            isMulti
            defaultValue={option[1]}
            hideSelectedOptions={false}
            classNamePrefix="react-select"
            isSelectAll={true}
            onChange={handleChange2}
            value={optionSelected2}
          />
          <SelectAllCheck
            options={options}
            isMulti
            hideSelectedOptions={false}
            defaultValue={options[1]}
            classNamePrefix="react-select"
            isSelectAll={true}
            onChange={handleChange}
            value={optionSelected}
            disabled
          />
          <SelectAllCheck
            options={option}
            isMulti
            hideSelectedOptions={false}
            defaultValue={option[1]}
            classNamePrefix="react-select"
            isSelectAll={true}
            onChange={handleChange}
            value={optionSelected}
            readonly
          />
          <SelectAllCheck
            options={option}
            isMulti
            hideSelectedOptions={false}
            defaultValue={option[1]}
            classNamePrefix="react-select"
            isSelectAll={true}
            onChange={handleChange}
            value={optionSelected}
            $transparent
          />
        </GuideBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default SelectGuide;

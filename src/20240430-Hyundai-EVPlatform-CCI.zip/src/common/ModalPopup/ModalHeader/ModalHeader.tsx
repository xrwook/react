import React from 'react';
import styled from 'styled-components';
import PopupButton, { ButtonIconProps } from 'common/PopupButton/PopupButton';

const ModalHeaderWrapper = styled.div<{ $isOpen: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px;
`;

const ModalIconRight = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;

const ModalTitle = styled.h2`
  flex: 1;
  font-size: ${(props) => props.theme.fontSize.fontSize7};
  text-align: center;
`;

export interface ModalHeaderProps {
  onClose: () => void;
  leftIcon?: ButtonIconProps;
  rightIcon?: ButtonIconProps;
  children?: React.ReactNode;
}

const ModalHeader: React.FC<ModalHeaderProps> = ({
  onClose,
  rightIcon,
  children,
}) => {
  return (
    <ModalHeaderWrapper $isOpen={false}>
      <ModalTitle>{children}</ModalTitle>
      <ModalIconRight>
        {rightIcon && <PopupButton icon={rightIcon.icon} onClick={onClose} />}
      </ModalIconRight>
    </ModalHeaderWrapper>
  );
};

export default ModalHeader;

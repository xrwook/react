import React from 'react';
import { Link } from 'react-router-dom';
import PageTitle from './GuideComponents/GuideTitle';
import GuideTable from './GuideComponents/GuideTable';
import GuideWrapper from './GuideComponents/GuideBox/GuideWrapper';

interface LogItem {
  date: string;
  text: string;
}

interface SubData {
  id: string;
  depth2: string;
  depth3: string;
  depth4: string;
  path: string;
  status: string;
  create: string;
  update: string;
  log: LogItem[];
}

interface Data {
  depth1: string;
  below: SubData[];
}

interface PublishingListProps {
  data: Data[];
}

const PublishingList: React.FC<PublishingListProps> = ({ data }) => {
  const formatDate = (date: Date) => {
    const d = new Date(date);
    const month = `${d.getMonth() + 1}`;
    const day = `${d.getDate()}`;
    const year = d.getFullYear();
    const format = `${year}.${`00${month}`.slice(-2)}.${`00${day}`.slice(-2)}`;

    return format;
  };

  const theadTitle: string[] = [
    'NO',
    'ID',
    'depth2',
    'depth3',
    'depth4',
    'path',
    'status',
    'create',
    'update',
    'log',
  ];

  return (
    <>
      <GuideWrapper>
        <div style={{ padding: '50px' }}>
          <div style={{ marginBottom: '30px' }}>
            <Link
              to="/guidelist"
              style={{
                textDecoration: 'none',
                color: '#3a5ee5',
                fontSize: '16px',
                padding: '10px 20px',
                borderRadius: '10px',
                backgroundColor: '#e0e0e0',
              }}
            >
              &#8592; Guide List
            </Link>
          </div>
          {data.map((data, idx) => (
            <div key={idx}>
              <PageTitle>{data.depth1}</PageTitle>
              <div>
                <GuideTable>
                  <colgroup>
                    <col width="50px" />
                    <col width="150px" />
                    <col width="120px" />
                    <col width="120px" />
                    <col width="120px" />
                    <col width="200px" />
                    <col width="80px" />
                    <col width="90px" />
                    <col width="90px" />
                    <col />
                  </colgroup>
                  <thead>
                    <tr>
                      {theadTitle.map((title, index) => (
                        <th key={index}>{title}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {data.below &&
                      data.below.map((subdata, subIdx) => (
                        <tr key={subIdx}>
                          <td>{subIdx + 1}</td>
                          <td>
                            <Link to={subdata.path} target="_blank">
                              {subdata.id}
                            </Link>
                          </td>
                          <td>
                            <Link to={subdata.path} target="_blank">
                              {subdata.depth2}
                            </Link>
                          </td>
                          <td>
                            <Link to={subdata.path} target="_blank">
                              {subdata.depth3}
                            </Link>
                          </td>
                          <td>
                            <Link to={subdata.path} target="_blank">
                              {subdata.depth4}
                            </Link>
                          </td>
                          <td>
                            <Link to={subdata.path} target="_blank">
                              {subdata.path}
                            </Link>
                          </td>
                          <td>
                            {subdata.status === '진행' && (
                              <span className="badge ing">
                                {subdata.status}
                              </span>
                            )}
                            {subdata.status === '수정' && (
                              <span className="badge modify">
                                {subdata.status}
                              </span>
                            )}
                            {subdata.status === '완료' && (
                              <span className="badge complete">
                                {subdata.status}
                              </span>
                            )}
                          </td>
                          <td>{subdata.create}</td>
                          <td>{subdata.update}</td>
                          <td>
                            <ul>
                              {subdata.log.map((item, logIdx) => (
                                <li
                                  className={`
                              ${formatDate(new Date()) === item.date && 'highlight'}`}
                                  key={logIdx}
                                >
                                  <span>[{item.date}]</span>
                                  {item.text}
                                </li>
                              ))}
                            </ul>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </GuideTable>
              </div>
            </div>
          ))}
        </div>
      </GuideWrapper>
    </>
  );
};

export default PublishingList;

import { Link } from 'react-router-dom';
import Breadcrumb from 'common/Breadcrumb/Breadcrumb';
import BreadcrumbHome from 'common/Breadcrumb/BreadcrumbHome';
import BreadcrumbLink from 'common/Breadcrumb/BreadcrumbLink';
import { HeaderWrap, HeaderProfileWrap } from './StyledLayout';

const Header: React.FC = () => {
  return (
    <HeaderWrap>
      <Breadcrumb>
        <BreadcrumbHome to="/" />
        <BreadcrumbLink to="/">충전소 운영 관리</BreadcrumbLink>
        <BreadcrumbLink to="/" className="active">
          충전소관리
        </BreadcrumbLink>
      </Breadcrumb>

      <HeaderProfileWrap>
        <figure>
          <img src="/images/dummy/profile-img.png" alt="프로필 사진" />
          <figcaption>hyundai.kim@hyundai-autoever.com</figcaption>
        </figure>
        <div className="profile-popover">
          <ul className="profile-popover-list">
            <li className="profile-popover-item">
              <span className="profile-popover-item__name">
                김오토 (테넌트 운영자)
              </span>
              <span className="profile-popover-item__info">
                hyundai.kim@hyundai-autoever.com
              </span>
            </li>
            <li className="profile-popover-item">
              <Link to={'#mypage'}>마이페이지</Link>
            </li>
            <li className="profile-popover-item">
              <Link to={'#logout'}>로그아웃</Link>
            </li>
          </ul>
        </div>
      </HeaderProfileWrap>
    </HeaderWrap>
  );
};

export default Header;

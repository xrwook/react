import { AlertHeaderWrapper } from './StyledAlert';

export interface AlertHeaderProps {
  children?: any;
}

const AlertHeader: React.FC<AlertHeaderProps> = ({ children }) => {
  return (
    <>
      <AlertHeaderWrapper>{children}</AlertHeaderWrapper>
    </>
  );
};

export default AlertHeader;

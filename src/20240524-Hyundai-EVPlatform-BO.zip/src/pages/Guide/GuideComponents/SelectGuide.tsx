import { useState } from 'react';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideTable from './GuideTable';
import GuideSubBox from './GuideBox/GuideSubBox';
import Select from 'common/Select/Select';
import SelectAllCheck, { Option } from 'common/SelectAllCheck/SelectAllCheck';
import SelectSearch from 'common/SelectSearch/SelectSearch';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';

const SelectGuide = () => {
  const [optionSelected, setSelected] = useState<Option[] | null>();
  const [optionSelected2, setSelected2] = useState<Option[] | null>();
  const handleChange = (selected: Option[]) => {
    setSelected(selected);
  };
  const handleChange2 = (selected: Option[]) => {
    setSelected2(selected);
  };

  const options = [
    {
      value: 'option01option01option01',
      label: 'option01option01option01',
    },
    {
      value: 'option02option02',
      label: 'option02option02',
    },
    {
      value: 'option03option03',
      label: 'option03option03',
    },
    {
      value: 'option04option04',
      label: 'option04option04',
    },
    {
      value: 'option06option06',
      label: 'option06option06',
    },
    {
      value: 'option07option07',
      label: 'option07option07',
    },
    {
      value: 'option08option08',
      label: 'option08option08',
    },
  ];
  const option = [
    {
      value: '옵션1',
      label: '옵션1',
    },
    {
      value: '옵션2',
      label: '옵션2',
    },
    {
      value: '옵션3',
      label: '옵션3',
    },
    {
      value: '옵션4',
      label: '옵션4',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Select</GuideText>
        <GuideBox>
          <Grid $columns={3} $gap="20px">
            <GridItem>
              <GuideText>
                <h3>Default Select - basic, multi</h3>
              </GuideText>
              <Select
                inputId="Select01"
                name="Select01"
                placeholder="Text"
                options={options}
                classNamePrefix="react-select"
              />
              <br />
              <Select
                inputId="Select03"
                name="Select03"
                options={options}
                classNamePrefix="react-select"
                placeholder="Text"
                defaultValue={options[0]}
                disabled
              />
              <br />
              <Select
                inputId="Select04"
                name="Select04"
                options={options}
                classNamePrefix="react-select"
                placeholder="Text"
                defaultValue={options[0]}
                readonly
              />
              <br />
              <Select
                $all={true}
                inputId="Select06"
                name="Select06"
                placeholder="Text"
                options={options}
                classNamePrefix="react-select"
                $checkbox
                $button
                isMulti
                hideSelectedOptions={false}
              />
              <br />
              <Select
                inputId="Select05"
                name="Select05"
                options={options}
                classNamePrefix="react-select"
                placeholder="Text"
                defaultValue={options[0]}
                $transparent
              />
            </GridItem>
            <GridItem>
              <GuideText>
                <h3>Select Search - basic, title</h3>
              </GuideText>
              <SelectSearch
                $all
                isMulti
                inputId="Select08"
                name="Select08"
                placeholder="Text"
                options={options}
                classNamePrefix="react-select"
                $button
                $checkbox
                defaultValue={options[0]}
              />
              <br />
              <SelectSearch
                inputId="Select089"
                name="Select089"
                placeholder="Text"
                options={options}
                classNamePrefix="react-select"
                $button
                $checkbox
                $menuTitle="Content Title"
                defaultValue={options[0]}
              />
            </GridItem>
            <GridItem>
              <GuideText>
                <h3>Select All Check</h3>
              </GuideText>
              <SelectAllCheck
                inputId="Select11"
                name="Select11"
                options={option}
                isMulti
                defaultValue={option[1]}
                hideSelectedOptions={false}
                classNamePrefix="react-select"
                isSelectAll={true}
                onChange={handleChange2}
                value={optionSelected2}
                $checkbox
              />
              <br />
              <SelectAllCheck
                inputId="Select12"
                name="Select12"
                options={options}
                isMulti
                hideSelectedOptions={false}
                defaultValue={options[1]}
                classNamePrefix="react-select"
                isSelectAll={true}
                onChange={handleChange}
                value={optionSelected}
                disabled
                $checkbox
              />
              <br />
              <SelectAllCheck
                inputId="Select13"
                name="Select13"
                options={option}
                isMulti
                hideSelectedOptions={false}
                defaultValue={option[1]}
                classNamePrefix="react-select"
                isSelectAll={true}
                onChange={handleChange}
                value={optionSelected}
                readonly
                $checkbox
              />
              <br />
              <SelectAllCheck
                inputId="Select14"
                name="Select14"
                options={option}
                isMulti
                hideSelectedOptions={false}
                defaultValue={option[1]}
                classNamePrefix="react-select"
                isSelectAll={true}
                onChange={handleChange}
                value={optionSelected}
                $transparent
                $checkbox
              />
            </GridItem>
          </Grid>
        </GuideBox>

        <GuideSubBox>
          {`<Select
            $all={true}
            inputId="Select06"
            name="Select06"
            placeholder="Text"
            options={options}
            classNamePrefix="react-select"
            $checkbox
            $button
            isMulti
            hideSelectedOptions={false}
            $transparent
          />`}
          <br />
          <br />
          {`<SelectSearch
              inputId="Select089"
              name="Select089"
              placeholder="Text"
              options={options}
              classNamePrefix="react-select"
              $button
              $checkbox
              $menuTitle="Content Title"
              defaultValue={options[0]}
            />`}
          <br />
          <br />
          {`<SelectAllCheck
              inputId="Select14"
              name="Select14"
              options={option}
              isMulti
              hideSelectedOptions={false}
              defaultValue={option[1]}
              classNamePrefix="react-select"
              isSelectAll={true}
              onChange={handleChange}
              value={optionSelected}
              $transparent
              $checkbox
            />`}
        </GuideSubBox>

        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr style={{ backgroundColor: '#eee' }}>
              <th colSpan={4} style={{ textAlign: 'left', fontWeight: 'bold' }}>
                Select 컴포넌트
              </th>
            </tr>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>defaultValue</td>
              <td>{`defaultValue={options[0]}`}</td>
              <td>보여줄 default option 값 선택</td>
              <td></td>
            </tr>
            <tr>
              <td>readonly</td>
              <td>readonly</td>
              <td>읽기만 가능</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>isMulti</td>
              <td>isMulti</td>
              <td>멀티 셀렉트 기능</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$checkbox</td>
              <td>$checkbox</td>
              <td>option 리스트 앞에 checkbox 추가</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$button</td>
              <td>$button</td>
              <td>하단에 초기화, 적용 버튼 추가</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>hideSelectedOptions</td>
              <td>{`hideSelectedOptions={false}`}</td>
              <td>선택된 옵션을 리스트에서 숨기는 기능</td>
              <td>true/false</td>
            </tr>
            <tr>
              <td>$transparent</td>
              <td>$transparent</td>
              <td>라인박스 없는 디자인 적용</td>
              <td>boolean</td>
            </tr>
            <tr style={{ backgroundColor: '#eee' }}>
              <td colSpan={4} style={{ textAlign: 'left', fontWeight: 'bold' }}>
                SelectSearch 컴포넌트
              </td>
            </tr>
            <tr>
              <td>$all</td>
              <td>$all</td>
              <td>SelectSearch 에서 전체 선택 기능</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$menuTitle</td>
              <td>{`$menuTitle="Content Title"`}</td>
              <td>옵션 dropbox 내 타이틀 지정</td>
              <td></td>
            </tr>
            <tr>
              <td>$menuTitle</td>
              <td>{`$menuTitle="Content Title"`}</td>
              <td>옵션 dropbox 내 타이틀 지정</td>
              <td></td>
            </tr>
            <tr style={{ backgroundColor: '#eee' }}>
              <td colSpan={4} style={{ textAlign: 'left', fontWeight: 'bold' }}>
                Select All Cheack 컴포넌트
              </td>
            </tr>
            <tr>
              <td>isSelectAll</td>
              <td>{`isSelectAll={true}`}</td>
              <td>전체 선택</td>
              <td>항상 켜져있는 옵션</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default SelectGuide;

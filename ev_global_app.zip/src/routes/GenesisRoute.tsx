import { Route, Routes } from 'react-router-dom';
import GenesisBrandTest from '../pages/brand/GenesisBrandTest';

const GenesisRoute = () => {
  return (
    <Routes>
      <Route path="brand" element={<GenesisBrandTest />} />
    </Routes>
  );
};

export default GenesisRoute;

import { components } from 'react-select';

const DefaultOption = (props: any) => (
  <components.Option {...props}>{props.label}</components.Option>
);

export default DefaultOption;

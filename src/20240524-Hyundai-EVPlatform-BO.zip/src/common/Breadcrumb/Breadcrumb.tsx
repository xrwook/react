import { BreadcrumbWrapper } from './StyledBreadcrumb';

export interface BreadcrumbHomeProps {
  children?: any;
}

const Breadcrumb: React.FC<BreadcrumbHomeProps> = ({ children }) => {
  return <BreadcrumbWrapper>{children}</BreadcrumbWrapper>;
};

export default Breadcrumb;

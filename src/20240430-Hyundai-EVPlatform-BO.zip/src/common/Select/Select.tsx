import ReactSelect from 'react-select';

export interface SelectProps {
  options?: any;
  placeholder?: any;
  isMulti?: any;
  hideSelectedOptions?: any;
  className?: any;
  title?: any;
  classNamePrefix: string;
  defaultValue?: any;
  required?: any;
  disabled?: any;
  error?: any;
  id?: any;
}

const Select: React.FC<SelectProps> = ({
  options,
  placeholder,
  isMulti,
  hideSelectedOptions,
  className,
  classNamePrefix,
  defaultValue,
  disabled,
  id,
}) => {
  return (
    <ReactSelect
      id={id}
      options={options}
      placeholder={placeholder}
      isMulti={isMulti}
      hideSelectedOptions={hideSelectedOptions}
      className={`
      ${className || ''}
      
    `}
      classNamePrefix={classNamePrefix}
      defaultValue={defaultValue}
      isDisabled={disabled}
    />
  );
};

export default Select;

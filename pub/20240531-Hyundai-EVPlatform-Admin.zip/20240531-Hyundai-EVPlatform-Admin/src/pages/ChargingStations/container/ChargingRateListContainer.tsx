import Header from 'layout/Header';
import Title from 'common/Title';
import Button from 'common/Button';
import FilterChargingRateList from '../components/FilterChargingRateList';
import AgGrid from 'common/AgGrid';
import { listPerPageSelectOption } from '../components/data';
import {
  ChargingRateListcolumnDefs,
  ChargingRateListRowData,
} from '../components/detailData';

const ChargingRateListContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '충전소 운영 관리' },
    { to: '/', text: '충전 요금 관리', className: 'active' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="충전 요금 관리"
        $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
      >
        <Button
          onClick={() => {}}
          $size="large"
          $variant="primary"
          $width={104}
        >
          요금제 등록
        </Button>
      </Title>

      <FilterChargingRateList />

      <AgGrid
        rowData={ChargingRateListRowData}
        columnDefs={ChargingRateListcolumnDefs}
        hasPaging={true}
        hasGridTop={true}
        listPerPageSelectOption={listPerPageSelectOption}
        listPerPageDefaultOption={{
          value: '20',
          label: '20개씩보기',
        }}
      />
    </>
  );
};

export default ChargingRateListContainer;

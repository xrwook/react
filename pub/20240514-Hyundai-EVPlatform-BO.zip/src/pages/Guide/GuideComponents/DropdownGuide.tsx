import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Dropdown from 'common/Dropdown/Dropdown';

const DropdownGuide = () => {
  const option = [
    {
      value: 'option01option01',
      label: 'option01option01',
    },
    {
      value: 'option02option02',
      label: 'option02option02',
    },
    {
      value: 'option03option03',
      label: 'option03option03',
    },
    {
      value: 'option04option04',
      label: 'option04option04',
    },
  ];

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Dropdown</GuideText>
        <GuideBox>
          <Dropdown options={option} placeholder="Placeholder" />
          <Dropdown options={option} disabled placeholder="Placeholder" />
          <Dropdown options={option} $readOnly placeholder="Placeholder" />
          <Dropdown
            options={option}
            placeholder="Placeholder"
            $day
            $transparent
          />
        </GuideBox>
        <GuideSubBox>&lt;Dropdown /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default DropdownGuide;

import FilterList from 'common/Filter/FilterList';
import FilterItem from 'common/Filter/FilterItem';
import FilterLabel from 'common/Filter/FilterLabel';
import TextField from 'common/TextField';
import Select from 'common/Select/Select';
import Dropdown from 'common/Dropdown/Dropdown';
import { DropdownWrap } from 'common/Dropdown/StyledDropdown';
import {
  filterOption,
  ChargingRateListOption,
  ChargingRateListOption2,
} from './data';

const FilterChargingRateList: React.FC = () => {
  return (
    <FilterList useDetailButtons>
      <FilterItem $search>
        <TextField
          id="TextField01"
          name="text"
          type="text"
          placeholder="요금제 이름으로 검색"
          $search
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>상태 :</FilterLabel>
        <Select
          options={ChargingRateListOption}
          defaultValue={ChargingRateListOption[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>적용요금 :</FilterLabel>
        <Select
          options={ChargingRateListOption2}
          defaultValue={ChargingRateListOption2[0]}
          classNamePrefix="react-select"
          $transparent
        />
      </FilterItem>
      <FilterItem>
        <FilterLabel>기간 :</FilterLabel>
        <DropdownWrap>
          <Dropdown
            options={filterOption}
            $allText="전체"
            placeholder="전체"
            $day
            $transparent
          />
        </DropdownWrap>
      </FilterItem>
    </FilterList>
  );
};

export default FilterChargingRateList;

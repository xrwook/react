import { useEffect, useRef, useState } from 'react';
import Header from 'layout/Header';
import Title from 'common/Title';
import Accordion from 'common/Accordion/Accordion';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import FormControl from 'common/FormControl';
import Button from 'common/Button/Button';
import AgGridTop from 'common/AgGrid/AgGridTop';
import CardStatus from 'common/Card/CardStatus';
import Card from 'common/Card';
import CardHeader from 'common/Card/CardHeader';
import CardItem from 'common/Card/CardItem';
import AgGrid from 'common/AgGrid/AgGrid';
import Icon from 'common/Icon';
import PageFooter from 'common/PageFooter';
import FormFlex from 'common/FormFlex';
import { ContentContainer } from 'layout/StyledLayout';
import { FileAttachArea } from 'common/FileSearch/StyledFileSearch';
import { dateSelectOption } from '../components/data';
import {
  InfoList,
  NormalList,
  NormalText,
  Tags,
} from '../styled/StyledServiceOperation';
import {
  CardInfo,
  CardName,
  CardValue,
  CardWrap,
} from 'common/Card/StyledCard';
import {
  chargingStationsDetailOption,
  dailyUsageColumnDefs,
  dailyUsageRowData,
  reviewInfoColumnDefs,
  reviewInfoRowData,
} from '../components/detailData';

const ChargingStationStatusDetailContainer: React.FC = () => {
  const breadcrumbLinks = [
    { to: '/', text: '서비스 운영 관리' },
    { to: '/', text: '충전소 현황' },
    { to: '/', text: '충전소 상세', className: 'active' },
  ];

  const [cardTotalCnt, setCardTotalCnt] = useState<any>(0);
  const cardWrap = useRef<HTMLDivElement>(null);
  const cardTotal = cardWrap.current?.children.length;
  useEffect(() => {
    setCardTotalCnt(cardTotal);
  }, [cardTotal]);

  const images = [
    { id: 1, name: '/images/dummy/img-attach.png' },
    { id: 2, name: '/images/dummy/img-attach01.jfif' },
    { id: 3, name: '/images/dummy/img-attach02.jfif' },
  ];

  return (
    <>
      <Header breadcrumbLinks={breadcrumbLinks} />

      <Title
        titlemain="충전소 현황 상세"
        $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
      />

      <ContentContainer $gap="48px">
        <Accordion title="[충전소ID] ChargePoint Charging Station" open>
          <Grid $columns={2} $gap="19px 120px">
            <GridItem $colStart={1} $colEnd={2}>
              <FormControl title="충전소 주소" $detail $row>
                <FormFlex>
                  Charging Station Address, CA, 90001 (위도/경도 정보)
                  <Button $variant="tertiary" $size="mini" onClick={() => {}}>
                    지도 보기
                  </Button>
                </FormFlex>
              </FormControl>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="상세위치" $detail $row>
                주차장 오른쪽 맨 끝 5개면
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="충전소 유형/개방 형태" $detail $row>
                Public
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="시설 유형/구분" $detail $row>
                주차시설 / 일반주차장
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="사업자" $detail $row>
                {/* DD : 사업자 아이콘
                    icon-cpo-cp / icon-cpo-cpo6 / icon-cpo-ea / icon-cpo-evgo / icon-cpo-shell
                */}
                <Icon $widthSize={16} $heightSize={16} $name={'icon-cpo-cp'}>
                  ChargePoint 아이콘
                </Icon>
                <span style={{ paddingLeft: '8px' }}>ChargePoint</span>
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="운영 상태" $detail $row>
                운영중
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="요금제" $detail $row>
                <NormalText>
                  제휴 요금제
                  <Button $variant="tertiary" $size="mini" onClick={() => {}}>
                    요금제 상세
                  </Button>
                </NormalText>
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주차 가능 여부" $detail $row>
                유료 주차
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="운영 사업자" $detail $row>
                ChargePoint 직접운영 / 1-833-632-2778
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="위탁 사업자" $detail $row>
                -
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="결제 방식" $detail $row>
                E-pit, HMG PAY, NFC
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="인증 방식" $detail $row>
                QR, NFC
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="Tag" $detail $row>
                <Tags>
                  <span className="tag">Plug & Charge</span>
                  <span className="tag">Public</span>
                  <span className="tag">Employee-only </span>
                  <span className="tag">Residents-only </span>
                  <span className="tag">Customers-only</span>
                  <span className="tag">Free-Parking</span>
                </Tags>
              </FormControl>
            </GridItem>
            <GridItem $colStart={1} $colEnd={3}>
              <FormControl title="충전소 이미지" $detail $row>
                <FileAttachArea>
                  {images.map((image: any) => (
                    <div
                      className="file-attach-area"
                      key={image.id}
                      data-file={image.name.replace(/^.*\//, '')}
                    >
                      <img src={image.name} />
                    </div>
                  ))}
                </FileAttachArea>
              </FormControl>
            </GridItem>
          </Grid>
        </Accordion>
        <Accordion title="영업일 및 편의시설 정보" open>
          <Grid $columns={2} $gap="12px 128px">
            <GridItem>
              <FormControl title="영업 시간" $detail $row>
                월 09:00 ~ 20:00 <br />
                화 09:00 ~ 20:00 <br />
                수 09:00 ~ 20:00 <br />
                목 09:00 ~ 20:00 <br />
                금 09:00 ~ 20:00 <br />
                토 11:00 ~ 18:00 <br />일 휴일
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl title="주변 주요 시설" $detail $row>
                <NormalList>
                  <li className="normal-item">
                    <span>Restroom</span>
                    <span>Orange Town & Country Shopping Center</span>
                  </li>
                  <li className="normal-item">
                    <span>Wi-Fi</span>
                    <span>Free Wi-Fi</span>
                  </li>
                  <li className="normal-item">
                    <span>Restaurant</span>
                    <span>IN-N-OUT BURGER</span>
                  </li>
                  <li className="normal-item">
                    <span>Cafe</span>
                    <span>Starbucks</span>
                  </li>
                </NormalList>
              </FormControl>
            </GridItem>
          </Grid>
        </Accordion>

        <section className="content-section">
          <Title titlemain="충전기 현황 (12)" $pagetitle />
          <AgGridTop totalCount={cardTotalCnt} $marginTop={24}></AgGridTop>
          <CardWrap ref={cardWrap}>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="green" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="blue" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="gray" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
            <Card $widthSize={377}>
              <CardHeader>
                <CardStatus $color="red" status="Available" />
              </CardHeader>
              <CardItem>
                <CardName>충전기 이름 최대 20자까지 입력 가능</CardName>
                <CardInfo>Left</CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>커넥터 타입</CardValue>
                <CardInfo>
                  <Icon
                    $name="icon-CCS-Combo"
                    $widthSize={20}
                    $heightSize={20}
                  />
                  CCS Combo
                </CardInfo>
              </CardItem>
              <CardItem>
                <CardValue>속도</CardValue>
                <CardInfo>Super Fast (Max.150 kW)</CardInfo>
              </CardItem>
            </Card>
          </CardWrap>
        </section>
        <Accordion title="당일 이용 현황" open>
          <InfoList>
            <dt>충전 횟수</dt>
            <dd>1회</dd>
            <dt>충전량</dt>
            <dd>123kWh</dd>
            <dt>매출액</dt>
            <dd>100,000,000원</dd>
          </InfoList>
          <AgGrid
            rowData={dailyUsageRowData}
            columnDefs={dailyUsageColumnDefs}
            hasGridTop={true}
            noneButton
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={{
              value: '5',
              label: '5개씩보기',
            }}
          />
        </Accordion>

        <Accordion title="리뷰 정보" open>
          <AgGrid
            rowData={reviewInfoRowData}
            columnDefs={reviewInfoColumnDefs}
            hasGridTop={true}
            hasDate
            noneButton
            dateSelectOption={dateSelectOption}
            dateSelectDefaultOption={{
              value: '3',
              label: '기간 : 3개월',
            }}
            listPerPageSelectOption={chargingStationsDetailOption}
            listPerPageDefaultOption={{
              value: '5',
              label: '5개씩보기',
            }}
          />
        </Accordion>
      </ContentContainer>

      <PageFooter>
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          목록으로 돌아가기
        </Button>
      </PageFooter>
    </>
  );
};

export default ChargingStationStatusDetailContainer;

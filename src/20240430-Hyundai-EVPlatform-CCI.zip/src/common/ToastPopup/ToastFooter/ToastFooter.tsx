import React from 'react';
import styled from 'styled-components';

const ToastFooterWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1rem;
  padding: 24px 30px;
`;

export interface ToastFooterProps {
  children?: React.ReactNode;
}

const ToastFooter: React.FC<ToastFooterProps> = ({ children }) => {
  return <ToastFooterWrapper>{children}</ToastFooterWrapper>;
};

export default ToastFooter;

import AgGrid from 'common/AgGrid';
import {
  rowData,
  columnDefs,
  listPerPageSelectOption,
} from '../components/data';
import Title from 'common/Title';
import Button from 'common/Button';
import FilterList from '../components/FilterListComponent';

const ChargingStationsListContainer: React.FC = () => {
  return (
    <>
      <Title
        titlemain="충전소관리"
        $titlesub="Last Updated 2024-00-00 00:00, Created by minsu"
      >
        <Button onClick={() => {}} $size="large" $variant="secondaryBlue">
          일괄 등록
        </Button>
        <Button onClick={() => {}} $size="large" $variant="primary">
          충전소 등록
        </Button>
      </Title>
      <FilterList />
      <AgGrid
        rowData={rowData}
        columnDefs={columnDefs}
        hasPaging={true}
        hasGridTop={true}
        listPerPageSelectOption={listPerPageSelectOption}
        listPerPageDefalutOption={{
          value: '20',
          label: '20개씩보기',
        }}
      />
    </>
  );
};

export default ChargingStationsListContainer;

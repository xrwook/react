import {
  CheckboxWrapper,
  StyledCheckBoxText,
  StyledCheckbox,
} from './StyledCheckbox';

export interface CheckBoxProps {
  id?: string;
  name?: any;
  text?: any;
  htmlFor?: any;
  disabled?: any;
  checked?: any;
  defaultChecked?: any;
  className?: any;
}

const CheckBox: React.FC<CheckBoxProps> = ({
  id,
  name,
  text,
  htmlFor,
  disabled,
  checked,
  defaultChecked,
  className,
}) => {
  return (
    <>
      <CheckboxWrapper>
        <StyledCheckbox
          type="checkbox"
          id={id}
          name={name}
          disabled={disabled}
          checked={checked}
          defaultChecked={defaultChecked}
          className={className}
        />
        <label htmlFor={htmlFor}>
          {text && (
            <StyledCheckBoxText disabled={disabled}>{text}</StyledCheckBoxText>
          )}
        </label>
      </CheckboxWrapper>
    </>
  );
};

export default CheckBox;

import { Route, Routes } from 'react-router-dom';
import PublishingList from 'pages/Guide/PublishingList';
import publishdata from 'pages/Guide/publishdata';
import ChargingStationsListContainer from 'pages/ChargingStations/container/ChargingStationsListContainer';

const PublishingRoute: React.FC = () => (
  <Routes>
    <Route
      path="publishinglist"
      element={<PublishingList data={publishdata} />}
    ></Route>
    {routes.map(({ path, element }) => (
      <Route key={path} path={path} element={element} />
    ))}
  </Routes>
);

// router start
const routes = [
  {
    path: '/sub/ChargingStationsList',
    element: <ChargingStationsListContainer />,
  },
  // {
  //   path: '/first2',
  //   element: <ChargingStationsList />,
  //   children: [
  //     {
  //       path: 'messages',
  //       element: <ChargingStationsList />,
  //     },
  //     { path: 'tasks', element: <ChargingStationsList /> },
  //   ],
  // },
];

export default PublishingRoute;

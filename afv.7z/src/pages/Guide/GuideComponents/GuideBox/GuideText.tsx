import styled from 'styled-components';
import React from 'react';

export interface StyledGuideText {
  children?: React.ReactNode;
}

const StyledGuideText = styled.h1`
  font-size: ${(props) => props.theme.fontSize.fontSize7};
  font-weight: 700;
  margin-bottom: 15px;
`;

const GuideText: React.FC<StyledGuideText> = ({ children }) => {
  return <StyledGuideText>{children}</StyledGuideText>;
};

export default GuideText;

import styled, { css } from 'styled-components';
import { CardStatusProps } from './CardStatus';

const color = {
  purple: css`
    background-color: #9747ff;
  `,
  blue: css`
    background-color: ${(props) => props.theme.color.blue};
  `,
  green: css`
    background-color: ${(props) => props.theme.color.green};
  `,
  gray: css`
    background-color: ${(props) => props.theme.color.gray4};
  `,
  yellow: css`
    background-color: ${(props) => props.theme.color.yellow};
  `,
  red: css`
    background-color: ${(props) => props.theme.color.textError};
  `,
};

export const CardBox = styled.div<{ $widthSize?: number }>`
  display: inline-block;
  min-width: 337px;
  width: auto;
  height: auto;
  padding: 17px 19px;
  border: 1px solid ${(props) => props.theme.color.gray2};
  border-radius: 8px;
  ${(props) =>
    props.$widthSize &&
    css`
      width: ${props.$widthSize}px;
    `}

  & + & {
    margin-left: 12px;
  }
`;

export const CardHeaderLayout = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
`;

export const CardItemLayout = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  line-height: 20px;
  font-weight: 400;

  + * {
    margin-top: 6px;
  }
`;

export const CardValue = styled.div`
  color: ${(props) => props.theme.color.black};
`;

export const CardName = styled.div`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  font-weight: 600;
  color: rgba(0, 0, 0, 0.9);
`;

export const CardInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  color: #000000b2;
`;

export const CardFooter = styled.div`
  margin-top: 10px;
  padding-top: 10px;
  font-size: ${(props) => props.theme.fontSize.fontSize1};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray4};
  border-top: 1px solid ${(props) => props.theme.color.gray1};
`;

export const Status = styled.div`
  display: flex;
  align-items: center;
`;

export const StatusColor = styled.span<CardStatusProps>`
  width: 10px;
  height: 10px;
  border-radius: 4px;
  margin-right: 6px;
  ${(props) => color[props.$color]};
`;

export const StatusText = styled.div`
  font-size: ${(props) => props.theme.fontSize.fontSize2};
  line-height: 24px;
  color: ${(props) => props.theme.color.gray8};
  font-weight: 500;
`;

export const CardWrap = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 12px;

  .card-box {
    margin-left: 0;
  }
`;

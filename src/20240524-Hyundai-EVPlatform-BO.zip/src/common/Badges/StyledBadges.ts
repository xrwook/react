import styled from 'styled-components';
import { BadgeProps } from './Badge';

export const BadgeStyle = styled.div<BadgeProps>`
  display: inline-block;
  width: auto;
  height: ${(props) => (props.$small ? '15px' : '18px')};
  padding: 0 5px;
  color: #ffffff;
  border-radius: 100px;
  background-color: ${(props) =>
    props.$blue
      ? `${props.theme.color.primary}`
      : props.$red
        ? `${props.theme.color.textError}`
        : `${props.theme.color.gray3}`};
`;

export const BadgeText = styled.div<BadgeProps>`
  font-size: ${(props) =>
    props.$small ? '9px' : `${props.theme.fontSize.fontSize1}`};
  line-height: ${(props) => (props.$small ? '15px' : '18px')};
  font-weight: 600;
`;

import { Dim, ModalBox, ModalClose, ModalWrapper } from './StyledModal';

export interface ModalProps {
  width?: string;
  height?: string;
  children?: any;
  oversize?: boolean;
  onClose(): void;
}

const Modal: React.FC<ModalProps> = ({
  width,
  height,
  children,
  onClose,
  oversize,
}) => {
  const handleCloseClick = (e: any) => {
    e.preventDefault();
    onClose();
  };

  return (
    <>
      <ModalWrapper $oversize={oversize}>
        <ModalBox width={width} height={height} $oversize={oversize}>
          <ModalClose
            type="button"
            aria-label="close"
            onClick={handleCloseClick}
          />
          {children}
        </ModalBox>
      </ModalWrapper>
      <Dim />
    </>
  );
};

export default Modal;

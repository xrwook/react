import { useRef, useEffect, useState } from 'react';
import flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.min.css';
import { Instance as FlatpickrInstance } from 'flatpickr/dist/types/instance';
import ReactDOM from 'react-dom';
import Button from 'common/Button';
import {
  GlobalStyles,
  DatePickerWrap,
  DatepickerTestInput,
  ButtonWrap,
  DatepickerBottom,
  Today,
} from './StyledDatepickedTest';
import { ButtonGroup } from 'common/Button/StyledButton';

export interface ButtonsPortalProps {
  close: () => void;
  select: () => void;
  $today?: any;
  $button?: any;
}

export interface DatepickerTestProps {
  mode: 'single' | 'range';
}

const ButtonsPortal = ({
  close,
  select,
  $today,
  $button,
}: ButtonsPortalProps) => (
  <DatepickerBottom $button={$button}>
    <Today $today={$today}>
      <Button onClick={close} $size="large" $variant="transparent">
        오늘 날짜로 이동
      </Button>
    </Today>
    <ButtonWrap $button={$button}>
      <Button onClick={close} $size="large" $variant="transparent">
        초기화
      </Button>
      <ButtonGroup $gap={8}>
        <Button onClick={select} $size="large" $variant="secondaryGray">
          취소
        </Button>
        <Button onClick={close} $size="large" $variant="primary">
          적용
        </Button>
      </ButtonGroup>
    </ButtonWrap>
  </DatepickerBottom>
);

const DatepickerTest = ({ mode }: DatepickerTestProps) => {
  const startInputRef = useRef<HTMLInputElement>(null);
  const endInputRef = useRef<HTMLInputElement>(null);
  const [instance, setInstance] = useState<FlatpickrInstance | null>(null);
  const fpRef = useRef<FlatpickrInstance | null>(null);

  useEffect(() => {
    if (startInputRef.current) {
      const fpOptions = {
        mode: mode,
        enableTime: false,
        dateFormat: 'Y-m-d',
        showMonths: mode === 'range' ? 2 : 1,
        closeOnSelect: false,
        onChange: (selectedDates: Date[]) => {
          if (mode === 'range' && selectedDates.length === 2) {
            startInputRef.current!.value = flatpickr.formatDate(
              selectedDates[0],
              'Y-m-d',
            );
            endInputRef.current!.value = flatpickr.formatDate(
              selectedDates[1],
              'Y-m-d',
            );
          }
        },
        onReady: (_: any, __: any, fpInstance: FlatpickrInstance) => {
          setInstance(fpInstance);
          fpRef.current = fpInstance;
        },
      };

      flatpickr(startInputRef.current, fpOptions);

      if (endInputRef.current) {
        endInputRef.current.addEventListener('click', () => {
          if (fpRef.current) {
            fpRef.current.open();
          }
        });
      }
    }

    return () => {
      instance?.destroy();
    };
  }, [mode]);

  return (
    <>
      <GlobalStyles />
      <DatePickerWrap>
        {mode === 'range' ? (
          <>
            <DatepickerTestInput
              ref={startInputRef}
              type="text"
              placeholder="YYYY.MM.DD"
              readOnly
            />
            <DatepickerTestInput
              ref={endInputRef}
              type="text"
              placeholder="YYYY.MM.DD"
              readOnly
            />
          </>
        ) : (
          <DatepickerTestInput
            ref={startInputRef}
            type="text"
            placeholder="YYYY.MM.DD"
            readOnly
          />
        )}

        {mode === 'range' ? (
          <>
            {instance &&
              ReactDOM.createPortal(
                <ButtonsPortal
                  close={() => instance.close()}
                  select={() => instance.close()}
                  $button
                />,
                instance.calendarContainer,
              )}
          </>
        ) : (
          <>
            {instance &&
              ReactDOM.createPortal(
                <ButtonsPortal
                  close={() => instance.close()}
                  select={() => instance.close()}
                  $today
                />,
                instance.calendarContainer,
              )}
          </>
        )}
      </DatePickerWrap>
    </>
  );
};

export default DatepickerTest;

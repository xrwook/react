import Button from 'common/Button';
import { defaultTheme } from 'react-select';
import { ReactNode, useEffect, useState } from 'react';
import CustomInput from 'common/CustomInput';
import CustomOption from 'common/CustomOption';
import DefaultOption from 'common/DefaultOption';

import {
  ArrowButton,
  Icon,
  MenuFooter,
  SelectInput,
  SelectStyle,
  SelectText,
} from '../Select/StyledSelect';
import {
  MenuContainer,
  MenuHeader,
  MenuTitle,
  MenuWrapper,
  MenuInner,
} from './StyledSelectSearch';

export type Option = {
  value: number | string;
  label: string;
  map?: any;
};

export interface SelectSearchProps {
  $checkbox?: any;
  classNamePrefix?: any;
  placeholder?: any;
  options?: any;
  $button?: any;
  label?: any;
  $menuTitle?: any;
  name?: any;
  inputId?: any;
  components?: any;
  $all?: boolean;
  isMulti?: any;
  $transparent?: any;
  defaultValue?: Option;
}

const SelectSearch: React.FC<SelectSearchProps> = ({
  $checkbox,
  classNamePrefix,
  placeholder,
  options,
  $button,
  $menuTitle,
  name,
  inputId,
  $all,
  isMulti,
  $transparent,
  defaultValue,
}) => {
  const defaultOption = defaultValue || null;
  const [value, setValue] = useState<Option | null>(
    defaultOption ? defaultOption : null,
  );
  const [$isOpen, setIsOpen] = useState(false);
  const { colors } = defaultTheme;
  const [selectedOptions, setSelectedOptions] = useState<Option | null>(
    $all ? { value: '*', label: '전체' } : defaultValue || null,
  );
  const [selectAll, setSelectAll] = useState<boolean>(false);
  useEffect(() => {
    setValue(selectedOptions);
  }, [selectedOptions]);

  const handleChange = (newValue: any) => {
    if (!isMulti && isMulti) {
      setIsOpen(false);
    }
    if ($all) {
      setSelectedOptions(newValue);
      setSelectAll(newValue?.length === options?.length);
    } else {
      setValue(newValue);
    }
    if (!isMulti) {
      setIsOpen(false);
    }
  };

  const handleReset = () => {
    setValue(null);
    setSelectedOptions({ value: '*', label: '전체' });
  };

  const handleApply = () => {
    setIsOpen(false);
  };

  const Menu = (props: any) => {
    return (
      <>
        <MenuContainer>
          <MenuHeader>
            <MenuTitle $menuTitle={$menuTitle}>{$menuTitle}</MenuTitle>
            <MenuWrapper>{props.children}</MenuWrapper>
          </MenuHeader>
          <MenuFooter $button={$button}>
            <Button onClick={handleReset} $size="small" $variant="transparent">
              초기화
            </Button>
            <Button
              onClick={handleApply}
              $size="small"
              $variant="transparentPurple"
            >
              적용
            </Button>
          </MenuFooter>
        </MenuContainer>
      </>
    );
  };

  const Blanket = (props: any) => <Icon {...props} />;

  const Dropdown = ({
    children,
    target,
    onClose,
  }: {
    children?: ReactNode;
    readonly $isOpen: boolean;
    readonly target: ReactNode;
    readonly onClose: () => void;
  }) => (
    <MenuInner>
      {target}
      {$isOpen ? <Menu>{children}</Menu> : null}
      {$isOpen ? <Blanket onClick={onClose} /> : null}
    </MenuInner>
  );
  const Svg = (p: any) => (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      focusable="false"
      role="presentation"
      {...p}
    />
  );
  const DropdownIndicator = () => (
    <span style={{ color: colors.neutral20, height: 24, width: 32 }}>
      <Svg>
        <path
          d="M16.436 15.085l3.94 4.01a1 1 0 0 1-1.425 1.402l-3.938-4.006a7.5 7.5 0 1 1 1.423-1.406zM10.5 16a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11z"
          fill="currentColor"
          fillRule="evenodd"
        />
      </Svg>
    </span>
  );

  const handleSelectAll = () => {
    if (!selectAll) {
      setSelectedOptions(options);
    } else {
      setSelectedOptions([] as any);
    }
    setSelectAll(!selectAll);
  };

  return (
    <Dropdown
      $isOpen={$isOpen}
      onClose={() => setIsOpen(false)}
      target={
        <SelectInput
          $transparent={$transparent}
          onClick={() => setIsOpen((prev) => !prev)}
        >
          <SelectText
            $textValue={
              Array.isArray(value)
                ? value.map((option: any) => option.label).join(', ')
                : value?.label || ''
            }
          >
            {Array.isArray(value)
              ? value.map((option: any) => option.label).join(', ')
              : value?.label || ''}
          </SelectText>
          <ArrowButton className="arrow-down" $isOpen={$isOpen}></ArrowButton>
        </SelectInput>
      }
    >
      <SelectStyle
        isMulti={isMulti}
        closeMenuOnSelect={!isMulti}
        inputId={inputId}
        name={name}
        autoFocus
        classNamePrefix={classNamePrefix}
        backspaceRemovesValue={false}
        options={
          $all
            ? [
                {
                  value: '*',
                  label: (
                    <span className="select-all-input">
                      <input
                        type="checkbox"
                        checked={selectAll}
                        onChange={handleSelectAll}
                      />
                      전체
                    </span>
                  ),
                },
                ...options,
              ]
            : options
        }
        components={{
          DropdownIndicator,
          IndicatorSeparator: null,
          Input: CustomInput,
          Option: $checkbox ? CustomOption : DefaultOption,
        }}
        controlShouldRenderValue={false}
        hideSelectedOptions={false}
        isClearable={false}
        menuIsOpen
        onChange={handleChange}
        placeholder={placeholder}
        styles={{
          control: (provided) => ({
            ...provided,
            minWidth: 240,
            margin: 8,
            maxWidth: 400,
          }),
          menu: () => ({
            boxShadow: 'inset 0 1px 0 rgba(0, 0, 0, 0.1)',
          }),
        }}
        tabSelectsValue={false}
        value={$all ? selectedOptions : value}
      />
    </Dropdown>
  );
};

export default SelectSearch;

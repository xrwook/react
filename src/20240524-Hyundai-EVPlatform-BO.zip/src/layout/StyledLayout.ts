import styled, { css } from 'styled-components';
import { DropdownList } from 'common/Dropdown/StyledDropdown';

export const LayoutWrap = styled.div`
  background-color: ${(props) => props.theme.color.white};
  min-width: 1280px;
`;

export const SubLayoutStyle = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 20px 40px 80px;
  margin-left: 296px;
  transition: 0.1s ease-out margin-left;
`;

export const MainContent = styled.main`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  row-gap: 24px;
`;

export const SidebarButton = styled.button`
  position: relative;
  width: 30px;
  height: 40px;
  border: 1px solid #e1e2e2;
  border-right: 0;
  border-top-left-radius: 6px;
  border-bottom-left-radius: 6px;
  background: #fff url('/images/icons/icon-double-arrow-left.svg') no-repeat
    center / 10px 11px;
  margin-top: 16px;
  right: 30px;
  z-index: 100;
`;

export const SidebarDragButton = styled.button`
  position: absolute;
  top: 50%;
  width: 100%;
  height: 32px;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1.5px;
  transform: translateY(-50%);
  cursor: col-resize;
  &::after {
    content: '';
    width: 1.5px;
    height: 12px;
    background-color: #d9d9d9;
  }
  &::before {
    content: '';
    width: 1.5px;
    height: 12px;
    background-color: #d9d9d9;
  }
`;

export const LnbWrap = styled.div`
  position: fixed;
  display: flex;
  flex-direction: column;
  width: 296px;
  height: 100%;
  background-color: #f9fafa;
  border-right: 1px solid #e1e2e2;
  transition: 0.1s ease-out width;
  z-index: 100;

  &.collapse {
    ${SidebarButton} {
      background-image: url('/images/icons/icon-double-arrow-right.svg');
    }
    .lnb-wrap {
      overflow-y: visible;
    }
    .lnb-list {
      padding: 0 10px;
      > li {
        justify-content: center;

        .lnb-item-left {
          gap: 0;
        }
      }
    }

    .lnb-logo {
      opacity: 0;
      transition: 0.1s ease-in all;
    }

    width: 60px;
    transition: 0.1s ease-in width;

    & ~ .main-content-wrap {
      margin-left: 60px;
      transition: 0.1s ease-in margin-left;
    }

    .lnb-footer {
      margin: 0 10px;
      font-size: 13px;
      font-weight: 600;
      text-align: center;
      display: block;

      .normal-text {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #3a4a5c;
        line-height: 20px;
        margin-top: 20px;
      }
    }

    overflow: visible;
  }
`;

export const LnbHeader = styled.div`
  width: 100%;
  height: 88px;
  padding: 25px 20px 0 24px;
`;

export const LnbHeaderLogo = styled.div`
  width: 70px;
  height: 22px;
  background: url('/images/common/ever-logo.svg') no-repeat center / cover;
  opacity: 1;
`;

export const LnbBody = styled.div`
  flex-grow: 1;
  overflow-y: auto;
`;

export const LnbList = styled.ul`
  padding: 0 20px;
`;

export const LnbItem = styled.li`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 49px;
  font-size: 15px;
  font-weight: 600;
  border-bottom: 1px solid #e4ebf1;
  white-space: nowrap;

  .lnb-item-left > a {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`;

export const SidebarDivider = styled.div`
  position: absolute;
  top: 0;
  right: -11px;
  width: 10px;
  height: 100%;
  background-color: ${(props) => props.theme.color.white};

  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: -24px;
    width: 24px;
    height: 100%;
    background: linear-gradient(
      90deg,
      rgba(40, 46, 56, 0) 0%,
      rgba(40, 46, 56, 0.03) 100%
    );
    z-index: 50;
  }

  &::before {
  }
`;

export const LnbFooter = styled.div`
  display: flex;
  align-items: center;
  height: 66px;
  margin: 20px 20px 0;
  border-top: 1px solid #e4ebf1;

  ${DropdownList} {
    width: max-content;
    left: -38px;
  }

  button[aria-expanded] {
    padding: 0;
  }

  [role='option'] {
    text-align: left;
  }
  .normal-text {
    display: none;
  }
  .dropdown-group {
    display: flex;
    gap: 8px;
    align-items: center;
  }
  &.collapse {
    .dropdown-group {
      display: none;
    }
    .normal-text {
      display: block;
    }
  }
`;

export const HeaderWrap = styled.div`
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 52px;
  border-bottom: 1px solid #d9d9d9;
  padding-bottom: 20px;
`;

export const HeaderProfileWrap = styled.div`
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  display: flex;
  flex: 1 0 auto;

  figure {
    display: flex;
    gap: 12px;
    height: 32px;
    align-items: center;
    word-break: break-all;

    figcaption {
      font-size: 14px;
      font-weight: 500;
      color: ${(props) => props.theme.color.text3};
    }
  }

  &:hover {
    .profile-popover {
      display: block;
    }
  }

  .profile-popover {
    display: none;
    position: absolute;
    top: 42px;
    min-width: 280px;
    border: 1px solid #caccd7;
    background-color: ${(props) => props.theme.color.white};
    box-shadow: 0px 6px 10px 0px rgba(0, 0, 0, 0.05);
    border-radius: 4px;
    padding: 8px;
    z-index: 200;
    &:hover {
      display: block;
    }

    .profile-popover-item {
      font-size: 14px;
      font-weight: 600;
      color: ${(props) => props.theme.color.text2};
      border-radius: 4px;
      line-height: 20px;

      > a {
        display: block;
        line-height: 20px;
        padding: 8px 12px;
      }

      > span {
        display: block;
      }

      &__info {
        font-size: 13px;
        font-weight: 400;
        color: ${(props) => props.theme.color.text4};
      }

      &:first-child {
        padding: 8px 38px 8px 12px;
      }

      &:hover {
        background-color: #f8f9fb;
      }
    }
  }
`;

export const ImgArea = styled.div<{ $size?: 'small' | 'large' }>`
  ${(props) => {
    if (props.$size === 'small') {
      return css`
        width: 32px;
        height: 32px;
      `;
    } else if (props.$size === 'large') {
      return css`
        width: 40px;
        height: 40px;
      `;
    }
  }}
  background: url('/images/dummy/img-profile.png') no-repeat center / cover;
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const ContentContainer = styled.div<{ $gap: any | null }>`
  display: flex;
  flex-direction: column;
  gap: ${(props) => props.$gap};
  min-width: 1544px;

  .content-section {
  }
`;

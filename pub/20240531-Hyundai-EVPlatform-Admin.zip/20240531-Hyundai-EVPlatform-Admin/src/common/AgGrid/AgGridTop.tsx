import React from 'react';
import { AgGridTopStyle, AgGridTopRight, Total } from './StyledAgGrid';

export interface AgGridTopProps {
  totalCount?: any;
  selectedCount?: any;
  children?: any;
  $marginTop?: number;
}

const AgGridTop: React.FC<AgGridTopProps> = ({
  totalCount,
  selectedCount,
  children,
  $marginTop,
}) => {
  return (
    <AgGridTopStyle $marginTop={$marginTop}>
      <Total>
        총<strong>{totalCount}</strong>
      </Total>
      {selectedCount !== undefined && selectedCount !== null && (
        <Total>
          선택<strong>{selectedCount}</strong>
        </Total>
      )}
      <AgGridTopRight>{children}</AgGridTopRight>
    </AgGridTopStyle>
  );
};

export default AgGridTop;

import Button from 'common/Button';
import { CheckBox, MenuFooter, SelectStyle } from './StyledSelect';
import { components } from 'react-select';

export type Option = {
  value: number | string;
  label: string;
};

export interface SelectProps {
  options?: any;
  placeholder?: any;
  isMulti?: any;
  hideSelectedOptions?: any;
  className?: any;
  title?: any;
  classNamePrefix: string;
  defaultValue?: any;
  required?: any;
  disabled?: any;
  readonly?: any;
  error?: any;
  id?: any;
  $transparent?: any;
  components?: any;
  isSelectAll?: any;
  value?: any;
  onChange?: any;
  menuTilte?: any;
  menuPortalTarget?: any;
  $button?: any;
  $checkbox?: any;
  $menuPosition?: any;
}

const Select: React.FC<SelectProps> = ({
  placeholder,
  isMulti,
  hideSelectedOptions,
  className,
  classNamePrefix,
  defaultValue,
  disabled,
  id,
  readonly,
  $transparent,
  $button,
  $checkbox,
  ...props
}) => {
  const Option = (props: any) => (
    <components.Option {...props}>
      <CheckBox
        key={props.value}
        type="checkbox"
        checked={props.isSelected}
        onChange={() => {}}
        $checkbox={$checkbox}
      />
      <label>{props.label}</label>
    </components.Option>
  );

  const Menu = (props: any) => (
    <components.Menu {...props}>
      {props.children}
      <MenuFooter $button={$button}>
        <Button onClick={() => {}} $size="small" $variant="transparent">
          초기화
        </Button>
        <Button onClick={() => {}} $size="small" $variant="transparentPurple">
          적용
        </Button>
      </MenuFooter>
    </components.Menu>
  );

  return (
    <SelectStyle
      {...props}
      id={id}
      placeholder={placeholder}
      isMulti={isMulti}
      options={[...props.options]}
      hideSelectedOptions={hideSelectedOptions}
      className={`
        ${className || ''}
      `}
      classNamePrefix={classNamePrefix}
      defaultValue={defaultValue}
      isDisabled={disabled}
      menuIsOpen={readonly ? false : undefined}
      readonly={readonly}
      $transparent={$transparent}
      components={{
        Option: Option,
        Menu: Menu,
        ...props.components,
      }}
    />
  );
};

export default Select;

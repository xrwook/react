import { useState } from 'react';
import Modal from 'common/Modal/Modal';
import ModalHeader from 'common/Modal/ModalHeader';
import ModalContent from 'common/Modal/ModalContent';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';
import Formcontrol from 'common/FormControl';
import FormcontrolItem from 'common/FormcontrolItem';
import Labels from 'common/Labels/Labels';

const ChargingStationStatusChargerInfoContainer: React.FC = () => {
  const [showModal, setShowModal] = useState(true);

  return (
    <>
      {showModal && (
        <Modal
          width="800px"
          height="auto"
          oversize
          onClose={() => setShowModal(false)}
        >
          <ModalHeader>충전기 상세 정보</ModalHeader>
          <ModalContent $marginBottom="30px">
            <Grid $columns={2} $gap="24px">
              <GridItem>
                <Formcontrol title="충전기 이름 (ID)" $detail $gapMini>
                  <FormcontrolItem>Charger 01 (CVF001_#1)</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="상태" $detail $gapMini>
                  <FormcontrolItem>
                    <Labels $color="purpleWhite" $size="default">
                      사용가능
                    </Labels>
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="커넥터 타입" $detail $gapMini>
                  <FormcontrolItem>CCS Combo</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="속도" $detail $gapMini>
                  <FormcontrolItem>급속 (최대 150kW)</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="위치" $detail $gapMini>
                  <FormcontrolItem>왼쪽</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="마지막 사용 시각" $detail $gapMini>
                  <FormcontrolItem>YYYY-MM-DD HH:MM</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="충전기 용량" $detail $gapMini>
                  <FormcontrolItem>50.00 kW</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="전용태그 유형" $detail $gapMini>
                  <FormcontrolItem>-</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="충전기 갱신 시각" $detail $gapMini>
                  <FormcontrolItem>YYYY-MM-DD HH:MM</FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="충전 시작/종료일시" $detail $gapMini>
                  <FormcontrolItem>
                    YYYY-MM-DD HH:MM ~ YYYY-MM-DD HH:MM
                  </FormcontrolItem>
                </Formcontrol>
              </GridItem>
              <GridItem>
                <Formcontrol title="이용시간 (분)" $detail $gapMini>
                  <FormcontrolItem>MM분</FormcontrolItem>
                </Formcontrol>
              </GridItem>
            </Grid>
          </ModalContent>
        </Modal>
      )}
    </>
  );
};

export default ChargingStationStatusChargerInfoContainer;

import { Route, Routes } from 'react-router-dom';
// import GenesisBrandTest from '../pages/brand/GenesisBrandTest';
import GenesisBrandTest from 'pages/Brand/GenesisBrandTest';

const GenesisRoute = () => {
  return (
    <Routes>
      <Route path="brand" element={<GenesisBrandTest />} />
    </Routes>
  );
};

export default GenesisRoute;

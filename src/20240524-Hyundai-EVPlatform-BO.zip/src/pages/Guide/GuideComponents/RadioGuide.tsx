import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import GuideTable from './GuideTable';
import Radio from 'common/Radio/Radio';
import Grid from 'common/Grid';
import GridItem from 'common/Griditem/GridItem';

import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const RadioGuide = () => {
  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Radio</GuideText>
        <GuideBox>
          <Grid $columns={4}>
            <GridItem>
              <GuideText>
                <h4>small</h4>
              </GuideText>
              {/* small */}
              <Radio
                id="radio01"
                name="radio01"
                htmlFor="radio01"
                defaultChecked
              />
              <Radio
                id="radio02"
                name="radio02"
                htmlFor="radio02"
                defaultChecked
                disabled
              />
              <Radio id="radio03" name="radio03" htmlFor="radio03" />
              <Radio id="radio04" name="radio04" htmlFor="radio04" disabled />
            </GridItem>
            <GridItem>
              {/* small + label */}
              <GuideText>
                <h4>small + label</h4>
              </GuideText>
              <Radio
                id="radio05"
                name="radio05"
                text="Label"
                htmlFor="radio05"
                defaultChecked
              />
              <Radio
                id="radio06"
                name="radio06"
                text="Label"
                htmlFor="radio06"
                defaultChecked
                disabled
              />
              <Radio
                id="radio07"
                name="radio07"
                text="Label"
                htmlFor="radio07"
              />
              <Radio
                id="radio08"
                name="radio08"
                text="Label"
                htmlFor="radio08"
                disabled
              />
            </GridItem>
            <GridItem>
              {/* large */}
              <GuideText>
                <h4>large</h4>
              </GuideText>
              <Radio
                id="radio09"
                name="radio09"
                htmlFor="radio09"
                defaultChecked
                $large
              />
              <Radio
                id="radio10"
                name="radio10"
                htmlFor="radio10"
                $large
                defaultChecked
                disabled
              />
              <Radio id="radio11" name="radio11" htmlFor="radio11" $large />
              <Radio
                id="radio12"
                name="radio12"
                htmlFor="radio12"
                $large
                disabled
              />
            </GridItem>
            <GridItem>
              {/* large + label */}
              <GuideText>
                <h4>large + label</h4>
              </GuideText>
              <Radio
                id="radio13"
                name="radio13"
                text="Label"
                htmlFor="radio13"
                $large
                defaultChecked
              />
              <Radio
                id="radio14"
                name="radio14"
                text="Label"
                htmlFor="radio14"
                $large
                defaultChecked
                disabled
              />
              <Radio
                id="radio15"
                name="radio15"
                text="Label"
                htmlFor="radio15"
                $large
              />
              <Radio
                id="radio16"
                name="radio16"
                text="Label"
                htmlFor="radio16"
                $large
                disabled
              />
              {/*  */}
            </GridItem>
          </Grid>
        </GuideBox>
        <GuideSubBox>
          &lt;Radio id="" text="" name="" htmlFor="" defaultChecked /&gt; <br />
          &lt;Radio id="" text="" name="" htmlFor="" defaultChecked disabled
          large /&gt; <br />
          &lt;Radio id="" text="" name="" htmlFor="" $large /&gt; <br />
          &lt;Radio id="" text="" name="" htmlFor="" disabled $large /&gt;
        </GuideSubBox>

        <GuideTable>
          <colgroup>
            <col width="20%" />
            <col width="30%" />
            <col width="30%" />
            <col />
          </colgroup>
          <thead>
            <tr>
              <th>props</th>
              <th>형식</th>
              <th>설명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>htmlFor</td>
              <td>htmlFor="radio01"</td>
              <td>label과 radio 연결</td>
              <td></td>
            </tr>
            <tr>
              <td>defaultChecked</td>
              <td>defaultChecked</td>
              <td>체크된 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>disabled</td>
              <td>disabled</td>
              <td>비활성 상태</td>
              <td>boolean</td>
            </tr>
            <tr>
              <td>$large</td>
              <td>$large</td>
              <td>큰 사이즈</td>
              <td>boolean</td>
            </tr>
          </tbody>
        </GuideTable>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default RadioGuide;

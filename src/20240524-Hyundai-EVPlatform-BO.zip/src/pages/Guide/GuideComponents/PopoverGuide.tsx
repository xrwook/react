import { useState } from 'react';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Popover from 'common/Popover';
import Icon from 'common/Icon';
import { StyledWrapper, StyledGuideWrapper } from './GuideBox/GuideWrapper';

const PopoverGuide = () => {
  const [showPopover, setShowPopover] = useState(false);

  return (
    <StyledGuideWrapper>
      <StyledWrapper>
        <GuideText>Popover(디자인 확정전)</GuideText>
        <GuideBox>
          <Icon
            $widthSize={48}
            $heightSize={48}
            $name={'icon-pin'}
            onClick={() => setShowPopover(true)}
          >
            위치
          </Icon>
          {showPopover && (
            <Popover onClose={() => setShowPopover(false)}>
              Enter long form text here Enter long
              <br />
              form text here Enter long form text
              <br />
              here Enter long form text here
            </Popover>
          )}
        </GuideBox>
        <GuideSubBox>&lt;Popover /&gt;</GuideSubBox>
      </StyledWrapper>
    </StyledGuideWrapper>
  );
};

export default PopoverGuide;

import { Route, Routes } from 'react-router-dom';
import PublishingList from 'pages/Guide/PublishingList';
import publishdata from 'pages/Guide/publishdata';
import routes from './publishroutedata';

const PublishingRoute: React.FC = () => (
  <Routes>
    <Route
      path="publishinglist"
      element={<PublishingList data={publishdata} />}
    ></Route>
    {routes.map(({ path, element }) => (
      <Route key={path} path={`/sub/${path}`} element={element} />
    ))}
  </Routes>
);

export default PublishingRoute;

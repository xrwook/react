import { ModalContentWrapper } from './StyledModal';

export interface ModalContentProps {
  children?: any;
}

const ModalContent: React.FC<ModalContentProps> = ({ children }) => {
  return (
    <>
      <ModalContentWrapper>{children}</ModalContentWrapper>
    </>
  );
};

export default ModalContent;

import styled from 'styled-components';
import homeIcon from '/images/icons/icon-home.svg';
import { NavLink } from 'react-router-dom';

export const BreadcrumbWrapper = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
`;

export const Breadcrumbhome = styled(NavLink)`
  display: inline-block;
  width: 20px;
  height: 20px;
  background-image: url(${homeIcon});
  background-repeat: no-repeat;
`;

export const BreadcrumbItem = styled.div`
  display: inline-block;
  position: relative;
  padding-left: 25px;
`;

export const BreadcrumbItemLink = styled(NavLink)`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: ${(props) => props.theme.color.gray4};

  &.active {
    color: ${(props) => props.theme.color.primary};
    font-weight: 500;
  }

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    width: 5px;
    height: 12px;
    margin: 0 10px;
    background: url('../images/icons/icon-home-line.svg') no-repeat;
  }
`;

import ChargingStationsListContainer from 'pages/ChargingStations/container/ChargingStationsListContainer';
import ChargingStationsDetailContainer from 'pages/ChargingStations/container/ChargingStationsDetailContainer';
import ChargingStationsEditContainer from 'pages/ChargingStations/container/ChargingStationsEditContainer';
import ChargingStationsDeleteContainer from 'pages/ChargingStations/container/ChargingStationsDeleteContainer';
import ChargingStationsLocationContainer from 'pages/ChargingStations/container/ChargingStationsLocationContainer';
import ChargingStationsChargingRateInfoContainer from 'pages/ChargingStations/container/ChargingStationsChargingRateInfoContainer';
import ChargingStationsReviewInfoContainer from 'pages/ChargingStations/container/ChargingStationsReviewInfoContainer';
import ChargingStationsRegistrationContainer from 'pages/ChargingStations/container/ChargingStationsRegistrationContainer';
import ChargingStationsAddContainer from 'pages/ChargingStations/container/ChargingStationsAddContainer';
import ChargingStationsAddressSearchContainer from 'pages/ChargingStations/container/ChargingStationsAddressSearchContainer';
import ChargingStationsBulkRegistrationContainer from 'pages/ChargingStations/container/ChargingStationsBulkRegistrationContainer';
import ChargingStationsChargerDeleteContainer from 'pages/ChargingStations/container/ChargingStationsChargerDeleteContainer';
import ChargingStationsChargerEditContainer from 'pages/ChargingStations/container/ChargingStationsChargerEditContainer';
import ChargingStationsRegistrationAlertContainer from 'pages/ChargingStations/container/ChargingStationsRegistrationAlertContainer';
import ChargingStationsChargerRegistrationContainer from 'pages/ChargingStations/container/ChargingStationsChargerRegistrationContainer';
import ChargingStationsChargerInfoContainer from 'pages/ChargingStations/container/ChargingStationsChargerInfoContainer';

const routes = [
  {
    path: '/ChargingStationsList',
    element: <ChargingStationsListContainer />,
  },
  {
    path: '/ChargingStationsDetail',
    element: <ChargingStationsDetailContainer />,
  },
  {
    path: '/ChargingStationsAdd',
    element: <ChargingStationsAddContainer />,
  },
  {
    path: '/ChargingStationsEdit',
    element: <ChargingStationsEditContainer />,
  },
  {
    path: '/ChargingStationsDelete',
    element: <ChargingStationsDeleteContainer />,
  },
  {
    path: '/ChargingStationsLocation',
    element: <ChargingStationsLocationContainer />,
  },
  {
    path: '/ChargingStationsChargingRateInfo',
    element: <ChargingStationsChargingRateInfoContainer />,
  },
  {
    path: '/ChargingStationsReviewInfo',
    element: <ChargingStationsReviewInfoContainer />,
  },
  {
    path: '/ChargingStationsChargerInfo',
    element: <ChargingStationsChargerInfoContainer />,
  },
  {
    path: '/ChargingStationsRegistration',
    element: <ChargingStationsRegistrationContainer />,
  },
  {
    path: '/ChargingStationsRegistrationAlert',
    element: <ChargingStationsRegistrationAlertContainer />,
  },
  {
    path: '/ChargingStationsAddressSearch',
    element: <ChargingStationsAddressSearchContainer />,
  },
  {
    path: '/ChargingStationsChargerRegistration',
    element: <ChargingStationsChargerRegistrationContainer />,
  },
  {
    path: '/ChargingStationsChargerEdit',
    element: <ChargingStationsChargerEditContainer />,
  },
  {
    path: '/ChargingStationsChargerDelete',
    element: <ChargingStationsChargerDeleteContainer />,
  },
  {
    path: '/ChargingStationsBulkRegistration',
    element: <ChargingStationsBulkRegistrationContainer />,
  },
];

export default routes;

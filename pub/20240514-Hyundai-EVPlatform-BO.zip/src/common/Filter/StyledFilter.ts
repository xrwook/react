import styled, { css } from 'styled-components';
import { FilterItemProps } from './FilterItem';
import { InputWrapper } from 'common/TextField/StyledTextField';

export const FilterListWrap = styled.div`
  position: relative;
  height: 48px;

  & > .filter-list {
    row-gap: 65px;
  }

  &:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    border-bottom: 1px solid ${(props) => props.theme.color.gray11};
  }
  &.filter-expanded {
    height: auto;

    & > .filter-list {
      row-gap: 0;
    }
  }
  .filter-detail-button-group {
    position: absolute;
    top: 0;
    right: 0;
    height: 32px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
`;

export const FilterListStyle = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  position: relative;
  width: 100%;
  max-width: 1800px;
  padding-bottom: 4px;
  padding-right: 106px;
`;

export const FilterItemStyle = styled.div<FilterItemProps>`
  display: flex;
  align-items: center;
  padding: ${(props) =>
    props.$search ? '0' : props.$button ? '0 0 0 4px' : '0 8px 0 12px'};
  margin-bottom: 12px;
  margin-right: ${(props) => (props.$search ? '12px' : '8px')};
  ${(props) => {
    if (props.$search) {
      return css`
        ${InputWrapper} {
          &.input-typing {
            input {
              padding-right: 50px;
            }
          }
        }
      `;
    }
  }}

  &:hover {
    border-radius: 4px;
    background-color: ${(props) =>
      props.$button ? 'none' : `${props.theme.color.gray1}`};
  }

  > div > input {
    width: ${(props) => (props.$search ? '296px' : 'auto')};
    ${(props) => {
      if (props.$search) {
        return css`
          padding-right: 26px;
        `;
      }
    }}
  }

  .react-select__control {
    margin-bottom: 0;
    line-height: 32px;
  }

  .react-select__indicator {
    margin-top: 0;
    flex: 1 0 auto;
    background-image: url('/images/icons/icon-filter-arrow-down.svg');
  }

  .react-select__indicators {
    height: 100%;
  }

  .react-select__input {
    position: absolute;
    left: 0;
  }

  .react-select__value-container {
    height: 100%;
    line-height: 18px;
  }

  .arrow-down {
    background-image: url('/images/icons/icon-filter-arrow-down.svg');
  }
`;

export const FilterLabeltyle = styled.div`
  font-size: ${(props) => props.theme.fontSize.fontSize3};
  line-height: 20px;
  color: #434343;
  font-weight: 600;
`;

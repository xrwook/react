import GlobalStyle from 'assets/theme/globalStyle';
import Router from './routes';
// import Header from './common/Header';
import { findServiceTypeByUserAgent } from './utils/validation';
import { ThemeProvider } from 'styled-components';
import theme from 'assets/theme/theme';

export default function App() {
  console.log('userAgent:', navigator.userAgent);
  console.log('test:', findServiceTypeByUserAgent());
  return (
    <>
      <ThemeProvider theme={theme}>
        <GlobalStyle />

        <div>
          {/* 퍼블페이지를 위해 주석 처리함 */}

          {/* <Header /> */}
          <Router serviceType={findServiceTypeByUserAgent()} />
        </div>
      </ThemeProvider>
    </>
  );
}

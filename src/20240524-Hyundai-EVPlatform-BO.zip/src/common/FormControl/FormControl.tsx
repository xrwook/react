import React from 'react';
import {
  FormControlWrap,
  FormControlItem,
  FormLabelWrap,
  FormControlLabel,
  RequiredDot,
  FormDetailHeader,
} from './StyledFormControl';

export interface FormWrapProps {
  children?: React.ReactNode;
  title?: string;
  required?: boolean;
  htmlFor?: string;
  $row?: boolean;
  $detail?: any;
  $gapSmall?: any;
  $gapLarge?: any;
  $gapMini?: any;
}

const FormWrap: React.FC<FormWrapProps> = ({
  title,
  required,
  htmlFor,
  children,
  $detail,
  $row,
  $gapSmall,
  $gapLarge,
  $gapMini,
}) => {
  return (
    <FormControlWrap
      $row={$row}
      $gapSmall={$gapSmall}
      $gapLarge={$gapLarge}
      $gapMini={$gapMini}
    >
      <FormLabelWrap
        $detail={$detail}
        $gapSmall={$gapSmall}
        $gapLarge={$gapLarge}
      >
        {!$detail ? (
          <FormControlLabel htmlFor={htmlFor}>
            {title}
            {required && <RequiredDot />}
          </FormControlLabel>
        ) : (
          <FormDetailHeader>{title}</FormDetailHeader>
        )}
      </FormLabelWrap>
      <FormControlItem $detail={$detail}>{children}</FormControlItem>
    </FormControlWrap>
  );
};

export default FormWrap;

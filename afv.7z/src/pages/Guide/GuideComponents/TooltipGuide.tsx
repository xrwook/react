import styled from 'styled-components';
import GuideWrapper from './GuideBox/GuideWrapper';
import GuideBox from './GuideBox/GuideBox';
import GuideText from './GuideBox/GuideText';
import GuideSubBox from './GuideBox/GuideSubBox';
import Tooltip from 'common/Tooltip';

const StyledGuideWrapper = styled.div`
  width: 100%;
`;

const Layout = styled.div`
  width: 300px;
  height: 100px;
  margin: 0 auto;
  position: relative;
`;

const LayoutTop = styled.div`
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
`;

const LayoutLeft = styled.div`
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
`;

const LayoutRight = styled.div`
  position: absolute;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
`;

const LayoutBottom = styled.div`
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
`;

const TooltipGuide = () => {
  return (
    <StyledGuideWrapper>
      <GuideWrapper>
        <GuideText>Tooltip</GuideText>
        <GuideBox>
          <Layout>
            <LayoutTop>
              <Tooltip
                message="Tooltips shouldn’t really exceed one line, but sometimes it’s unavoidable"
                direction="top"
              >
                TOP
              </Tooltip>
            </LayoutTop>
            <LayoutLeft>
              <Tooltip message="Tooltip" direction="left" auto>
                LEFT
              </Tooltip>
            </LayoutLeft>
            <LayoutRight>
              <Tooltip message="Dashboard" direction="right" auto>
                RIGHT
              </Tooltip>
            </LayoutRight>
            <LayoutBottom>
              <Tooltip
                message="Tooltips shouldn’t really exceed one line, but sometimes it’s unavoidableTooltips shouldn’t really exceed one line, but sometimes it’s unavoidable"
                direction="bottom"
              >
                BOTTOM
              </Tooltip>
            </LayoutBottom>
          </Layout>
        </GuideBox>
        <GuideSubBox>
          &lt;Tooltip message="" direction="top" auto&gt;&lt;/Tooltip&gt;
          <br />
          &lt;Tooltip message="" direction="left" auto&gt;&lt;/Tooltip&gt;
          <br />
          &lt;Tooltip message="" direction="right" auto&gt;&lt;/Tooltip&gt;
          <br />
          &lt;Tooltip message="" direction="bottom" auto&gt;&lt;/Tooltip&gt;
          <br />
        </GuideSubBox>
      </GuideWrapper>
    </StyledGuideWrapper>
  );
};

export default TooltipGuide;

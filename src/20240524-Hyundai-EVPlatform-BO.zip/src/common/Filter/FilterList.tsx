import { useState, useRef } from 'react';
import { FilterListStyle, FilterListWrap } from './StyledFilter';
import Button from 'common/Button/Button';
export interface FilterListProps {
  children?: any;
  useDetailButtons?: boolean;
}

const FilterList: React.FC<FilterListProps> = ({
  children,
  useDetailButtons,
}) => {
  const initElements = children;
  useDetailButtons = initElements.length > 7 ? true : false;
  const [elements, setElements] = useState<string[]>(
    useDetailButtons && initElements.slice(0, 6),
  );
  const [expanded, setExpanded] = useState<boolean>(false);
  const filterListElement = useRef<any>(null);
  const expandedElements = () => {
    setElements(initElements);
    setExpanded(true);
  };

  const collapseElemnts = () => {
    setElements(initElements.slice(0, 6));
    setExpanded(false);
  };

  return (
    <FilterListWrap>
      <FilterListStyle className="filter-list" ref={filterListElement}>
        {useDetailButtons
          ? elements.map((element, index) => <div key={index}>{element}</div>)
          : children}
        {useDetailButtons && (
          <div className="filter-detail-button-group">
            {!expanded ? (
              <Button
                onClick={expandedElements}
                $size="mini"
                $variant="secondaryGray"
                className="filter-detail-button__detail"
              >
                더보기
              </Button>
            ) : (
              <>
                <Button
                  onClick={collapseElemnts}
                  $size="mini"
                  $variant="secondaryGray"
                  className="filter-detail-button__detail"
                >
                  간략히
                </Button>
                <Button
                  onClick={() => {}}
                  $size="mini"
                  $variant="secondaryGray"
                  className="filter-detail-button__detail"
                >
                  초기화
                </Button>
              </>
            )}
          </div>
        )}
      </FilterListStyle>
    </FilterListWrap>
  );
};

export default FilterList;

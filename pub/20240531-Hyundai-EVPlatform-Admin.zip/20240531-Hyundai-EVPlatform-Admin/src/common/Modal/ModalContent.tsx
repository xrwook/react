import { ModalContentWrapper } from './StyledModal';

export interface ModalContentProps {
  children?: any;
  $marginBottom?: any;
  $height?: any;
  $oversize?: boolean;
}

const ModalContent: React.FC<ModalContentProps> = ({
  children,
  $marginBottom,
  $height,
  $oversize,
}) => {
  return (
    <ModalContentWrapper
      $marginBottom={$marginBottom}
      $height={$height}
      $oversize={$oversize}
    >
      {children}
    </ModalContentWrapper>
  );
};

export default ModalContent;
